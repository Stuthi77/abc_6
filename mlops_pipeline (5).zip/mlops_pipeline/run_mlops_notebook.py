# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "6"
# dependencies = [
#   "-r requirements.txt",
# ]
# ///
# MAGIC %load_ext autoreload
# MAGIC %autoreload 2
# MAGIC # Enables autoreload; learn more at https://docs.databricks.com/en/files/workspace-modules.html#autoreload-for-python-modules
# MAGIC # To disable autoreload; run %autoreload 0

# COMMAND ----------

# DBTITLE 1,MLops pipeline
# MAGIC %md
# MAGIC # MLOps pipeline
# MAGIC
# MAGIC ```
# MAGIC features ─▶ train ─[review]─▶ register ─[status]─▶ serve
# MAGIC                                   │
# MAGIC         score ─▶ baseline ─▶ monitor ─▶ sync dashboard ─▶ drift / degradation
# MAGIC                                   │
# MAGIC                          visualize ─┴─[approve]─▶ rollback
# MAGIC ```
# MAGIC Every cell is a single `stage_*` call from `src/pipeline.py`; no logic or
# MAGIC table names live in this notebook. Stages never chain on their own. The ones
# MAGIC that change shared state — `register`, `serve`, `baseline`, `rollback` —
# MAGIC require `approved=True`.
# MAGIC
# MAGIC Inputs live in `src/config/` (`feature_config.py`, `mlops_config.py`,
# MAGIC `monitoring_config.py`) as plain dictionaries only. The code that builds and
# MAGIC validates them lives in `src/settings/` (`*_settings.py`, `builder.py`).

# COMMAND ----------

# DBTITLE 1,Install dependencies
# MAGIC %pip install -r requirements.txt

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,Parameters and stage imports
import os, sys
REPO_ROOT = os.getcwd()          # the folder this notebook lives in
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

from src.pipeline import (stage_features, stage_train, stage_review,
                          stage_register, stage_status, stage_serve,
                          stage_score, stage_baseline, stage_monitor,
                          stage_sync_dashboard, stage_drift, stage_degradation,
                          stage_visualize, stage_rollback, stage_diagnose_monitor)
from src.config.mlops_config import USE_CASES, DEFAULT_USE_CASE
from src.config.feature_config import FEATURE_SETS
from src.config.monitoring_config import MONITORING_CONFIGS

dbutils.widgets.dropdown("use_case", DEFAULT_USE_CASE, sorted(USE_CASES), "Use case")
dbutils.widgets.dropdown("feature_set", sorted(FEATURE_SETS)[0],
                         sorted(FEATURE_SETS), "Feature set")
dbutils.widgets.dropdown("monitor", sorted(MONITORING_CONFIGS)[0],
                         sorted(MONITORING_CONFIGS), "Monitoring config")
dbutils.widgets.dropdown("approve", "false", ["true", "false"],
                         "Approve state changes")
dbutils.widgets.dropdown("recreate_monitor", "false", ["true", "false"],
                         "Recreate monitor (after schema changes)")

USE_CASE    = dbutils.widgets.get("use_case")
FEATURE_SET = dbutils.widgets.get("feature_set")
MONITOR     = dbutils.widgets.get("monitor")
APPROVE     = dbutils.widgets.get("approve") == "true"
RECREATE    = dbutils.widgets.get("recreate_monitor") == "true"
print(f"use_case={USE_CASE} feature_set={FEATURE_SET} monitor={MONITOR} "
      f"approve={APPROVE} recreate_monitor={RECREATE}")

# COMMAND ----------

# MAGIC %md ## 0. Features — dry run first

# COMMAND ----------

stage_features(FEATURE_SET, dry_run=True)

# COMMAND ----------

stage_features(FEATURE_SET)

# COMMAND ----------

# MAGIC %md ## 1. Train

# COMMAND ----------

stage_train(USE_CASE)

# COMMAND ----------

# MAGIC %md ## GATE 1 — review candidates against the incumbent

# COMMAND ----------

stage_review(USE_CASE)

# COMMAND ----------

# MAGIC %md ## 2. Register — needs approval

# COMMAND ----------

stage_register(USE_CASE, approved=APPROVE)

# COMMAND ----------

# MAGIC %md ## GATE 2 — registry vs endpoint

# COMMAND ----------

stage_status(USE_CASE)

# COMMAND ----------

# MAGIC %md ## 3. Serve — needs approval

# COMMAND ----------

stage_serve(USE_CASE, approved=APPROVE)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Score — batch predictions for monitoring
# MAGIC Scores the deployed version plus `compare_model_refs` from the config, adds the
# MAGIC slicing column (`batch.enrichment`) and writes the output types the monitor needs.
# MAGIC Only periods without predictions are scored per version, so re-running is cheap.

# COMMAND ----------

stage_score(MONITOR)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Baseline + Monitor — create or refresh
# MAGIC The baseline (training rows scored by the Champion) is the reference the monitor
# MAGIC measures drift against — needs approval because it overwrites the table.
# MAGIC The monitor produces the profile and drift tables the detectors read, and its
# MAGIC generated dashboard is synced right after. Set the `recreate_monitor` widget to
# MAGIC `true` only after the inference table schema changed.

# COMMAND ----------

# DBTITLE 1,Build monitor baseline
stage_baseline(MONITOR, approved=APPROVE)

# COMMAND ----------

stage_monitor(MONITOR, recreate=RECREATE)

# COMMAND ----------

# DBTITLE 1,Shift inference dates into the monitor 30-day window
# ── Shift the time column forward so the monitor's 30-day lookback can see the data ──
# Table, column and shift come from cfg.batch (monitoring_config.py: date_shift_days).
# The shift is measured against the feature table, so re-running is a no-op.

import importlib
from pyspark.sql import functions as F
import src.config.monitoring_config as monitoring_config
import src.settings.monitoring_settings as monitoring_settings
importlib.reload(monitoring_config)     # pick up config (inputs) edits
importlib.reload(monitoring_settings)   # rebuild the objects from them
from src.settings.monitoring_settings import get_monitoring_config

b = get_monitoring_config(MONITOR).batch
if b.date_shift_days == 0:
    print(f"date_shift_days=0 for '{MONITOR}' — nothing to shift.")
else:
    src_max = spark.read.table(b.feature_table).agg(F.max(b.time_column)).first()[0]
    inf_max = spark.read.table(b.inference_table).agg(F.max(b.time_column)).first()[0]
    already = (inf_max - src_max).days
    delta = b.date_shift_days - already
    if delta == 0:
        print(f"Already shifted by {already} day(s) — nothing to do.")
    else:
        (spark.read.table(b.inference_table)
            .withColumn(b.time_column, F.col(b.time_column) + F.expr(f"INTERVAL {delta} DAYS"))
            .write.format("delta").mode("overwrite").saveAsTable(b.inference_table))
        print(f"Shifted {b.time_column} by {delta} day(s) (total {b.date_shift_days}).")
    display(spark.sql(f"SELECT min({b.time_column}), max({b.time_column}), count(*) "
                      f"FROM {b.inference_table}"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Drift — have the inputs moved?
# MAGIC Detection only. Drift is a reason to look, not to roll back.

# COMMAND ----------

stage_drift(MONITOR)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Degradation — has live error actually worsened?
# MAGIC Compares the monitor's error metric to the Champion's training metric
# MAGIC over consecutive windows.

# COMMAND ----------

stage_degradation(MONITOR)

# COMMAND ----------

# DBTITLE 1,Dashboard and visualizations
# MAGIC %md
# MAGIC ## 8. Dashboard sync + visualizations
# MAGIC Repairs the monitor-generated dashboard (slice / Model Id / Top K / fairness filters)
# MAGIC and verifies every dataset; then charts prediction distribution by model version,
# MAGIC drift, quantile shifts and fairness ratios. Settings: `cfg.dashboard`, `cfg.viz`.
# MAGIC After a sync, close open dashboard tabs and hard-reload before editing.

# COMMAND ----------

# DBTITLE 1,Sync monitor dashboard
stage_sync_dashboard(MONITOR)

# COMMAND ----------

# DBTITLE 1,Monitoring charts
stage_visualize(MONITOR)

# COMMAND ----------

# MAGIC %md
# MAGIC ## GATE 3 — rollback, needs approval
# MAGIC Promotes the Challenger and keeps the demoted Champion as Challenger,
# MAGIC so this is reversible.

# COMMAND ----------

stage_rollback(MONITOR, approved=APPROVE)