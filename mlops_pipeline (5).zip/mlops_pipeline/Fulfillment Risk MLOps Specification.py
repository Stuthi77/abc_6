# Databricks notebook source
# DBTITLE 1,Title
# MAGIC %md
# MAGIC # MLOps Solution Specification: Fulfillment Risk Classification
# MAGIC
# MAGIC This document outlines the end-to-end machine learning operationalization (MLOps) strategy for classifying fulfillment risk on open sales orders. By leveraging historical order, inventory, and warehouse data from the ERP system, this predictive model enables the supply chain team to proactively identify orders at risk of fulfillment delays, prioritize warehouse operations, and optimize inventory allocation.

# COMMAND ----------

# DBTITLE 1,Executive Summary
# MAGIC %md
# MAGIC ## 1. Executive Summary
# MAGIC
# MAGIC This document outlines the end-to-end machine learning operationalization (MLOps) strategy for classifying fulfillment risk on open sales order lines. Each order line is assigned to one of four risk categories based on inventory position, supply pipeline status, and historical fulfillment patterns.
# MAGIC
# MAGIC The four risk classes are:
# MAGIC
# MAGIC | Risk Class | Description |
# MAGIC | --- | --- |
# MAGIC | Low - Stock Available | Sufficient on-hand inventory to fulfill the order immediately |
# MAGIC | Medium - Supply In Pipeline | Inventory is on order or in transit; fulfillment is expected but not immediate |
# MAGIC | Medium - Receipt Expected | A receipt is expected within the lead time window |
# MAGIC | High - No Supply Visibility | No inventory, no supply in pipeline, and no receipts expected |
# MAGIC
# MAGIC By classifying every open order line in near-real-time, the supply chain team can proactively escalate high-risk lines, adjust warehouse pick priorities, and trigger expedited procurement before commitments are missed.
# MAGIC
# MAGIC The model is trained on \~3,500 historical order lines with engineered features derived from item-level and customer-level fulfillment history, warehouse assignment, lead time parameters, and calendar context. Supply-side columns that directly encode the risk label (available\_qty, on\_order\_qty, in\_transit\_qty, supply\_gap\_qty, days\_until\_fulfillment) are excluded from features to ensure the model learns generalizable patterns rather than reproducing the deterministic rule.

# COMMAND ----------

# DBTITLE 1,Data Sources and Schema Mapping
# MAGIC %md
# MAGIC ## 2. Data Sources and Schema Mapping
# MAGIC
# MAGIC The foundation of this classification model relies on a consolidated ERP order/inventory snapshot. The source table, target variable, and derived feature tables are organized as follows.
# MAGIC
# MAGIC ### 2.1 Source Table
# MAGIC
# MAGIC | Attribute | Value |
# MAGIC | --- | --- |
# MAGIC | Source Table | `dev_platform.mlops.fulfillment_risk_level` |
# MAGIC | Grain | One row per order line (order\_number × item\_number) |
# MAGIC | Row Count | \~3,500 (training) + validation split |
# MAGIC | Time Column | `order_date` (DATE) |
# MAGIC
# MAGIC ### 2.2 Source Schema
# MAGIC
# MAGIC | Column | Type | Role |
# MAGIC | --- | --- | --- |
# MAGIC | order\_number | STRING | Identifier / join key |
# MAGIC | item\_number | STRING | Identifier / join key |
# MAGIC | item\_description | STRING | Free text (excluded) |
# MAGIC | customer\_number | STRING | Categorical (replaced by history features) |
# MAGIC | customer\_name | STRING | Free text (excluded) |
# MAGIC | warehouse | STRING | Categorical (one-hot encoded: WH1, WH2, WH3, other) |
# MAGIC | order\_date | DATE | Event time column |
# MAGIC | requested\_ship\_date | DATE | Supply-side (excluded from features) |
# MAGIC | backorder\_qty | DECIMAL(19,5) | Demand quantity on this line |
# MAGIC | extended\_price | DECIMAL(19,5) | Order line value |
# MAGIC | on\_hand\_qty | DECIMAL(19,5) | Physical stock at order time |
# MAGIC | available\_qty | DECIMAL(20,5) | **Excluded** — used in labelling rule |
# MAGIC | total\_backordered | DECIMAL(19,5) | Item-level backorder aggregate |
# MAGIC | on\_order\_qty | DECIMAL(19,5) | **Excluded** — used in labelling rule |
# MAGIC | in\_transit\_qty | DECIMAL(19,5) | **Excluded** — used in labelling rule |
# MAGIC | safety\_stock | DECIMAL(19,5) | Safety stock threshold |
# MAGIC | purchasing\_lead\_time\_days | DECIMAL(10,0) | Supplier purchasing lead time |
# MAGIC | mfg\_fixed\_lead\_time | DECIMAL(10,0) | Manufacturing fixed lead time |
# MAGIC | next\_expected\_receipt | DATE | **Excluded** — used in labelling rule |
# MAGIC | next\_expected\_delivery | DATE | Supply-side (excluded) |
# MAGIC | requested\_lead\_time\_days | INT | Ship-date minus order-date |
# MAGIC | supply\_gap\_qty | DECIMAL(21,5) | **Excluded** — used in labelling rule |
# MAGIC | days\_until\_fulfillment | INT | **Excluded** — used in labelling rule |
# MAGIC | days\_overdue | INT | CURRENT\_DATE-relative (excluded) |
# MAGIC | estimated\_delivery\_date | DATE | CURRENT\_DATE-relative (excluded) |
# MAGIC | fulfillment\_risk\_level | STRING | **Target variable** (4 classes) |
# MAGIC | snapshot\_date | DATE | Bookkeeping (excluded) |
# MAGIC | row\_seq | INT | Bookkeeping (excluded) |
# MAGIC
# MAGIC ### 2.3 Target Variable Derivation
# MAGIC
# MAGIC The target variable `fulfillment_risk_level` is a categorical label derived by a deterministic CASE statement in the source ETL that evaluates inventory position columns (available\_qty, on\_order\_qty, in\_transit\_qty, next\_expected\_receipt, supply\_gap\_qty, days\_until\_fulfillment). These columns are deliberately excluded from the feature matrix to prevent the model from simply memorizing the rule. The categorical label is integer-encoded as `risk_level_encoded` (0–3) for model consumption.

# COMMAND ----------

# DBTITLE 1,Feature Engineering Strategy
# MAGIC %md
# MAGIC ## 3. Feature Engineering Strategy
# MAGIC
# MAGIC Feature engineering operates in **row-level mode** — each source row (one order line) produces one output row, with no resampling or aggregation. Features are constructed in the following categories.
# MAGIC
# MAGIC ### 3.1 Passthrough Features (Known at Order Placement)
# MAGIC
# MAGIC These columns are carried directly from the source, coerced to numeric types where needed:
# MAGIC
# MAGIC * `backorder_qty` — demand on this order line
# MAGIC * `extended_price` — line value
# MAGIC * `on_hand_qty` — physical stock at order time
# MAGIC * `total_backordered` — item-level total backorder quantity
# MAGIC * `safety_stock` — safety stock threshold
# MAGIC * `purchasing_lead_time_days` — supplier lead time in days
# MAGIC * `mfg_fixed_lead_time` — manufacturing fixed lead time in days
# MAGIC * `requested_lead_time_days` — requested ship date minus order date
# MAGIC
# MAGIC ### 3.2 Point-in-Time History Features
# MAGIC
# MAGIC Computed from PRIOR rows only (shifted by one row so the current line never contributes to its own feature):
# MAGIC
# MAGIC **Item History (series = item\_number):**
# MAGIC
# MAGIC | Feature | Description |
# MAGIC | --- | --- |
# MAGIC | item\_prior\_lines | Count of prior order lines for this item |
# MAGIC | item\_prior\_avg\_backorder | Expanding mean of backorder\_qty on prior lines |
# MAGIC | item\_prior\_max\_backorder | Expanding max of backorder\_qty on prior lines |
# MAGIC | item\_prior\_avg\_price | Expanding mean of extended\_price on prior lines |
# MAGIC | item\_last5\_avg\_backorder | Rolling mean of backorder\_qty over the last 5 lines |
# MAGIC | item\_last5\_avg\_onhand | Rolling mean of on\_hand\_qty over the last 5 lines |
# MAGIC
# MAGIC **Customer History (series = customer\_number):**
# MAGIC
# MAGIC | Feature | Description |
# MAGIC | --- | --- |
# MAGIC | cust\_prior\_lines | Count of prior order lines for this customer |
# MAGIC | cust\_prior\_avg\_backorder | Expanding mean of backorder\_qty for this customer |
# MAGIC
# MAGIC ### 3.3 Warehouse Encoding
# MAGIC
# MAGIC `warehouse` is one-hot encoded into binary flags (`wh_WH1`, `wh_WH2`, `wh_WH3`, `wh_other`). The raw column is dropped. One-hot encoding is used instead of native categorical treatment because pandas Categorical columns cannot cross an HTTP boundary — JSON has no category dtype, causing LightGBM to reject payloads at serving time.
# MAGIC
# MAGIC ### 3.4 Calendar Features (Derived from order\_date)
# MAGIC
# MAGIC | Feature | Description |
# MAGIC | --- | --- |
# MAGIC | year | Calendar year |
# MAGIC | month | Month of year (1–12) |
# MAGIC | quarter | Financial quarter (1–4) |
# MAGIC | week\_of\_year | ISO week number |
# MAGIC | day\_of\_week | Day of week (0=Monday) |
# MAGIC | days\_from\_start | Days since the earliest order in the dataset |
# MAGIC
# MAGIC ### 3.5 Excluded Columns (Leakage Prevention)
# MAGIC
# MAGIC Columns excluded from the feature matrix fall into three categories:
# MAGIC
# MAGIC * **Label leakage** — columns the labelling CASE statement reads: `available_qty`, `on_order_qty`, `in_transit_qty`, `next_expected_receipt`, `supply_gap_qty`, `days_until_fulfillment`
# MAGIC * **No modelling value** — free-text duplicates (`item_description`, `customer_name`), supply-side dates (`next_expected_delivery`), CURRENT\_DATE-relative values (`estimated_delivery_date`, `days_overdue`)
# MAGIC * **Bookkeeping** — `snapshot_date`, `row_seq`
# MAGIC
# MAGIC ### 3.6 Output Tables
# MAGIC
# MAGIC | Table | Description |
# MAGIC | --- | --- |
# MAGIC | `dev_platform.mlops.fulfillment_risk_features` | Training feature table (\~3,500 rows, 28 columns) |
# MAGIC | `dev_platform.mlops.fulfillment_risk_truth` | Training labels (`risk_level_encoded`), joined on `order_number` + `item_number` |
# MAGIC | `dev_platform.mlops.fulfillment_risk_validation_features` | Held-out validation features (same schema, separate time window) |
# MAGIC | `dev_platform.mlops.fulfillment_risk_validation_truth` | Validation labels |
# MAGIC
# MAGIC Validation features borrow history from the training table (via `history_tables`) so each validation row sees the prior orders for its item, exactly as it would in production.

# COMMAND ----------

# DBTITLE 1,Model Selection
# MAGIC %md
# MAGIC ## 4. Model Selection: Tree-Based Ensembles
# MAGIC
# MAGIC For tabular data containing a mix of continuous numeric features (quantities, prices, lead times) and low-cardinality binary indicators (warehouse flags), gradient boosted trees are the optimal choice for multi-class classification.
# MAGIC
# MAGIC ### 4.1 Candidate Models
# MAGIC
# MAGIC 1. **XGBoost** (Primary) — Multi-class soft probability objective (`multi:softprob`). Advanced regularization (gamma, L1/L2) prevents overfitting on the \~3,500-row training set. Natively handles missing values from first-order items with no history.
# MAGIC
# MAGIC 2. **LightGBM** (Alternative) — Histogram-based learning for faster training. Uses `class_weight="balanced"` to counteract the class imbalance inherent in risk categories (High-risk orders are the rarest but most valuable to predict).
# MAGIC
# MAGIC 3. **CatBoost** (Alternative) — Built-in handling of class imbalance via `auto_class_weights="Balanced"`. Ordered boosting reduces overfitting on small datasets.
# MAGIC
# MAGIC ### 4.2 Hyperparameter Optimization
# MAGIC
# MAGIC | Setting | Value |
# MAGIC | --- | --- |
# MAGIC | Framework | Optuna (Bayesian TPE) |
# MAGIC | Trials per model | 20 |
# MAGIC | Pruner | MedianPruner (startup=5) |
# MAGIC | Cross-validation | Rolling time-based, 2 splits |
# MAGIC | Validation window | 4 weeks per split, 2-week step |
# MAGIC | Min test rows | 100 per window |
# MAGIC | Split weighting | 0.3 (oldest) to 1.0 (newest) |
# MAGIC
# MAGIC ### 4.3 Selection Criteria
# MAGIC
# MAGIC The production model is selected through empirical evaluation. All candidates are trained and evaluated using the same historical fulfillment data.
# MAGIC
# MAGIC **Primary Metric: F1 Macro** — chosen because the High-risk class is the most operationally valuable to detect and also the rarest. Accuracy would hide poor recall on this minority class; F1 Macro gives equal weight to every class regardless of frequency.
# MAGIC
# MAGIC **Additional Evaluation Metrics:**
# MAGIC
# MAGIC | Metric | Purpose |
# MAGIC | --- | --- |
# MAGIC | Balanced Accuracy | Overall per-class accuracy, corrected for imbalance |
# MAGIC | Accuracy | Standard accuracy (for reference) |
# MAGIC | Precision Macro | Average per-class precision |
# MAGIC | Recall Macro | Average per-class recall |
# MAGIC | Log Loss | Calibration of probability estimates |
# MAGIC
# MAGIC The selected production model will be the candidate that provides the best balance of predictive performance across all risk classes, with emphasis on correctly identifying High-risk orders.

# COMMAND ----------

# DBTITLE 1,MLOps Pipeline and Deployment
# MAGIC %md
# MAGIC ## 5. MLOps Pipeline & Deployment
# MAGIC
# MAGIC This section describes how the fulfillment risk classification solution is operationalized on the Databricks Lakehouse Platform.
# MAGIC
# MAGIC ### 5.1 Pipeline Architecture
# MAGIC
# MAGIC ```
# MAGIC features ─▶ train ─[review]─▶ register ─[status]─▶ serve
# MAGIC                                   │
# MAGIC                 score ─▶ monitor ─┴─▶ drift / degradation ─[approve]─▶ rollback
# MAGIC ```
# MAGIC
# MAGIC Stages never chain on their own. The three that change shared state — `register`, `serve`, `rollback` — require explicit `approved=True`. This design ensures a model that wins on F1 Macro by a small margin is not automatically put in front of production traffic without human review.
# MAGIC
# MAGIC ### 5.2 Configuration Architecture
# MAGIC
# MAGIC All configuration is centralized in three files under `src/config/`:
# MAGIC
# MAGIC | File | Scope |
# MAGIC | --- | --- |
# MAGIC | `mlops_config.py` | Shared facts (tables, columns, experiment, model), training splits/search, registration thresholds, serving endpoint |
# MAGIC | `feature_config.py` | Feature engineering: passthrough columns, point-in-time specs, one-hot encoding, calendar features, output tables |
# MAGIC | `monitoring_config.py` | Batch inference, Lakehouse monitor, drift thresholds, rollback rules, alerting |
# MAGIC
# MAGIC Each fact is stated ONCE and derived everywhere else. The same `drop_cols` list used during training is used during scoring, making a schema mismatch between the model signature and the serving input structurally impossible.

# COMMAND ----------

# DBTITLE 1,Feature Engineering and Model Training
# MAGIC %md
# MAGIC ### 5.3 Feature Engineering & Model Training
# MAGIC
# MAGIC Engineered features (Section 3) are materialized into governed Delta tables and written as plain Delta overwrites. A changed feature set replaces the table outright, ensuring no stale columns persist.
# MAGIC
# MAGIC Training workflows are orchestrated through the `run_mlops_notebook` notebook, with MLflow Tracking capturing:
# MAGIC
# MAGIC * Model parameters and hyperparameters
# MAGIC * Training artifacts (model binaries)
# MAGIC * Evaluation metrics (F1 Macro, Balanced Accuracy, Precision, Recall, Log Loss)
# MAGIC * Experiment history and reproducibility information
# MAGIC * Feature importance rankings (top 30)
# MAGIC * Prediction CSVs with identifier columns
# MAGIC
# MAGIC **Training Workflow:**
# MAGIC
# MAGIC 1. Curated feature datasets are refreshed and validated via `stage_features()`
# MAGIC 2. Optuna HPO runs 20 trials per model (XGBoost, LightGBM, CatBoost) via `stage_train()`
# MAGIC 3. Best model is refitted on the full training set and logged to MLflow
# MAGIC 4. Candidate performance is reviewed against the incumbent Champion via `stage_review()`
# MAGIC
# MAGIC **Training Configuration:**
# MAGIC
# MAGIC | Parameter | Value |
# MAGIC | --- | --- |
# MAGIC | Experiment Path | `/Workspace/Users/danduprolu.stuthi@latentview.com/fulfillment_risk-1` |
# MAGIC | Feature Table | `dev_platform.mlops.fulfillment_risk_features` |
# MAGIC | Truth Table | `dev_platform.mlops.fulfillment_risk_truth` |
# MAGIC | Join Keys | `order_number`, `item_number` |
# MAGIC | Target Column | `risk_level_encoded` |
# MAGIC | Dropped Columns | `order_number`, `item_number`, `customer_number`, `order_date`, `risk_level` |
# MAGIC
# MAGIC **Training Failure Runbook:**
# MAGIC
# MAGIC | Failure Mode | Likely Cause | Resolution |
# MAGIC | --- | --- | --- |
# MAGIC | Training workflow fails before completion | Data quality issues, resource constraints, dependency conflicts | Review workflow logs, validate feature datasets, verify cluster resources |
# MAGIC | Training completes but evaluation results are unavailable | MLflow tracking or logging issues | Validate tracking configuration and rerun training |
# MAGIC | Training exceeds expected execution duration | Resource limitations or inefficient HPO configuration | Review compute sizing and reduce n\_trials |
# MAGIC | Schema mismatch at predict time | drop\_cols divergence between training and scoring | Verify both derive from `SharedConfig.drop_cols` |
# MAGIC
# MAGIC **Runbook Steps:**
# MAGIC
# MAGIC 1. Training workflow failure generates an operational alert
# MAGIC 2. ML Engineering reviews workflow execution details and supporting logs
# MAGIC 3. Root cause is classified as data, infrastructure, configuration, or code related
# MAGIC 4. Appropriate remediation is applied
# MAGIC 5. Training workflow is re-executed
# MAGIC 6. Successful model registration and evaluation results are verified
# MAGIC 7. Existing production model remains available throughout the recovery process

# COMMAND ----------

# DBTITLE 1,Model Registry and Governance
# MAGIC %md
# MAGIC ### 5.4 Model Registry & Governance
# MAGIC
# MAGIC Approved models are managed through the Unity Catalog Model Registry at `dev_platform.mlops.fulfillment_risk_model_1`, providing centralized governance, lineage tracking, version management, auditability, and access control.
# MAGIC
# MAGIC A **Champion-Challenger** evaluation strategy compares newly trained candidate models against the currently approved production model.
# MAGIC
# MAGIC **Registration Configuration:**
# MAGIC
# MAGIC | Parameter | Value |
# MAGIC | --- | --- |
# MAGIC | UC Model Name | `dev_platform.mlops.fulfillment_risk_model_1` |
# MAGIC | Comparison Metric | `best_weighted_mean_f1_macro` |
# MAGIC | Metric Direction | Maximize |
# MAGIC | Improvement Threshold | 0% (any improvement qualifies) |
# MAGIC | Champion Alias | `champion` |
# MAGIC | Challenger Alias | `challenger` |
# MAGIC | Run Filter | `tags.stage = 'best_model_refit'` |
# MAGIC | Baseline Window | Anchored, 6 months, min 100 rows |
# MAGIC | Tags | `use_case: fulfillment_risk`, `task: classification` |
# MAGIC
# MAGIC **Promotion Process:**
# MAGIC
# MAGIC 1. The candidate model is registered following successful training via `stage_register(approved=True)`
# MAGIC 2. Automated evaluation compares candidate F1 Macro against the Champion's logged metric
# MAGIC 3. If the candidate matches or improves on the Champion, it becomes the new Champion
# MAGIC 4. Previous Champion is demoted to Challenger (available for rollback)
# MAGIC 5. Metrics from the winning run are copied as UC version tags for auditability
# MAGIC
# MAGIC **Governance Benefits:**
# MAGIC
# MAGIC * End-to-end lineage from feature table to served endpoint
# MAGIC * Version control with alias-based promotion
# MAGIC * Audit trail via metric tags on every registered version
# MAGIC * Controlled promotion requiring explicit approval
# MAGIC * Rapid rollback by reassigning aliases

# COMMAND ----------

# DBTITLE 1,Model Serving and Business Integration
# MAGIC %md
# MAGIC ### 5.5 Model Serving & Business Integration
# MAGIC
# MAGIC Approved models are deployed through Databricks Model Serving to provide real-time prediction capabilities for downstream business applications.
# MAGIC
# MAGIC **Serving Configuration:**
# MAGIC
# MAGIC | Parameter | Value |
# MAGIC | --- | --- |
# MAGIC | Endpoint Name | `fulfillment-risk-endpoint` |
# MAGIC | Served Entity | `dev_platform.mlops.fulfillment_risk_model_1@champion` |
# MAGIC | Workload Size | Small (CPU) |
# MAGIC | Scale to Zero | Enabled |
# MAGIC | Traffic Split | 100% to Champion |
# MAGIC | Wait Timeout | 30 minutes |
# MAGIC | Tags | `use_case: fulfillment_risk`, `owner: mlops` |
# MAGIC
# MAGIC **AI Gateway Configuration:**
# MAGIC
# MAGIC | Setting | Value |
# MAGIC | --- | --- |
# MAGIC | Usage Tracking | Enabled |
# MAGIC | Inference Table | `dev_platform.mlops.fulfillment_risk_serving_1` |
# MAGIC | Rate Limit (endpoint) | 1,000 requests/minute |
# MAGIC | Rate Limit (per user) | 100 requests/minute |
# MAGIC
# MAGIC **Operational Objectives:**
# MAGIC
# MAGIC * Real-time classification of order lines into risk categories
# MAGIC * Secure API-based integration with ERP/WMS systems
# MAGIC * Autoscaling infrastructure (scale-to-zero for cost optimization)
# MAGIC * High availability and resiliency
# MAGIC * Centralized monitoring via inference tables and usage tracking
# MAGIC
# MAGIC **Business Response Workflow:**
# MAGIC
# MAGIC 1. Order line information is submitted to the prediction endpoint
# MAGIC 2. The model classifies the line into one of four risk categories
# MAGIC 3. High-risk predictions ("No Supply Visibility") trigger predefined workflows and notifications
# MAGIC 4. Warehouse operations teams gain proactive visibility into fulfillment risk
# MAGIC 5. Procurement teams can initiate expedited sourcing for high-risk items
# MAGIC
# MAGIC **Endpoint Failure Runbook:**
# MAGIC
# MAGIC | Failure Mode | Detection | Resolution |
# MAGIC | --- | --- | --- |
# MAGIC | Prediction service errors | Monitoring alerts and application logs | Review serving logs, validate request payloads, verify deployment configuration |
# MAGIC | Latency degradation | Monitoring dashboards and operational alerts | Review infrastructure utilization, autoscaling behavior, and serving configuration |
# MAGIC | Endpoint unavailable | Health checks, application timeouts, or user reports | Review platform health and execute recovery procedures |
# MAGIC | Unexpected prediction failures | Application logs or user reports | Validate model deployment, configuration, and request schema |
# MAGIC
# MAGIC **Runbook Steps:**
# MAGIC
# MAGIC 1. Operational alert is generated through monitoring systems
# MAGIC 2. ML Engineering reviews endpoint health, deployment history, and operational metrics
# MAGIC 3. If a recent deployment or model change is the likely cause, rollback procedures are initiated
# MAGIC 4. Infrastructure-related issues are escalated to Platform Operations
# MAGIC 5. Service availability and functionality are validated following remediation
# MAGIC 6. Root cause analysis is completed and documented

# COMMAND ----------

# DBTITLE 1,Monitoring and Drift Detection
# MAGIC %md
# MAGIC ### 5.6 Monitoring & Drift Detection
# MAGIC
# MAGIC Prediction requests and outcomes are monitored to ensure the model continues to perform effectively as order patterns, inventory levels, and fulfillment processes evolve.
# MAGIC
# MAGIC **Monitoring Architecture:**
# MAGIC
# MAGIC Batch scoring runs against the held-out validation features via the serving endpoint (not local model loading), so the monitored predictions are the ones production actually returns.
# MAGIC
# MAGIC | Parameter | Value |
# MAGIC | --- | --- |
# MAGIC | Scoring Mode | `endpoint` (HTTP to serving endpoint) |
# MAGIC | Feature Table (scoring) | `dev_platform.mlops.fulfillment_risk_validation_features` |
# MAGIC | Truth Table (scoring) | `dev_platform.mlops.fulfillment_risk_validation_truth` |
# MAGIC | Inference Table | `dev_platform.mlops.fulfillment_risk_predictions` |
# MAGIC | Merge Keys | `order_number`, `item_number` |
# MAGIC | Time Column | `order_date` (business date, not scoring timestamp) |
# MAGIC | Endpoint Batch Size | 100 rows per HTTP request |
# MAGIC
# MAGIC **Lakehouse Monitor Configuration:**
# MAGIC
# MAGIC | Parameter | Value |
# MAGIC | --- | --- |
# MAGIC | Problem Type | Classification |
# MAGIC | Granularity | 1 day |
# MAGIC | Monitor Time Basis | Event (order\_date) |
# MAGIC | Prediction Column | `prediction_final` |
# MAGIC | Label Column | `risk_level_encoded` |
# MAGIC | Baseline Table | `dev_platform.mlops.fulfillment_risk_model_1_baseline` |
# MAGIC | Output Schema | `dev_platform.mlops` |
# MAGIC | Assets Directory | `/Workspace/Users/danduprolu.stuthi@latentview.com/monitoring_assets` |
# MAGIC
# MAGIC Using `order_date` as the monitor time basis (instead of `prediction_timestamp`) spreads rows across real business periods. A backfill stamps every row with the same `prediction_timestamp`, which would collapse all rows into one window and make drift measurement impossible.
# MAGIC
# MAGIC **Monitoring Areas:**
# MAGIC
# MAGIC | Category | Purpose |
# MAGIC | --- | --- |
# MAGIC | Data Drift | Detect changes in incoming feature distributions |
# MAGIC | Feature Drift | Detect shifts in individual feature values vs. baseline |
# MAGIC | Model Performance | Monitor F1 score and classification accuracy over time |
# MAGIC | Prediction Volume | Monitor usage trends and serving load |
# MAGIC | Latency & Availability | Monitor endpoint reliability via AI Gateway |
# MAGIC | Data Quality | Monitor completeness, validity, and consistency of inputs |
# MAGIC
# MAGIC **Drift Detection Configuration:**
# MAGIC
# MAGIC | Parameter | Value |
# MAGIC | --- | --- |
# MAGIC | Drift Table | `dev_platform.mlops.fulfillment_risk_predictions_drift_metrics` |
# MAGIC | KS p-value Threshold | 0.05 |
# MAGIC | Chi-squared p-value Threshold | 0.05 |
# MAGIC | Min Drifted Columns | 5 |
# MAGIC | Excluded from Drift | `:table`, join keys, model outputs, prediction\_timestamp, prediction\_final, risk\_level\_encoded, order\_date |
# MAGIC
# MAGIC **Drift Response Runbook:**
# MAGIC
# MAGIC 1. Monitoring alerts identify potential drift, performance degradation, or data quality concerns
# MAGIC 2. Impacted features, business processes, and prediction outcomes are reviewed
# MAGIC 3. Operational impact is assessed (drift alone is a reason to investigate, not to roll back)
# MAGIC 4. Retraining workflows may be initiated when required
# MAGIC 5. Newly trained models are evaluated and validated
# MAGIC 6. Governance and approval processes are completed
# MAGIC 7. Promotion occurs only after validation criteria are satisfied

# COMMAND ----------

# DBTITLE 1,Retraining Strategy and Rollback
# MAGIC %md
# MAGIC ### 5.7 Retraining Strategy & Operational Recovery
# MAGIC
# MAGIC Retraining ensures the model continues to reflect current fulfillment patterns, inventory dynamics, and operational processes.
# MAGIC
# MAGIC **Degradation Detection:**
# MAGIC
# MAGIC | Parameter | Value |
# MAGIC | --- | --- |
# MAGIC | Monitor Metric | `f1_score` |
# MAGIC | Training Metric | `best_weighted_mean_f1_macro` |
# MAGIC | Metric Direction | Lower is better (a falling F1 is degradation) |
# MAGIC | Degradation Threshold | 20% worsening vs. Champion's training metric |
# MAGIC | Consecutive Windows Required | 3 (one bad window is usually noise) |
# MAGIC | Settling Period After Rollback | 24 hours |
# MAGIC
# MAGIC **Trigger Categories:**
# MAGIC
# MAGIC | Trigger | Action |
# MAGIC | --- | --- |
# MAGIC | Scheduled retraining cycle | Execute retraining workflow using the latest approved datasets |
# MAGIC | Drift detection event | Initiate retraining and model evaluation process |
# MAGIC | Model performance degradation | Review model performance; if 3 consecutive windows breach the 20% threshold, initiate rollback review |
# MAGIC | Production serving incident | Execute rollback and recovery procedures |
# MAGIC
# MAGIC **Rollback Procedure (`stage_rollback`):**
# MAGIC
# MAGIC 1. Identify the current Champion and Challenger model versions
# MAGIC 2. Promote the Challenger to Champion (swap aliases)
# MAGIC 3. Demote the previous Champion to Challenger, keeping it available for re-promotion
# MAGIC 4. Validate endpoint health and prediction behavior
# MAGIC 5. Confirm restoration of expected service levels
# MAGIC 6. Document incident findings, root cause, and corrective actions
# MAGIC
# MAGIC Rollback requires `approved=True` and uses the `dev_platform.mlops.mlops_pipeline_control` table to record events and enforce the 24-hour settling window. The settling window prevents a fresh Champion from being judged on windows produced by its predecessor, which would cause an infinite rollback loop.
# MAGIC
# MAGIC **Alerting Configuration:**
# MAGIC
# MAGIC | Parameter | Value |
# MAGIC | --- | --- |
# MAGIC | Enabled | False (configurable) |
# MAGIC | Recipients | `danduprolu.stuthi@latentview.com` |
# MAGIC | Subject Prefix | `[MLOps][fulfillment_risk]` |

# COMMAND ----------

# DBTITLE 1,Environment Promotion Flow
# MAGIC %md
# MAGIC ### 5.8 Environment Promotion Flow
# MAGIC
# MAGIC Environment promotion governs how machine learning code, workflows, configurations, and infrastructure changes move through the software delivery lifecycle. This process is distinct from model promotion, which governs how approved models move through validation and production approval workflows.
# MAGIC
# MAGIC | Environment | Purpose |
# MAGIC | --- | --- |
# MAGIC | Development | Model development, experimentation, feature engineering, and hyperparameter tuning |
# MAGIC | Production | Live business operations and prediction serving |
# MAGIC
# MAGIC **Current Deployment:**
# MAGIC
# MAGIC | Component | Location |
# MAGIC | --- | --- |
# MAGIC | Catalog | `dev_platform` |
# MAGIC | Schema | `mlops` |
# MAGIC | Pipeline Code | `/Workspace/Users/danduprolu.stuthi@latentview.com/mlops_pipeline/` |
# MAGIC | Experiment | `/Workspace/Users/danduprolu.stuthi@latentview.com/fulfillment_risk-1` |
# MAGIC | Monitoring Assets | `/Workspace/Users/danduprolu.stuthi@latentview.com/monitoring_assets` |
# MAGIC
# MAGIC **Promotion Flow:**
# MAGIC
# MAGIC 1. Pipeline code, workflow definitions, and infrastructure configurations are maintained in the workspace
# MAGIC 2. Changes are developed and validated within the Development environment
# MAGIC 3. Testing and validation activities are completed prior to deployment
# MAGIC 4. Following successful validation and approval, changes are promoted to Production through standardized deployment processes
# MAGIC 5. Model promotion governance operates independently from environment promotion governance
# MAGIC
# MAGIC **Ownership:**
# MAGIC
# MAGIC * ML Engineering owns model development, deployment pipelines, and operational processes
# MAGIC * Production deployments require formal review and approval in accordance with organizational change-management procedures