"""
mlops_process_job.py — Lakeflow Job entry point (Python script task)
--------------------------------------------------------------------
Notebook equivalent: sections 1-3 (train, review, register, status, serve).

Inputs: src/config/job_config.py -> JOBS["mlops_process"]
        (use case, stages, approve_register / approve_serve), and
        src/config/mlops_config.py (models, search space, registry, endpoint).
No job parameters are needed. register and serve only act when their
approve_* flag is True; otherwise they log what they would do.
"""
import logging
import os
import sys


def _project_root() -> str:
    """The mlops_pipeline folder: the first parent that contains src/config."""
    try:
        start = os.path.dirname(os.path.abspath(__file__))
    except NameError:          # some task runners do not define __file__
        start = os.getcwd()
    d = start
    while True:
        if os.path.isdir(os.path.join(d, "src", "config")):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            raise RuntimeError(f"Could not find the project root above {start}")
        d = parent


ROOT = _project_root()
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
                    datefmt="%Y-%m-%d %H:%M:%S")

from src.jobs.bootstrap import ensure_requirements  # noqa: E402
ensure_requirements(ROOT)

from src.jobs.runner import run_mlops_process_job  # noqa: E402


if __name__ == "__main__":
    run_mlops_process_job()
