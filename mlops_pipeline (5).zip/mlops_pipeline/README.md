# MLOps pipeline — complete reference

Every file, every config field, and why each piece exists.

---

## 1. The flow

```
                    ┌─────────────────────────────────────────┐
                    │  src/config/  — all decisions live here │
                    └─────────────────────────────────────────┘
                                      │
   feature_config ──▶ mlops_config ──▶ monitoring_config
         │                  │                   │
         ▼                  ▼                   ▼
    ┌─────────┐      ┌──────────┐        ┌────────────┐
    │features │─────▶│  train   │        │   score    │
    └─────────┘      └──────────┘        └────────────┘
                           │                    │
                      [GATE: review]            ▼
                           │              ┌────────────┐
                           ▼              │  monitor   │
                     ┌──────────┐         └────────────┘
                     │ register │               │
                     └──────────┘      ┌────────┴────────┐
                           │           ▼                 ▼
                      [GATE: status]  drift         degradation
                           │                             │
                           ▼                      [GATE: approve]
                     ┌──────────┐                        │
                     │  serve   │                        ▼
                     └──────────┘                  ┌──────────┐
                                                   │ rollback │
                                                   └──────────┘
```

Nothing advances on its own. Three stages change shared state and refuse to run
without `--approve`: **register**, **serve**, **rollback**.

Why gates: a model that beats the Champion by 0.3 days of MAE is not
automatically one you want taking production traffic. The decision to promote
and the decision to roll out are different decisions, made by a person.

---

## 2. Layout

```
README.md
requirements.txt
run_mlops_notebook.py              Databricks driver, all stages as cells
src/
  pipeline.py                      stage orchestration + approval gates
  config/
    feature_config.py              feature engineering
    mlops_config.py                training / registration / serving
    monitoring_config.py           scoring / monitoring / drift / rollback
  feature_engineering/
    build_features.py
  training/
    model_training.py
  model_registration/
    model_registration.py
    promotion_functions.py
    model_formats.py
  serving/
    endpoint_manager.py
  monitoring/
    batch_inference.py
    lakehouse_monitor.py
    check_drift.py
    check_rollback.py
    rollback.py
    common.py
  utils/
    retry.py
```

## 3. Files

### Config — the only files you edit

| File | Decides |
|---|---|
| `src/config/feature_config.py` | How raw rows become features |
| `src/config/mlops_config.py` | Training, registration, serving |
| `src/config/monitoring_config.py` | Scoring, monitoring, drift, rollback |

### Code — reads config, you rarely touch

| File | Does |
|---|---|
| `src/pipeline.py` | Orchestrates the stages and enforces the gates |
| `src/feature_engineering/build_features.py` | Builds and writes the feature set |
| `src/training/model_training.py` | Optuna search with rolling time validation |
| `src/model_registration/model_registration.py` | Champion/Challenger registration + baseline |
| `src/model_registration/promotion_functions.py` | The alias mechanics |
| `src/model_registration/model_formats.py` | `.pkl`/`.ubj`/`.cb`/... → MLflow flavor |
| `src/serving/endpoint_manager.py` | Serving endpoint + AI Gateway |
| `src/monitoring/batch_inference.py` | Scores the Champion over new periods |
| `src/monitoring/lakehouse_monitor.py` | Creates/refreshes the quality monitor |
| `src/monitoring/check_drift.py` | Have the inputs moved? |
| `src/monitoring/check_rollback.py` | Has live error actually worsened? |
| `src/monitoring/rollback.py` | Promotes the Challenger (gated) |
| `src/monitoring/common.py` | Model state, control table, alerts |
| `src/utils/retry.py` | Retries transient API failures only |

---

## 4. feature_config.py

Turns raw transactional rows into a modelling table.

### `AggregationSpec` — one output column

```python
AggregationSpec("target_qty", "order_qty", "sum")
#                └ output     └ source     └ sum|mean|min|max|std|count|nunique|share_of
```

`share_of` is special — it counts rows where the column equals a value:

```python
AggregationSpec("consumer_orders", "cust_segment", "share_of", equals="Consumer")
```

### `LagSpec` — values from earlier periods

```python
LagSpec("target_qty", [1, 2, 3, 4, 8, 12], prefix="lag")   # -> lag_1 ... lag_12
```

Lags are computed **within a series** (`series_cols`), so a product's lag never
pulls a value from a different product.

### `RollingSpec` — rolling statistics

```python
RollingSpec("target_qty", windows=[4, 8], stats=["mean", "std"], prefix="target")
# -> target_rolling_mean_4, target_rolling_mean_8, target_rolling_std_4, ...
```

**Always shifted by one period before the window is applied.** Without that
shift, a row's own target is inside its own rolling mean — the model sees the
answer and the metrics look excellent until production. Verified by test.

### Grain vs series

```python
group_cols  = ["product", "category", "department", "country", "state"]  # one output row
series_cols = ["product", "country", "state"]                            # one time series
```

`series_cols` must be a subset of `group_cols` — a series is a slice of the
grain. Note the consequence: with the values above, lags cross category and
department boundaries within a product. That was the original behaviour; keep
it only if it is intended.

### Where things land

```python
feature_store = FeatureStoreSpec(table_name=..., primary_keys=[...])
target_table  = TargetTableSpec(table_name=..., target_col=..., merge_keys=[...])
```

Features and label go to **separate tables**. The label is only known after the
fact, and keeping it out of the feature table is what stops it being fed back
in as a feature at scoring time.

### Other fields

| Field | Meaning |
|---|---|
| `freq` | Pandas offset alias — `"W-MON"` = weeks starting Monday |
| `out_time_column` | Name the resampled period gets (`"week"`) — **created**, not read |
| `max_source_date` | Rows on/after this are held out |
| `ratios` | `{"consumer_pct": ("consumer_orders", "total_orders")}` |
| `drop_ratio_numerators` | Drop the raw counts once the ratio exists |
| `dropna` | Drop rows with no lag history (the first periods of each series) |

---

## 5. mlops_config.py

One `SharedConfig` per use case; training, registration and serving each derive
their own view of it.

### Why derived

These three facts used to live in three files and drift apart:

| Fact | Used by | Broke as |
|---|---|---|
| experiment path | train writes, register reads | register found the wrong experiment |
| `drop_cols` | train fits, scoring excludes | model signature ≠ scoring frame |
| metric name | train logs, register selects | register picked a run with no model |

Now stated once:

```python
training_config(name)       -> TrainingConfig      # .data.drop_cols
registration_pipeline(name) -> PipelineConfig      # .tables.exclude_from_features
serving_config(name)        -> ServingConfig       # .served_models[0].model_name
```

`registration_metric_key()` derives `best_weighted_mean_<primary_metric>` —
change `primary_metric` to `"rmse"` and registration follows automatically.

### SharedConfig fields

| Field | Meaning |
|---|---|
| `experiment_path` | `/Workspace/...` — the path, not the browser URL |
| `model_name` | UC name without catalog.schema |
| `feature_table` / `target_table` | Inputs; `target_table=None` means the label is already in features |
| `join_keys` | How the two are joined |
| `date_column` | A **real** DATE/TIMESTAMP column |
| `drop_cols` | Excluded at training **and** scoring — the critical pairing |
| `cat_cols` | Treated as categoricals (see §9 for the cost) |
| `numeric_cols` | Force-cast to numeric — Spark DECIMAL arrives as `Decimal` objects |

### Registration stage

| Field | Meaning |
|---|---|
| `improvement_threshold` | `0.02` = must be 2% better to unseat the Champion |
| `run_filter` | `tags.stage = 'best_model_refit'` — skips nested trials |
| `test_months` | Baseline window length |
| `baseline_window_mode` | `"anchored"` walks back to find enough rows; `"fixed"` uses the last N months |
| `min_baseline_rows` | Below this a reference distribution is not usable |

---

## 6. monitoring_config.py

### Derived from `mlops_config`, not retyped

`from_use_case("delay_days", ...)` builds a whole `MonitoringConfig` from
`SharedConfig`. These come across automatically and therefore cannot disagree
with training:

| Taken from SharedConfig | Why it must match |
|---|---|
| `feature_table` | scoring must read what training read |
| `catalog` / `schema` / `model_name` | must address the registered model |
| `target_col` → `label_col` | the monitor needs the real outcome |
| `join_keys` → `merge_keys` | the grain of one prediction |
| `drop_cols` → `exclude_from_features` | scoring frame must match the signature |
| `primary_metric` → `training_metric` | `best_weighted_mean_<metric>` |

Only monitoring-specific values are passed in: where predictions and metric
tables live, the assets dir, and the thresholds.

`feature_config.outputs_from_use_case()` does the same in the other direction —
the feature job WRITES the tables training READS, so it takes both names from
the same place.

### `LakehouseMonitorConfig` — one field matters more than the rest

```python
prediction_col = "prediction_final"
label_col      = "target_qty"        # the ACTUAL outcome
```

The original set both to `"prediction_final"`. The monitor then compares
predictions against themselves, every error metric is zero, and
`check_rollback` — which reads those metrics — can never detect degradation.
Config now rejects it.

### `DriftConfig`

| Field | Meaning |
|---|---|
| `ks_pvalue_threshold` | Numeric columns; below this = drifted |
| `chi_pvalue_threshold` | Categorical columns |
| `min_drifted_columns` | How many before it counts (was hardcoded `> 4`) |
| `exclude_columns` | IDs, outputs, timestamps — never drift signals |

### `RollbackThresholds`

| Field | Meaning |
|---|---|
| `metric_pct_increase` | `0.20` = 20% worse than training |
| `consecutive_windows` | Breaches in a row before flagging — one bad window is noise |
| `settling_hours` | Quiet period after a rollback |
| `monitor_metric` | What the monitor computes (`mean_absolute_error`) |
| `training_metric` | What the Champion's run logged (`best_weighted_mean_mae`) |

The last two are different names for the same quantity, measured in different
places. Both must exist or degradation can't be evaluated.

### The settling window

After a rollback, recent metric windows were produced by the **previous**
Champion. Judging the new one on them would immediately flag it as degraded and
roll back again. `rollback.py` writes to `control_table`; the checks read it and
skip while inside the window.

---

## 7. Stage reference

| Stage | Reads | Writes | Gated |
|---|---|---|---|
| `features` | source table | feature + target tables | no |
| `train` | feature + target | MLflow runs | no |
| `review` | MLflow runs | nothing | — |
| `register` | best run | UC model version, alias, baseline | **yes** |
| `status` | registry + endpoint | nothing | — |
| `serve` | UC model | serving endpoint | **yes** |
| `score` | features + Champion | inference table | no |
| `monitor` | inference table | profile + drift tables | no |
| `drift` | drift table | alert | no |
| `degradation` | profile table | alert | no |
| `rollback` | registry | aliases + control table | **yes** |

---

## 8. Run order

```bash
python -m src.pipeline features    --feature_set weekly_orders --dry_run
python -m src.pipeline features    --feature_set weekly_orders
python -m src.pipeline train       --use_case delay_days
python -m src.pipeline review      --use_case delay_days
python -m src.pipeline register    --use_case delay_days --approve
python -m src.pipeline status      --use_case delay_days
python -m src.pipeline serve       --use_case delay_days --approve
```

Then on a schedule:

```bash
python -m src.pipeline score       --monitor_name weekly_orders
python -m src.pipeline monitor     --monitor_name weekly_orders
python -m src.pipeline drift       --monitor_name weekly_orders
python -m src.pipeline degradation --monitor_name weekly_orders
```

---

## 9. Non-obvious mechanics

**MLflow 3 logged models.** A model may not appear under `list_artifacts(run_id)`.
It is a LoggedModel entity on `run.outputs.model_outputs`, addressed as
`models:/<model_id>`. Detection checks both.

**Server-side `order_by` does not filter.** Sorting runs on a metric does not
exclude runs lacking it — that is how a failed nested trial got selected.
Ranking is client-side, filtered to `FINISHED` runs that have the metric.

**Serving pins a version.** Aliases are resolved at deploy time. Moving the
Champion alias does **not** move the endpoint until you redeploy. `status`
warns when they differ. This is deliberate.

**Drift ≠ degradation.** Drift means the inputs moved. Degradation means
accuracy fell. Inputs can shift without hurting accuracy, and accuracy can fall
with no input drift. Separate checks, separate evidence.

**Rollback is reversible.** The demoted Champion becomes the Challenger, so a
bad rollback can be undone. The original deleted the challenger alias and left
the old Champion unreferenced — a one-way door.

---

## 10. Known trade-offs

**`cat_cols` costs more than it looks.** Pandas Categorical columns make
LightGBM store category lists that must match exactly at scoring time, and
XGBoost encode by position with no recoverable mapping. Scoring handles
LightGBM; XGBoost-with-categoricals cannot be fixed at scoring time and raises
explicitly. If the table is already encoded, leave `cat_cols` empty.

**Anchored baselines are older.** When recent data is sparse, the window moves
back to find enough rows. You get a usable reference describing an older
period. If volume is genuinely low, drift detection will be noisy whatever you
choose.

**Alerts log but do not send** unless `webhook_url` is set. Email recipients are
recorded but no SMTP transport is assumed — wire `common.send_alert` to your
relay.


---

## 11. Install

```bash
pip install -r requirements.txt
```

On Databricks, in the first notebook cell:

```python
%pip install -r /Workspace/Users/<you>/lv-mlops-demo/requirements.txt
dbutils.library.restartPython()
```

`dbutils.library.restartPython()` clears the module cache as well as installing.
That matters: editing a config file and re-running without a restart leaves the
OLD config object live, because `PIPELINES` and friends are built at import
time. Several confusing failures trace back to exactly this.
