> # MLOps Framework — User Guide

A complete, start-to-end guide to the config-driven MLOps framework in
`/Workspace/Users/danduprolu.stuthi@latentview.com/mlops_pipeline`:
how to run it, what each stage does, which config file controls what, how to
add a new use case / feature technique / model, and which cells to re-run when
something changes.

---

## Contents

1. Design principles
2. Project layout
3. The driver notebook (`run_mlops_notebook`)
4. Widgets (notebook parameters)
5. Stage reference — what, when, approval, outputs
6. Configuration reference
   - 6.1 `feature_config.py`
   - 6.2 `mlops_config.py`
   - 6.3 `monitoring_config.py`
7. How-to recipes
   - 7.1 Add a new feature-engineering technique
   - 7.2 Add a new use case end to end
   - 7.3 Add a new model family
   - 7.4 Add a new monitoring slice / fairness group
   - 7.5 Add a new stage
   - 7.6 Replay historical data into the monitor window (date shift)
8. Re-run guide — "I changed X, which cells do I run again?"
9. Dashboard notes
10. Troubleshooting
11. Checklists

---

## 1. Design principles

* **The notebook holds no logic.** Every code cell is a single `stage_*` call
  from `src/pipeline.py`. No table names, column names, SQL, model
  hyper-parameters or dashboard IDs live in the notebook.
* **All decisions live in `src/config/`.** Three files, one per concern:
  features → training/registry/serving → scoring/monitoring. They hold
  **inputs only** — plain dictionaries and variables, no classes or
  functions.
* **All config code lives in `src/settings/`.** `feature_settings.py`,
  `mlops_settings.py` and `monitoring_settings.py` hold the dataclasses,
  `validate()` rules, SQL helpers and derived views; `builder.py` turns each
  config dict into its dataclass (a misspelt key fails with the list of
  valid keys). Pipeline code imports from `src.settings.*`, never from
  `src.config.*`.
* **State each fact once.** `SharedConfig` (in `mlops_config.py`) holds the
  table names, keys and target for a use case; training, registration,
  serving and monitoring all derive from it, so they cannot drift apart.
* **Nothing chains on its own.** Each stage is run explicitly.
* **Gates on state changes.** Stages that change shared state —
  `register`, `serve`, `baseline`, `rollback` — do nothing unless
  `approved=True` (the `approve` widget). Without approval they log what they
  *would* do and (where possible) run as a dry run.
* **Idempotent.** Scoring only scores periods that have no predictions yet;
  dashboard sync can be run any number of times.

---

## 2. Project layout

```
mlops_pipeline/
  run_mlops_notebook            Driver notebook: one stage call per cell
  MLOps_Framework_Guide.md      This guide
  README.md                     Original field-by-field reference
  requirements.txt              Installed by the notebook's %pip cell
  src/
    pipeline.py                 Stage functions + approval gates (the only API the notebook uses)
    config/
      feature_config.py         Feature sets: source, transformations, output tables, holdout
      mlops_config.py           Use cases: shared facts, training, registration, serving
      monitoring_config.py      Scoring, baseline, monitor, drift, rollback, dashboard, charts
    feature_engineering/
      build_features.py         Transformations (aggregate / row-level), writes features + truth
      create_raw_table.py       Optional: builds the raw source table (stage_raw)
      check_label_leakage.py    Optional: leakage check (stage_check_leakage)
    training/
      model_training.py         Time-split CV, Optuna search, MLflow logging
    model_registration/
      model_registration.py     Pick best run, register to UC, set aliases, baseline
      promotion_functions.py    Champion / challenger comparison
      model_formats.py          Loading models from different artifact formats
    serving/
      endpoint_manager.py       Create / update the Model Serving endpoint, AI Gateway
      check_holdout.py          Optional: score holdout via endpoint (stage_holdout_check)
    monitoring/
      batch_inference.py        Batch scoring, slice enrichment, baseline build
      lakehouse_monitor.py      Create/refresh the Lakehouse Monitor, dashboard sync
      check_drift.py            Drift detection from drift metrics
      check_rollback.py         Performance degradation check
      rollback.py               Swap champion / challenger aliases
      diagnose_monitor.py       Monitor contract check + notebook charts
      common.py                 Shared helpers
    utils/retry.py              Retry helper
```

---

## 3. The driver notebook (`run_mlops_notebook`)

| # | Section | Cell | Purpose |
|---|---------|------|---------|
| 1 | Setup | `%load_ext autoreload` | Reload `src/` edits automatically |
| 2 | — | Markdown overview | Pipeline diagram |
| 3 | Setup | `%pip install -r requirements.txt` | Libraries |
| 4 | Setup | `dbutils.library.restartPython()` | Apply installs |
| 5 | Setup | Parameters and stage imports | Widgets, `sys.path`, imports |
| 7 | 0. Features | `stage_features(FEATURE_SET, dry_run=True)` | Preview, writes nothing |
| 8 | 0. Features | `stage_features(FEATURE_SET)` | Write feature + truth (+ holdout) tables |
| 10 | 1. Train | `stage_train(USE_CASE)` | Train candidates, log to MLflow |
| 12 | GATE 1 | `stage_review(USE_CASE)` | Read-only: best candidate vs Champion |
| 14 | 2. Register | `stage_register(USE_CASE, approved=APPROVE)` | Register to UC, set aliases |
| 16 | GATE 2 | `stage_status(USE_CASE)` | Read-only: aliases vs endpoint version |
| 18 | 3. Serve | `stage_serve(USE_CASE, approved=APPROVE)` | Deploy / update endpoint |
| 20 | 4. Score | `stage_score(MONITOR)` | Batch predictions into inference table |
| 22 | 5. Baseline | `stage_baseline(MONITOR, approved=APPROVE)` | Training rows scored by Champion → baseline table |
| 23 | 5. Monitor | `stage_monitor(MONITOR, recreate=RECREATE)` | Create/refresh monitor, auto-sync dashboard |
| 24 | 5. Date shift | Shift inference dates into the monitor 30-day window | Testing/replay only: shifts `batch.time_column` by `batch.date_shift_days` (no-op when 0 or already shifted) — see 7.6 |
| 26 | 6. Drift | `stage_drift(MONITOR)` | Have inputs moved? |
| 28 | 7. Degradation | `stage_degradation(MONITOR)` | Has live error worsened? |
| 30 | 8. Dashboard | `stage_sync_dashboard(MONITOR)` | Repair/verify monitor dashboard |
| 31 | 8. Charts | `stage_visualize(MONITOR)` | Prediction, drift, quantile, fairness charts |
| 33 | GATE 3 | `stage_rollback(MONITOR, approved=APPROVE)` | Promote Challenger (reversible) |

Always run cells **1–5 first** after attaching compute or after a Python
restart; every later cell depends on the imports and widget values from cell 5.

Optional stages exposed by `src/pipeline.py` but not in the notebook (add a
cell if needed): `stage_raw`, `stage_check_leakage`, `stage_holdout_check`,
`stage_diagnose_monitor`.

---

## 4. Widgets (notebook parameters)

| Widget | Options come from | Used by |
|--------|-------------------|---------|
| `use_case` | keys of `USE_CASES` (`mlops_config.py`) | train, review, register, status, serve |
| `feature_set` | keys of `FEATURE_SETS` (`feature_config.py`) | features |
| `monitor` | keys of `MONITORING_CONFIGS` (`monitoring_config.py`) | score → rollback |
| `approve` | `true` / `false` (default `false`) | register, serve, baseline, rollback |
| `recreate_monitor` | `true` / `false` (default `false`) | monitor |

`recreate_monitor=true` deletes and recreates the monitor on every run of
cell 23 — and each recreate generates a **new** dashboard and resets the
30-day lookback (see 7.6). Set it back to `false` immediately after the run
that needed it.

Adding a new entry to any of those dictionaries makes it appear in the dropdown
automatically after re-running cell 5. Keep `approve=false` while exploring;
switch to `true` only for the run in which you intend to change state.

Typical combination for the fulfillment-risk project:
`use_case=fulfillment_risk`, `feature_set=fulfillment_risk` (training) or
`fulfillment_risk_validation` (scoring data), `monitor=fulfillment_risk`.

---

## 5. Stage reference

| Stage | Signature | Approval | Reads | Writes | Run when |
|-------|-----------|----------|-------|--------|----------|
| features | `stage_features(feature_set, dry_run=False)` | no | `FeatureSetConfig.source_table` (+ `history_tables`) | feature table, truth table, holdout table | New source data, or feature definition changed. Run once for the training set and once for the validation/scoring set. |
| train | `stage_train(use_case, dry_run=False, fail_fast=True)` | no | `SharedConfig.feature_table` + `target_table` | MLflow runs in `experiment_path` | After features, or when search/split config changes |
| review | `stage_review(use_case)` | read-only | MLflow + UC registry | — | After every train, before register |
| register | `stage_register(use_case, approved, skip_baseline=False)` | **yes** | best MLflow run | UC model version, aliases, registration baseline | Review shows the candidate beats the Champion |
| status | `stage_status(use_case)` | read-only | UC aliases, endpoint | — | Before serve; any time to check what's live |
| serve | `stage_serve(use_case, approved, wait=True, gateway_only=False)` | **yes** | `ServingStage` | Model Serving endpoint | A new Champion should take traffic, or serving config changed |
| score | `stage_score(monitor, dry_run=False)` | no | `batch.feature_table`, endpoint/model | inference table | New scoring periods arrived; new Champion/Challenger to compare |
| baseline | `stage_baseline(monitor, approved, dry_run=False)` | **yes** (overwrite) | training features + truth, Champion | `monitor.baseline_table` | After a new Champion is registered/served, or schema of inference table changed |
| monitor | `stage_monitor(monitor, refresh=True, wait=True, recreate=False)` | no | inference + baseline | profile & drift metric tables, dashboard | After score; `recreate=True` only after inference schema / slicing changes |
| sync_dashboard | `stage_sync_dashboard(monitor, verify=True)` | no | dashboards in `monitor.assets_dir` | dashboard drafts | Auto-run by monitor; re-run after dashboard config changes |
| drift | `stage_drift(monitor)` | read-only | drift metrics | alerts (if enabled) | After monitor refresh |
| degradation | `stage_degradation(monitor)` | read-only | profile metrics vs training metric | alerts (if enabled) | After monitor refresh |
| visualize | `stage_visualize(monitor)` | read-only | inference, profile, drift tables | — (charts) | Any time after monitor |
| rollback | `stage_rollback(monitor, approved)` | **yes** | aliases | swaps champion/challenger | Degradation confirmed and challenger is better |
| diagnose_monitor | `stage_diagnose_monitor(monitor)` | read-only | inference table | — | Monitor errors or empty metrics |

### Typical runs

* **First run of a use case:** 1–5 → 7 → 8 (training set) → change
  `feature_set` to the scoring set → 8 → 10 → 12 → (`approve=true`) 14 → 16 →
  18 → 20 → 22 → 23 → (wait for first refresh, see below) → 26 → 28 → 30 → 31.
* **New data arrived (routine):** 1–5 → 8 (scoring feature set) → 20 → 23 →
  26 → 28 → 31.
* **Retrain:** 1–5 → 8 (training set) → 10 → 12 → 14 → 16 → 18 → 22 → 23.
* **Rollback:** 1–5 → 28 (confirm) → 16 → (`approve=true`) 33 → 16 → 18.
* **Replaying historical validation data:** see 7.6.

**The first refresh after create/recreate is asynchronous.** Cell 23 returns
as soon as the monitor is ACTIVE, but the `_profile_metrics` and
`_drift_metrics` tables only exist once the first refresh finishes (about
10 minutes for ~1k rows). Until then sync, drift and degradation fail with
`TABLE_OR_VIEW_NOT_FOUND`. Check the refresh state (`lakehouse_monitor
--status`, or `w.quality_monitors.list_refreshes(<inference_table>)`) and
run 30 → 26 → 28 only after it shows `SUCCESS`.

---

## 6. Configuration reference

Rule of thumb:

| You want to change… | Edit |
|---------------------|------|
| Source table, transformations, label, output feature/truth tables, holdout | `feature_config.py` |
| Catalog/schema, model name, target, keys, dropped/categorical columns, CV splits, models, metric, Optuna trials, search space, registration rules, endpoint | `mlops_config.py` |
| Scoring table/mode, slicing column, monitor granularity, baseline, drift thresholds, rollback thresholds, alerts, dashboard filters, chart labels/colours | `monitoring_config.py` |

Each config class has a `validate()` that runs at the start of its stage and
raises a clear error for invalid values, so a mistake fails fast.

**Inputs vs code.** The files in `src/config/` contain only dictionaries:
every key is a field name of the matching dataclass in `src/settings/`, and a
key left out takes that field's default. Nested dicts become nested
dataclasses (for example `"split": {...}` → `SplitConfig`, each entry of
`"lags": [...]` → `LagSpec`). The registries `USE_CASES`, `FEATURE_SETS` and
`MONITORING_CONFIGS` that the stages read are built from these dicts in
`src/settings/*_settings.py`.

| Input file (edit) | Code file (do not edit for new inputs) |
|---|---|
| `src/config/feature_config.py` | `src/settings/feature_settings.py` |
| `src/config/mlops_config.py` | `src/settings/mlops_settings.py` |
| `src/config/monitoring_config.py` | `src/settings/monitoring_settings.py` |

After editing a config file in an attached notebook session, reload both the
config module and its settings module (or restart Python) so the objects are
rebuilt.

Dataclass field names and defaults below are defined in `src/settings/`;
the values are set in `src/config/`.

### 6.1 `src/config/feature_config.py`

Registry: `FEATURE_SETS: Dict[str, FeatureSetConfig]`, `DEFAULT_FEATURE_SET`.

**`FeatureSetConfig` main fields**

| Field | Meaning |
|-------|---------|
| `name` | Key shown in the `feature_set` widget |
| `mode` | `"aggregate"` (resample to `freq` per `group_cols`, then lags/rollings) or `"row_level"` (one output row per source row) |
| `source_table` | Input table |
| `history_tables` | Extra tables used only as history context (e.g. validation rows see earlier training rows); dropped from output |
| `time_column`, `freq`, `out_time_column` | Event date, resample frequency (aggregate mode), output date column |
| `group_cols`, `series_cols` | Grain of the output; series used to order history |
| `passthrough_cols` | Columns copied unchanged (row_level) |
| `numeric_cols` | Columns coerced to numeric before features |
| `aggregations: List[AggregationSpec]` | `name`, `column`, `func` in `sum, mean, min, max, std, count, nunique, share_of` (+ `equals` for share_of) |
| `lags: List[LagSpec]` | `column`, `periods`, `prefix` |
| `rollings: List[RollingSpec]` | `column`, `windows`, `stats` in `mean, std, min, max, sum, ewm` |
| `point_in_time: List[PointInTimeSpec]` | History-only stats that never see the current row: `stat` in `mean, std, sum, count, min, max, rate`; `window` (None = expanding); `threshold`; `fill_value` |
| `one_hot: List[OneHotSpec]` | `column`, fixed `categories`, `prefix`, `drop_original`, `other_flag` (fixed categories keep train/serve columns identical) |
| `calendar: CalendarSpec` | Toggle year, month, quarter, week_of_year, week_of_month, day_of_week, boundary flags, days_from_start |
| `ratios: Dict[name, (num, den)]` | Ratio features; `drop_ratio_numerators` |
| `label: LabelSpec` | `name`, `source_column`, `bins` (empty = already categorical), `labels`, `encode` (adds `<name>_encoded`) |
| `max_source_date` | Exclude rows on/after this date |
| `dropna` | Drop rows with NaN after building |
| `feature_store: FeatureStoreSpec` | Output feature table, primary keys, `use_feature_store` (plain Delta overwrite when False — recommended) |
| `target_table: TargetTableSpec` | Output truth/label table, target column, merge keys |
| `holdout: HoldoutSpec` | Optional held-back rows written to a separate table |

The fulfillment-risk sets are built by `_fulfillment_feature_set(...)` so the
training and validation sets use identical transformations; only source table,
output prefix and history differ. Shared lists live in module constants
(`_FR_PASSTHROUGH`, `_FR_POINT_IN_TIME`, `_FR_ONE_HOT`, `_FR_NUMERIC`,
`_FR_CLASSES`, `_FR_CALENDAR`).

**Row-level build order** (`build_features.build_row_level`): load source +
history → numeric coercion → `add_point_in_time` → drop history rows →
`add_label` → `add_one_hot` → `add_calendar` → select output columns.
**Aggregate build order** (`build_features.build`): `load_source` →
`aggregate` → `add_ratios` → `add_calendar` → `add_lags_and_rollings` →
`dropna`.

### 6.2 `src/config/mlops_config.py`

Registry: `USE_CASES: Dict[str, UseCase]`, `DEFAULT_USE_CASE`.
A `UseCase` has four parts:

**`SharedConfig` — state each fact once**

| Field | Meaning |
|-------|---------|
| `name`, `catalog`, `schema` | Use-case key and UC location |
| `experiment_path` | MLflow experiment |
| `model_name` | UC model name (without catalog.schema) |
| `feature_table`, `target_table`, `join_keys` | Training input (must match the feature set's output tables) |
| `source_label_col`, `target_col` | Label column in truth table / training target |
| `date_column`, `min_valid_date` | Real DATE/TIMESTAMP for time splits |
| `drop_cols` | Never used as features (IDs, raw dates, label text, leakage) |
| `cat_cols` | Native categoricals — keep empty for served models (JSON has no category dtype); one-hot in features instead |
| `numeric_cols`, `id_cols` | Typing and identifiers |

**`TrainingStage`**: `split: SplitConfig` (`n_splits`, `val_weeks`,
`step_weeks`, `min_test_rows`, sample weights), `search: SearchConfig`
(`task` regression/classification, `models` e.g. `["xgboost","lightgbm","catboost"]`,
`n_trials`, `primary_metric`, `metric_names`, pruner settings),
`search_space` (override of `DEFAULT_SEARCH_SPACE` /
`CLASSIFICATION_SEARCH_SPACE`), logging toggles.

**`RegistrationStage`**: `metric`, `metric_direction` (`minimize`/`maximize`),
`improvement_threshold` (0.02 = must be 2% better), `run_filter`,
`model_artifact_path`, baseline window (`test_months`, `baseline_window_mode`,
`min_baseline_rows`, `max_anchor_lookback_months`), `registry: RegistryConfig`
(`champion_alias`, `challenger_alias`, metric tags, `extra_tags`).

**`ServingStage`**: `endpoint_name` (default `<name>-endpoint`),
`serve_alias`, `workload_size` (Small/Medium/Large), `workload_type`
(CPU/GPU_*), `scale_to_zero_enabled`, `ai_gateway` (usage tracking, inference
table, rate limits), `tags`, `wait_timeout_minutes`.

Metric names and directions are defined in `METRIC_DIRECTIONS`,
`REGRESSION_METRICS`, `CLASSIFICATION_METRICS`.

### 6.3 `src/config/monitoring_config.py`

Registry: `MONITORING_CONFIGS: Dict[str, MonitoringConfig]`. Entries are
built with `from_use_case(use_case, ...)`, which derives model name, keys,
label, baseline table, aliases, etc. from the use case, so you only pass what
differs.

**`from_use_case` arguments you normally set**

| Argument | Meaning |
|----------|---------|
| `inference_schema`, `monitor_schema` | Where the inference table and metric tables go |
| `scoring_feature_table`, `scoring_target_table` | Data to score + its actual labels (e.g. the validation feature set output) |
| `assets_dir` | Workspace folder where the monitor dashboard is generated |
| `time_column`, `monitor_time_basis` | Business date used for windows (`"event"`) |
| `granularities` | Monitor windows, e.g. `["1 day"]`, `["1 week"]` — pick so the data spans several windows |
| `scoring_mode` | `"endpoint"` (score via serving endpoint, what production returns) or `"local"` (load model on cluster) |
| `endpoint_batch_size` | Rows per endpoint request |
| `slicing_exprs` | Monitor slices; `binary_slices(col, groups)` gives the column + one binary expression per group (fairness needs binary slices) |
| `enrichment: SliceEnrichmentConfig` | How the slicing column is added during scoring: `column`, `source_table` + `join_keys` lookup, `source_expr` (e.g. `prefix_case_expr`), `fallback_expr` (e.g. `hash_bucket_expr`) |
| `compare_model_refs` | Extra model aliases/versions scored next to the deployed one (e.g. `["challenger"]`) |
| `categorical_output` | Write prediction as STRING (needed for classification drift/frequent items) |
| `date_shift_days` | Days to shift `time_column` forward in the inference table relative to the feature table (default `0` = no shift). Testing/replay only — used by notebook cell 24, see 7.6. Fulfillment risk: `25` (Sep 16–21 → Oct 11–16) |
| `monitor_metric`, `training_metric` | Metrics compared by degradation check |
| `drift_exclude_extra` | Extra columns excluded from drift |
| `alerts: AlertConfig` | `enabled`, `recipients`, `subject_prefix`, `webhook_url` |
| `viz: VisualizationConfig` | Chart settings (below) |

**Nested classes**

* `BatchInferenceConfig` (`cfg.batch`): `feature_table`, `inference_table`,
  `actual_target_table`, `merge_keys`, `time_column`, `prediction_col`,
  `label_col`, `model_version_col`, `model_name_col`, `timestamp_col`,
  `exclude_from_features`, `max_periods_per_run`, `scoring_mode`,
  `endpoint_name`, `endpoint_batch_size`, `categorical_output`,
  `compare_model_refs`, `enrichment`, `date_shift_days` (validated `>= 0`).
* `LakehouseMonitorConfig` (`cfg.monitor`): `output_schema`, `assets_dir`,
  `baseline_table`, `problem_type`, `granularities`, column names,
  `slicing_exprs`, refresh polling/timeout.
* `DriftConfig` (`cfg.drift`): `ks_pvalue_threshold`,
  `chi_pvalue_threshold`, `min_drifted_columns`, `exclude_columns`.
* `RollbackThresholds` (`cfg.rollback`): `metric_pct_increase` (0.20 = 20%
  worse), `direction`, `consecutive_windows`, `settling_hours`,
  `monitor_metric`, `training_metric`.
* `DashboardConfig` (`cfg.dashboard`): `sync_on_monitor`,
  `sync_all_dashboards`, `no_slice_label`, `model_all_token` (`"*"`), filter
  parameter names (`Model Id`, `Slice Key`, `Slice Value`, `top_k`),
  `default_protected_group` (default = first binary slice).
* `VisualizationConfig` (`cfg.viz`): `class_labels` (class → display name),
  `top_n_drift_features`, `quantile_panels`, `quantile_labels`,
  `ks_alert_statistic`, `drift_chart_type` (`CONSECUTIVE`/`BASELINE`),
  `fairness_band`, `palette`.

Slice helpers (code, in `src/settings/monitoring_settings.py`):
`prefix_case_expr`, `hash_bucket_expr`, `binary_slices`. Fulfillment-risk
grouping (input, in `src/config/monitoring_config.py`): the `FR_SLICE_GROUPS`
dict — `column`, `source_column`, `hash_key`, `shares`,
`lookup_feature_set`, `lookup_use_case` — referenced by the entry's
`"slice_groups"` key. Change groups or shares there and every slice,
fallback, dashboard default and fairness chart follows.

### 6.4 `src/config/job_config.py` — Lakeflow Jobs

The notebook is split into three Python script entry points under `jobs/`.
Each takes **no job parameters**: what it runs comes from `JOBS` in
`src/config/job_config.py`, everything else from the other three config
files. Code: `src/settings/job_settings.py` (validation) and
`src/jobs/runner.py` (runs the stages in order, logs a summary). Each stage
is the same `stage_*` call the notebook makes.

| Job file | Notebook sections | `JOBS[...]` keys |
|---|---|---|
| `jobs/feature_engineering_job.py` | 0 | `feature_sets` (built in order), `dry_run_first` |
| `jobs/mlops_process_job.py` | 1–3 | `use_case`, `stages` (train, review, register, status, serve), `approve_register`, `approve_serve`, `skip_baseline`, `wait_for_endpoint` |
| `jobs/monitoring_job.py` | 4–8, gate 3 | `monitor`, `stages` (score, shift_dates, baseline, monitor, drift, degradation, sync_dashboard, visualize, diagnose_monitor, rollback), `approve_baseline`, `approve_rollback`, `recreate_monitor`, `wait_for_refresh`, `skip_score_when_replayed` |

* `approve_*` replace the `approve` widget. A job runs unattended, so they
  default to `False`: gated stages log what they would do and the job
  carries on. Set the flag to `True` after reviewing a run, then re-run.
* A stage that raises fails the task; later stages do not run.
* `shift_dates` replaces the notebook's date-shift cell (now
  `src/monitoring/date_shift.py`, `stage_shift_dates`). It is a no-op when
  `date_shift_days = 0`. While a replay is in place,
  `skip_score_when_replayed` skips `score` so the original dates are not
  re-added.

**Creating the jobs** (one Python script task each, run in order
feature_engineering → mlops_process → monitoring, or as three tasks of one
job with dependencies):
* Path: `/Workspace/Users/danduprolu.stuthi@latentview.com/mlops_pipeline/jobs/<file>.py`,
  source Workspace.
* Compute: serverless; add dependency
  `-r /Workspace/Users/danduprolu.stuthi@latentview.com/mlops_pipeline/requirements.txt`
  in the task environment.
* Parameters: none.

---

## 7. How-to recipes

### 7.1 Add a new feature-engineering technique

Example: a "target-free z-score per item" or any new transformation.

1. **Config spec** — in `src/settings/feature_settings.py` (code), with the
   values added as a dict key in `src/config/feature_config.py` (inputs):
   * Add a dataclass describing the technique's parameters, with a
     `validate()` (follow `LagSpec` / `PointInTimeSpec`):
     ```python
     @dataclass
     class ZScoreSpec:
         column: str
         by: List[str]
         name: Optional[str] = None
         def validate(self) -> None:
             if not self.by:
                 raise ValueError(f"[{self.column}] z-score needs 'by' columns.")
         def output_name(self) -> str:
             return self.name or f"{self.column}_z"
     ```
   * Add a field to `FeatureSetConfig`:
     `zscores: List[ZScoreSpec] = field(default_factory=list)`.
   * In `FeatureSetConfig.validate()`, call `spec.validate()` for each entry.
2. **Transformation** — in `src/feature_engineering/build_features.py`,
   add a function with the standard signature, a no-op when not configured:
   ```python
   def add_zscores(df: pd.DataFrame, cfg: FeatureSetConfig) -> pd.DataFrame:
       if not cfg.zscores:
           return df
       for s in cfg.zscores:
           g = df.groupby(s.by)[s.column]
           df[s.output_name()] = (df[s.column] - g.transform("mean")) / g.transform("std")
       return df
   ```
   Rules: never use the current row's label or future rows (leakage); for
   history features order by `cfg.series_cols` + `cfg.time_column` and shift.
3. **Wire it into the build order**:
   * Row-level: call it in `build_row_level` (after `add_point_in_time` if it
     needs history rows, otherwise after `add_one_hot`) **and add its output
     names to the selected output column list** near the end of
     `build_row_level` (where one-hot / point-in-time names are added),
     otherwise the new columns are dropped.
   * Aggregate: call it in `build` between `aggregate` and `dropna`.
4. **Use it** — add the spec to the feature set in `FEATURE_SETS`
   (for fulfillment risk, inside `_fulfillment_feature_set` so training and
   validation both get it).
5. **Make sure training uses it** — new columns are features automatically
   unless listed in `SharedConfig.drop_cols`. If the column is categorical,
   one-hot it rather than adding to `cat_cols` for served models.
6. **Run**: cells 1–5 → 7 (dry run, check new column appears) → 8 for the
   training set → 8 for the validation set → 10 → 12 → 14 → 16 → 18 → 22 →
   23 with `recreate_monitor=true` (the inference schema changed) → 30 → 31.

For a one-off computation that needs no parameters you can skip step 1 and
just add the function, but parameters should still go to config, never the
notebook.

### 7.2 Add a new use case end to end

1. **Features** (`feature_config.py`): add one `FeatureSetConfig` for
   training data and (if you monitor separate data) one for scoring data, to
   `FEATURE_SETS`. Output tables via `feature_store.table_name` and
   `target_table.table_name`.
2. **Use case** (`mlops_config.py`): add `"my_case": UseCase(shared=SharedConfig(...),
   training=TrainingStage(...), registration=RegistrationStage(...),
   serving=ServingStage(...))` to `USE_CASES`. `feature_table` /
   `target_table` must equal the training feature set's outputs.
   Set `metric_direction="maximize"` for f1/accuracy-type metrics.
3. **Monitoring** (`monitoring_config.py`): add
   `"my_case": from_use_case("my_case", inference_schema=..., monitor_schema=...,
   scoring_feature_table=..., scoring_target_table=..., assets_dir=...,
   time_column=..., granularities=[...], slicing_exprs=[...], ...)` to
   `MONITORING_CONFIGS`.
4. Re-run cell 5; pick the new values in the widgets; follow the
   "First run" sequence in section 5.

### 7.3 Add a new model family

1. `src/training/model_training.py`: add a branch in `_load_estimator`
   (estimator class per task), `_model_log_fn` (MLflow flavour), and if
   needed `get_model_data` / `build_model` / `log_feature_importance`.
2. `src/config/mlops_config.py`: add a search-space entry to
   `DEFAULT_SEARCH_SPACE` and/or `CLASSIFICATION_SEARCH_SPACE`.
3. Add the name to `TrainingStage.search.models` of the use case.
4. Add the library to `requirements.txt`; re-run cells 3–5, then 10.

### 7.4 Add a new monitoring slice / fairness group

* New group in the existing column: edit `_FR_GROUP_SHARES` (groups and
  hash-fallback shares).
* New slicing column: add a `SliceEnrichmentConfig` (or a column already
  in the feature table) and add `binary_slices("<col>", [...])` to
  `slicing_exprs`.
* Then run 20 (score, adds the column) → 22 (`approve=true`) → 23 with
  `recreate_monitor=true` → 30 → 31.

### 7.5 Add a new stage

1. Put the logic in the right module under `src/` with a function taking
   `(spark, cfg)`.
2. Add `stage_<name>(monitor_or_use_case, ...)` to `src/pipeline.py` that
   loads the config (`get_monitoring_config`, `get_use_case`, `get_feature_set`)
   and, if it changes shared state, wraps the call with `_gate(...)` and
   `approved`.
3. Import it in notebook cell 5 and add a markdown + one-line code cell.

### 7.6 Replay historical data into the monitor window (date shift)

**Why.** When a time-series or inference monitor is first created it only
analyses data from the **30 days before its creation**; later data is
always processed. Validation data that is older than that (fulfillment
risk: `order_date` Sep 16–21, monitor created Oct 21) produces metric tables
with only baseline / NULL-window rows: every dashboard dataset is empty,
drift logs "No drift rows to evaluate" and degradation logs `window None`.
Recreating the monitor does **not** help — it moves the cutoff forward.

**Production fix.** Score periods whose time column falls inside the last
30 days (cell 8 with new source data → 20 → 23).

**Testing / demo fix (config-driven):**

1. In `monitoring_config.py`, set `date_shift_days=<n>` in the use case's
   `from_use_case(...)` call so the latest date lands inside the window
   (fulfillment risk: `25`). Nothing is hardcoded in the notebook.
2. Run cell 24. It reads `batch.inference_table`, `batch.time_column` and
   `batch.date_shift_days`, measures the shift already applied against the
   feature table's max date, and applies only the missing difference — so
   re-running is a no-op ("Already shifted by N day(s)"). It reloads
   `monitoring_config` itself, so a config edit is picked up without a
   restart.
3. Refresh the monitor: cell 23 with `recreate_monitor=false`. Wait for the
   refresh to show `SUCCESS`.
4. Run 30 (sync, expect `errors={}` and `empty=[]`) → 26 → 28 → 31.

**Caveats.**

* Never shift real production predictions.
* Calendar features (`month`, `quarter`, `week_of_year`, `day_of_week`,
  `days_from_start`) are not shifted, so they will legitimately drift
  against the baseline — expect drift alerts in a replay.
* `stage_score` finds pending periods by matching `time_column` between the
  feature table and the inference table. After a shift the original
  periods look unscored, so running cell 20 again re-scores them and
  duplicates rows. Skip cell 20 while replaying, or reset `date_shift_days`
  to `0` and rebuild the inference table first.

---

## 8. Re-run guide — "I changed X, which cells do I run again?"

Always start with cells 1–5 after a kernel restart. Edits to `src/` are
normally picked up by autoreload; if a change does not show up (dataclass
fields, module-level constants), run **cell 4 (restart) then cell 5** before
re-running the stage. Config registries such as `MONITORING_CONFIGS` are
built at import time, so a new dataclass field can raise `AttributeError`
until the module is reloaded (`importlib.reload(...)`, as cell 24 does) or
Python is restarted.

| Change | Go back to | Then run |
|--------|-----------|----------|
| New raw/source data for training | 8 (training set) | 10 → 12 → 14 → 16 → 18 → 22 → 23 |
| New data to score / monitor | 8 (scoring set) | 20 → 23 → 26 → 28 → 31 |
| Feature definition / new technique | 7 → 8 (both sets) | 10 → … → 18 → 22 → 23 (`recreate_monitor=true`) → 30 → 31 |
| `drop_cols`, split, models, search space, metric | 10 | 12 → 14 → 16 → 18 → 22 → 23 |
| Registration rules (threshold, direction) | 12 | 14 → 16 |
| Serving config (size, gateway, endpoint) | 16 | 18 |
| New Champion registered | 16 → 18 | 20 → 22 → 23 → 26 → 28 → 31 |
| `scoring_mode`, `compare_model_refs`, enrichment | 20 | 23 → 30 → 31 |
| `slicing_exprs`, `granularities`, `problem_type`, inference columns | 20 → 22 | 23 with `recreate_monitor=true` → wait for refresh → 30 → 31 |
| `date_shift_days` (replay) | 24 | 23 (`recreate_monitor=false`) → wait for refresh → 30 → 26 → 28 → 31 |
| Drift thresholds | 26 | — |
| Rollback thresholds / metrics | 28 | — |
| Dashboard settings (`cfg.dashboard`) or dashboard looks broken | 30 | refresh browser tab |
| Chart settings (`cfg.viz`) | 31 | — |
| Rollback executed | 16 | 18 (if endpoint serves by version) → 20 → 23 |

Re-running stages is safe: `stage_score` only fills missing periods,
`stage_features` overwrites its tables, `stage_sync_dashboard` is idempotent,
and gated stages do nothing while `approve=false`.

---

## 9. Dashboard notes

* The Lakehouse Monitor generates its dashboard in `monitor.assets_dir`; a
  recreate generates a **new** dashboard. `stage_sync_dashboard` repairs
  every dashboard in that folder (when `sync_all_dashboards=True`):
  Model Id exact match (`*` = all versions aggregate), Slice Key / Slice Value
  filters, baseline fallback to the version that has a baseline profile,
  STRING window labels in the quantile chart, Top K options (DECIMAL),
  fairness filters with the first binary slice as default.
* After every sync, **close open dashboard tabs and hard-reload**
  (Ctrl+Shift+R) before editing. A stale browser copy can overwrite the fix
  and shows "widget query references non-existent dataset".
* Fairness metrics only exist for binary slices with `slice_value = 'true'`;
  that is why `slicing_exprs` contains one binary expression per group.
* Each recreate leaves the previous dashboard in place and adds a new one
  named `<table> Monitoring <timestamp>`. Both are synced, but delete the
  one you no longer use to avoid confusion.
* A sync run before the first refresh finishes verifies every dataset as
  `TABLE_OR_VIEW_NOT_FOUND`; this is timing, not a dashboard bug — re-run
  cell 30 after the refresh succeeds.

---

## 10. Troubleshooting

| Symptom | Cause / fix |
|---------|-------------|
| `ModuleNotFoundError: src` | Run cell 5 (adds the notebook folder to `sys.path`) |
| Gated stage logs "STAGE ... NOT RUN" | `approve` widget is `false`; set `true`, re-run cell 5, re-run stage |
| `Alias 'challenger' is not set` warning in score | Expected until a challenger exists; remove from `compare_model_refs` or register one |
| Score writes 0 rows | All periods already scored; add new data via cell 8 |
| Drift/monitor shows one window only | `granularities` too coarse for the data span |
| Categorical drift missing for predictions | `categorical_output=True` so prediction is STRING |
| Monitor fails after adding columns | Re-run with `recreate_monitor=true` |
| Served model rejects categorical columns | Keep `cat_cols=[]`; one-hot in features |
| Training fails on stale columns | Use `use_feature_store=False` (plain Delta overwrite) |
| Code change not picked up | Cell 4 (restart) → cell 5 |
| Dashboard filter empty / wrong | Re-run cell 30, hard-reload the tab |
| `CAST_INVALID_INPUT` in quantile chart | Fixed by sync (window cast to STRING); re-run 30 |
| Sync/drift/degradation fail with `TABLE_OR_VIEW_NOT_FOUND` on `_profile_metrics` / `_drift_metrics` right after create/recreate | First refresh still running (async, ~10 min). Wait for `SUCCESS`, then re-run 30 → 26 → 28 |
| Sync reports `errors={}` but most datasets `empty`; profile metrics have only NULL `granularity`/`window`; drift "No drift rows to evaluate"; degradation `window None` | Data is older than the monitor's 30-day lookback from creation. Score recent periods, or (testing) set `date_shift_days` and follow 7.6. Recreating does not help |
| Duplicate monitoring dashboards | Monitor was recreated; delete the older one, keep `recreate_monitor=false` |
| `AttributeError: ... has no attribute 'date_shift_days'` (or any new config field) | Config module still cached; re-run cell 24 (it reloads) or cell 4 → cell 5 |
| Score re-scores old periods after a date shift | Expected — pending periods are matched on the original dates; skip cell 20 while replaying (7.6) |

---

## 11. Checklists

**Before register (GATE 1):** review output shows candidate beats Champion
by at least `improvement_threshold` on the primary metric; no label leakage
(suspiciously perfect scores); feature importance looks sensible.

**Before serve (GATE 2):** `stage_status` shows the alias you intend to
serve; endpoint config is as intended.

**Before rollback (GATE 3):** degradation sustained for
`consecutive_windows`; past `settling_hours`; challenger exists and is
better on recent data. Rollback is reversible — the demoted Champion becomes
Challenger.

**Keeping the notebook clean:** no literals in cells; new parameters go in
a config dataclass; new logic goes in a module + `stage_*` wrapper; scratch
work stays out of the driver notebook.
