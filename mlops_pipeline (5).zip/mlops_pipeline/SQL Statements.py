# Databricks notebook source
# MAGIC %sql
# MAGIC select * from dev_platform.mlops.fulfillment_risk_level

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_platform.mlops.fulfillment_risk_features

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_platform.mlops.fulfillment_risk_truth

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_platform.mlops.fulfillment_risk_validation

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_platform.mlops.fulfillment_risk_validation_features

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_platform.mlops.fulfillment_risk_validation_truth

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_platform.mlops.fulfillment_risk_model_1_baseline

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_platform.mlops.fulfillment_risk_predictions_profile_metrics

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_platform.mlops.fulfillment_risk_predictions_drift_metrics