"""
feature_config.py — INPUTS ONLY
--------------------------------
Feature-engineering inputs, as plain dictionaries: the source table, the
grain, the aggregations, lags, rollings, point-in-time history, one-hot
flags, the label and the output tables.

No classes, no functions: the dataclasses, validation and the builder that
turns these dicts into FeatureSetConfig objects live in
src/settings/feature_settings.py. Every key is a field name of the matching
spec; any key left out takes its default.

    python -m src.feature_engineering.build_features --feature_set weekly_orders
"""

# ── Feature set selected when none is given ───────────────────────────────
DEFAULT_FEATURE_SET = "fulfillment_risk"


# ── Fulfillment risk: column decisions, stated once and reused ───────────
#
# EXCLUDED — the labelling CASE statement reads these, so a model given them
# reproduces the rule at ~100% accuracy and learns nothing:
#     available_qty, on_order_qty, in_transit_qty, next_expected_receipt,
#     supply_gap_qty, days_until_fulfillment
#
# EXCLUDED — no modelling value:
#     item_description, customer_name   free text duplicating the codes
#     next_expected_delivery            supply-side, same family as the rule
#     estimated_delivery_date           CURRENT_DATE() + lead time; moves every run
#     days_overdue                      CURRENT_DATE()-relative; differs per rebuild
#     snapshot_date, row_seq            bookkeeping
#
# KEPT — known when the order is placed and stable across rebuilds:
FR_PASSTHROUGH = [
    "order_number", "item_number",          # identifiers (dropped before the model)
    "customer_number", "warehouse",         # categoricals
    "order_date",                           # time column
    "backorder_qty",                        # the demand on this line
    "extended_price",
    "on_hand_qty",                          # physical stock, NOT Available
    "total_backordered",                    # item-level, not in the CASE rule
    "safety_stock",
    "purchasing_lead_time_days",
    "mfg_fixed_lead_time",
    "requested_lead_time_days",             # requested ship minus order date
]

# Item behaviour from PRIOR lines only; every statistic is shifted by a row so
# the current line never contributes to its own feature.
FR_POINT_IN_TIME = [
    {"name": "item_prior_lines",         "column": "backorder_qty",  "stat": "count", "window": None},
    {"name": "item_prior_avg_backorder", "column": "backorder_qty",  "stat": "mean",  "window": None},
    {"name": "item_prior_max_backorder", "column": "backorder_qty",  "stat": "max",   "window": None},
    {"name": "item_prior_avg_price",     "column": "extended_price", "stat": "mean",  "window": None},
    {"name": "item_last5_avg_backorder", "column": "backorder_qty",  "stat": "mean",  "window": 5},
    {"name": "item_last5_avg_onhand",    "column": "on_hand_qty",    "stat": "mean",  "window": 5},
]

# warehouse is low-cardinality, so flags cost little and make the frame
# servable over JSON. customer_number is NOT one-hot encoded — it is dropped,
# and customer behaviour is captured by history features.
FR_ONE_HOT = [
    {"column": "warehouse",
     "categories": ["WH1", "WH2", "WH3"],   # <- set to YOUR warehouse codes
     "prefix": "wh",
     "drop_original": True,
     "other_flag": True},
]

# Numbers stored as text or DECIMAL in the source; cast before modelling.
FR_NUMERIC = [
    "backorder_qty", "extended_price", "on_hand_qty", "total_backordered",
    "safety_stock", "purchasing_lead_time_days", "mfg_fixed_lead_time",
    "requested_lead_time_days",
]

FR_CLASSES = [
    "Low - Stock Available",
    "Medium - Supply In Pipeline",
    "Medium - Receipt Expected",
    "High - No Supply Visibility",
]

FR_CALENDAR = {
    "year": True, "month": True, "quarter": True, "week_of_year": True,
    "week_of_month": False, "day_of_week": True,
    "boundary_flags": False, "days_from_start": True,
}

# Everything the training and validation feature sets share. They differ only
# in source table, output tables and borrowed history — identical
# transformations are what make the two frames comparable at scoring time.
FR_COMMON = {
    "mode": "row_level",
    "time_column": "order_date",
    "freq": "D",                              # unused in row_level
    "out_time_column": "order_date",
    "group_cols": ["order_number", "item_number"],
    "series_cols": ["item_number"],           # item history is the series
    "passthrough_cols": FR_PASSTHROUGH,
    "point_in_time": FR_POINT_IN_TIME,
    "one_hot": FR_ONE_HOT,
    "numeric_cols": FR_NUMERIC,
    "label": {
        "name": "risk_level",
        "source_column": "fulfillment_risk_level",
        "bins": [],                           # empty = already categorical
        "labels": FR_CLASSES,
        "encode": True,
    },
    "calendar": FR_CALENDAR,
    "dropna": False,                          # first line per item has no history
}


# ── Feature sets ──────────────────────────────────────────────────────────
FEATURE_SETS = {

    # ── Fulfillment risk: TRAINING (prod_platform.mlops.fulfillment_risk_level)
    "fulfillment_risk": {
        **FR_COMMON,
        "name": "fulfillment_risk",
        "source_table": "prod_platform.mlops.fulfillment_risk_level",
        "history_tables": [],
        # Plain Delta, not the Feature Store: the Feature Store merges and
        # cannot drop columns, so a changed feature set would leave stale
        # columns behind. A plain overwrite replaces the table outright.
        "feature_store": {
            "table_name": "prod_platform.mlops.fulfillment_risk_features_1",
            "primary_keys": ["order_number", "item_number"],
            "description": "Order/item features for fulfillment_risk (rule columns excluded)",
            "use_feature_store": False,
        },
        "target_table": {
            "table_name": "prod_platform.mlops.fulfillment_risk_truth_1",
            "target_col": "risk_level_encoded",
            "merge_keys": ["order_number", "item_number"],
        },
    },

    # ── Fulfillment risk: VALIDATION
    # history_tables pulls in the training rows so each validation line sees
    # the earlier orders for its item; otherwise every validation row would
    # start with an empty history.
    "fulfillment_risk_validation": {
        **FR_COMMON,
        "name": "fulfillment_risk_validation",
        "source_table": "prod_platform.mlops.fulfillment_risk_validation",
        "history_tables": ["prod_platform.mlops.fulfillment_risk_level"],
        "feature_store": {
            "table_name": "prod_platform.mlops.fulfillment_risk_validation_features_1",
            "primary_keys": ["order_number", "item_number"],
            "description": "Order/item features for fulfillment_risk_validation (rule columns excluded)",
            "use_feature_store": False,
        },
        "target_table": {
            "table_name": "prod_platform.mlops.fulfillment_risk_validation_truth_1",
            "target_col": "risk_level_encoded",
            "merge_keys": ["order_number", "item_number"],
        },
    },
}

    