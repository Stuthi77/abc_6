"""
mlops_config.py — INPUTS ONLY
------------------------------
Training, registration and serving inputs, as plain dictionaries.
No classes, no functions: the code that turns these into typed objects,
validates them and derives the stage views lives in
src/settings/mlops_settings.py.

Each USE_CASES entry has four parts; every key is a field name:
    "shared"        tables, columns, experiment, model name   <- stated once
    "training"      split, search, (optional) search_space
    "registration"  metric, thresholds, baseline window, registry
    "serving"       endpoint, workload, AI Gateway, tags

Any key left out takes the default defined in mlops_settings.py.
"""

# ── Use case selected when none is given ────────────────────────────────────
DEFAULT_USE_CASE = "fulfillment_risk"


# ── Search spaces ───────────────────────────────────────────────────────
#   tuple  -> tuned     ("int", low, high) | ("float", low, high, log?) |
#                       ("categorical", [choices])
#   scalar -> fixed, passed straight to the estimator
# Used when a use case leaves training.search_space unset: regression spaces
# for a regressor, classification spaces for a classifier.
DEFAULT_SEARCH_SPACE = {
    "xgboost": {
        "n_estimators": ("int", 200, 1500),
        "max_depth": ("int", 3, 10),
        "min_child_weight": ("int", 1, 20),
        "learning_rate": ("float", 1e-3, 0.2, True),
        "gamma": ("float", 0.0, 5.0),
        "reg_alpha": ("float", 1e-8, 10.0, True),
        "reg_lambda": ("float", 1e-8, 10.0, True),
        "subsample": ("float", 0.5, 0.95),
        "colsample_bytree": ("float", 0.5, 0.95),
        "colsample_bylevel": ("float", 0.6, 1.0),
        "objective": "reg:squarederror",
        "eval_metric": "rmse",
        "random_state": 42,
        "n_jobs": -1,
    },
    "lightgbm": {
        "n_estimators": ("int", 200, 1500),
        "max_depth": ("int", 3, 12),
        "num_leaves": ("int", 15, 255),
        "min_child_samples": ("int", 10, 100),
        "learning_rate": ("float", 1e-3, 0.2, True),
        "reg_alpha": ("float", 1e-8, 10.0, True),
        "reg_lambda": ("float", 1e-8, 10.0, True),
        "subsample": ("float", 0.5, 0.95),
        "subsample_freq": ("int", 1, 7),
        "colsample_bytree": ("float", 0.5, 0.95),
        "objective": "regression",
        "metric": "rmse",
        "random_state": 42,
        "n_jobs": -1,
        "verbosity": -1,
    },
    "catboost": {
        "iterations": ("int", 300, 1500),
        "depth": ("int", 4, 10),
        "learning_rate": ("float", 1e-3, 0.2, True),
        "l2_leaf_reg": ("float", 1.0, 20.0, True),
        "random_strength": ("float", 1e-3, 10.0, True),
        "bagging_temperature": ("float", 0.0, 1.0),
        "loss_function": "RMSE",
        "eval_metric": "RMSE",
        "random_state": 42,
        "verbose": False,
        "thread_count": -1,
        # Job tasks run from a read-only git checkout; CatBoost's default
        # train_dir (catboost_info/ in cwd) can't be created there.
        "train_dir": "/tmp/catboost_info",
        "allow_writing_files": False,
    },
    "random_forest": {
        "n_estimators": ("int", 100, 500),
        "max_depth": ("int", 5, 25),
        "min_samples_split": ("int", 2, 20),
        "min_samples_leaf": ("int", 1, 10),
        "max_features": ("float", 0.4, 1.0),
        "random_state": 42,
        "n_jobs": -1,
    },
}

# Classification variants. Same structure as DEFAULT_SEARCH_SPACE; only the
# objective/loss differs, so a classifier is not accidentally fitted with a
# regression objective.
CLASSIFICATION_SEARCH_SPACE = {
    "xgboost": {
        "n_estimators": ("int", 300, 1500),
        "max_depth": ("int", 4, 12),
        "min_child_weight": ("int", 1, 10),
        "learning_rate": ("float", 1e-3, 0.2, True),
        "gamma": ("float", 1e-8, 1.0, True),
        "reg_alpha": ("float", 1e-4, 10.0, True),
        "reg_lambda": ("float", 1e-4, 10.0, True),
        "subsample": ("float", 0.6, 1.0),
        "colsample_bytree": ("float", 0.4, 0.9),
        "colsample_bylevel": ("float", 0.5, 1.0),
        "tree_method": "hist",
        "objective": "multi:softprob",
        "eval_metric": "mlogloss",
        "random_state": 42,
        "n_jobs": -1,
    },
    "lightgbm": {
        "n_estimators": ("int", 300, 1500),
        "max_depth": ("int", 3, 15),
        "num_leaves": ("int", 20, 300),
        "min_child_samples": ("int", 5, 80),
        "learning_rate": ("float", 1e-3, 0.2, True),
        "reg_alpha": ("float", 1e-4, 10.0, True),
        "reg_lambda": ("float", 1e-4, 10.0, True),
        "subsample": ("float", 0.6, 1.0),
        "subsample_freq": ("int", 1, 5),
        "colsample_bytree": ("float", 0.4, 0.9),
        "path_smooth": ("float", 1e-3, 10.0, True),
        "class_weight": "balanced",
        "objective": "multiclass",
        "random_state": 42,
        "n_jobs": -1,
        "verbosity": -1,
    },
    "catboost": {
        "iterations": ("int", 300, 1500),
        "depth": ("int", 4, 10),
        "learning_rate": ("float", 1e-3, 0.2, True),
        "l2_leaf_reg": ("float", 1.0, 20.0, True),
        "random_strength": ("float", 1e-3, 10.0, True),
        "bagging_temperature": ("float", 0.0, 1.0),
        "auto_class_weights": "Balanced",
        "loss_function": "MultiClass",
        "eval_metric": "MultiClass",
        "random_state": 42,
        "verbose": False,
        "thread_count": -1,
        # Job tasks run from a read-only git checkout; CatBoost's default
        # train_dir (catboost_info/ in cwd) can't be created there.
        "train_dir": "/tmp/catboost_info",
        "allow_writing_files": False,
    },
    "extra_trees": {
        "n_estimators": ("int", 200, 800),
        "max_depth": ("int", 10, 40),
        "min_samples_split": ("int", 2, 15),
        "min_samples_leaf": ("int", 1, 8),
        "max_features": ("float", 0.2, 0.8),
        "criterion": ("categorical", ["gini", "entropy"]),
        "class_weight": "balanced",
        "random_state": 42,
        "n_jobs": -1,
    },
    "hist_gradient_boosting": {
        "max_iter": ("int", 200, 1000),
        "max_depth": ("int", 3, 12),
        "max_leaf_nodes": ("int", 15, 127),
        "min_samples_leaf": ("int", 10, 100),
        "learning_rate": ("float", 1e-3, 0.2, True),
        "l2_regularization": ("float", 1e-8, 10.0, True),
        "class_weight": "balanced",
        "random_state": 42,
    },
    "logistic_regression": {
        "C": ("float", 1e-4, 100.0, True),
        "l1_ratio": ("float", 0.0, 1.0),
        "penalty": "elasticnet",
        "solver": "saga",
        "class_weight": "balanced",
        "max_iter": 2000,
        "random_state": 42,
        "n_jobs": -1,
    },
}


# ── Use cases — the only block to edit for a new model ────────────────────
USE_CASES = {

    # ── Fulfillment risk — CLASSIFICATION ─────────────────────────────────
    "fulfillment_risk": {
        "shared": {
            "name": "fulfillment_risk",
            "catalog": "dev_platform",
            "schema": "mlops",
            "experiment_path": "/Workspace/Users/danduprolu.stuthi@latentview.com/fulfillment_risk-1",
            "model_name": "fulfillment_risk_model_1",   # UC name, without catalog.schema

            "feature_table": "dev_platform.mlops.fulfillment_risk_features",
            "target_table": "dev_platform.mlops.fulfillment_risk_truth",
            "join_keys": ["order_number", "item_number"],
            "source_label_col": "risk_level_encoded",
            "target_col": "risk_level_encoded",

            "date_column": "order_date",
            "min_valid_date": "2000-01-01",

            # Excluded from the feature matrix at BOTH training and scoring.
            "drop_cols": [
                # Identifiers
                "order_number", "item_number",
                # High cardinality; its signal is in the cust_prior_* features
                "customer_number",
                # Raw date — calendar parts carry it
                "order_date",
                # The text label: the same answer the target encodes
                "risk_level",
                # NOTE: available_qty / on_order_qty / in_transit_qty /
                # next_expected_receipt / supply_gap_qty / days_until_fulfillment
                # are never written by feature engineering at all, because the
                # labelling CASE statement reads them.
            ],

            # EMPTY, and it must stay empty for a model that will be served:
            # a pandas Categorical cannot cross the JSON boundary of the
            # endpoint. warehouse is one-hot encoded in feature engineering
            # instead, and customer_number is dropped in favour of customer
            # history features.
            "cat_cols": [],
            "numeric_cols": ["extended_price", "on_hand_qty", "safety_stock",
                             "backorder_qty", "total_backordered"],
            "id_cols": ["order_number", "item_number"],
        },

        "training": {
            # ~3,500 training rows over a short window: smaller validation
            # slices, and min_test_rows low enough that a window can form.
            "split": {"n_splits": 2, "val_weeks": 4, "step_weeks": 2,
                      "min_test_rows": 100},
            "search": {
                "task": "classification",
                "models": ["xgboost", "lightgbm", "catboost","extra_trees","hist_gradient_boosting","logistic_regression"],
                "n_trials": 20,
                # f1_macro: the High-risk class is the one worth predicting and
                # is also the rarest, so accuracy would hide failure on it.
                "primary_metric": "accuracy",
                "metric_names": ["f1_macro", "balanced_accuracy", "accuracy",
                                 "precision_macro", "recall_macro", "log_loss"],
            },
        },

        "registration": {
            "metric_direction": "maximize",     # f1_macro, unlike the error metrics
            "improvement_threshold": 0.0,
            "test_months": 6,
            "min_baseline_rows": 100,
            "registry": {
                "extra_tags": {"use_case": "fulfillment_risk",
                               "task": "classification"},
            },
        },

        "serving": {
            "workload_size": "Small",
            "scale_to_zero_enabled": True,
            "ai_gateway": {
                "usage_tracking_enabled": True,
                "inference_table": {
                    "enabled": True,
                    "catalog_name": "dev_platform",
                    "schema_name": "mlops",
                    "table_name_prefix": "fulfillment_risk_serving_1",
                },
                "rate_limits": [
                    {"calls": 1000, "renewal_period": "minute", "key": "endpoint"},
                    {"calls": 100, "renewal_period": "minute", "key": "user"},
                ],
            },
            "tags": {"use_case": "fulfillment_risk", "owner": "mlops"},
        },
    },
}

    # ── Supplier delay — REGRESSION ───────────────────────────────────────
#     "delay_days": {
#         "shared": {
#             "name": "delay_days",
#             "catalog": "prod_platform",
#             "schema": "mlops",
#             "experiment_path": "/Workspace/Users/danduprolu.stuthi@latentview.com/supplier_delay_2",
#             "model_name": "delay_days_model_1",

#             "feature_table": "prod_platform.mlops.supplier_delay_features",
#             "target_table": "prod_platform.mlops.supplier_delay_ground_truth",
#             "join_keys": ["PONUMBER"],
#             "source_label_col": "delivery_delay_days",
#             "target_col": "delivery_delay_days",

#             "date_column": "DOCDATE",
#             "min_valid_date": "2000-01-01",

#             # THE critical list: it defines the model signature at training
#             # AND the scoring frame. A column belongs here if it is an
#             # identifier, a raw date, or leakage.
#             "drop_cols": [
#                 "PONUMBER",               # identifier
#                 "VENDORID",               # identifier; vendor_* features cover it
#                 "DOCDATE",                # raw date; calendar features cover it
#                 "actual_lead_time_days",  # arrives from the ground-truth table
#             ],
#             # Deliberately empty — the feature table is already encoded.
#             "cat_cols": [],
#             # Numbers that arrive as DECIMAL/text; cast with pd.to_numeric.
#             "numeric_cols": [
#                 "FRTAMNT", "cancellation_rate",
#                 "avg_date_pushed", "avg_negotiation_gap",
#                 "vendor_avg_delay", "vendor_delay_rate", "vendor_avg_lead_time",
#                 "vendor_delay_stddev",
#                 "rolling_90d_avg_delay", "rolling_90d_delay_rate",
#             ],
#             "id_cols": ["PONUMBER"],
#         },

#         "training": {
#             "split": {"n_splits": 2, "val_weeks": 8, "step_weeks": 4,
#                       "min_test_rows": 50},
#             "search": {
#                 "models": ["xgboost", "lightgbm", "catboost"],
#                 "n_trials": 20,
#                 "primary_metric": "mae",
#             },
#         },

#         "registration": {
#             "improvement_threshold": 0.0,
#             "test_months": 6,
#             "min_baseline_rows": 200,
#             "registry": {"extra_tags": {"use_case": "supplier_delay"}},
#         },

#         "serving": {
#             "workload_size": "Small",
#             "scale_to_zero_enabled": True,
#             "ai_gateway": {
#                 "usage_tracking_enabled": True,
#                 "inference_table": {
#                     "enabled": True,
#                     "catalog_name": "prod_platform",
#                     "schema_name": "mlops",
#                     "table_name_prefix": "delay_days_serving",
#                 },
#                 "rate_limits": [
#                     {"calls": 1000, "renewal_period": "minute", "key": "endpoint"},
#                     {"calls": 100, "renewal_period": "minute", "key": "user"},
#                 ],
#             },
#             "tags": {"use_case": "supplier_delay", "owner": "mlops"},
#         },
#     },
# }
