"""
job_config.py — INPUTS ONLY
----------------------------
What each of the three Lakeflow Jobs runs. Plain dictionaries, no code: the
validation lives in src/settings/job_settings.py and the stage runner in
src/jobs/runner.py.

    jobs/feature_engineering_job.py  -> JOBS["feature_engineering"]
    jobs/mlops_process_job.py        -> JOBS["mlops_process"]
    jobs/monitoring_job.py           -> JOBS["monitoring"]

The names below (feature sets, use case, monitor) are keys of FEATURE_SETS
(feature_config.py), USE_CASES (mlops_config.py) and MONITORING_CONFIGS
(monitoring_config.py); every table, column and threshold comes from there.

Approval flags replace the notebook's `approve` widget. A job runs unattended,
so the stages that change shared state (register, serve, baseline, rollback)
only act when their flag is True; otherwise they log what they would do.
Set a flag to True after reviewing the previous run, then re-run the job.
"""

JOBS = {

    # ── 1. Feature engineering ───────────────────────────────────────────────────
    # Builds the feature + truth tables for each feature set, in order.
    # Training features first, then validation (it borrows training history).
    "feature_engineering": {
        "feature_sets": ["fulfillment_risk", "fulfillment_risk_validation"],
        # Run a dry run (resolve source, validate spec, no writes) before each
        # real build, so a bad spec fails before any table is overwritten.
        "dry_run_first": True,
    },

    # ── 2. MLOps process: train -> review -> register -> status -> serve ────────────
    "mlops_process": {
        "use_case": "fulfillment_risk",
        # Run in this order; remove a name to skip that stage.
        "stages": ["train", "review", "register", "status", "serve"],
        "approve_register": True,     # True = register the best run / move aliases
        "approve_serve": True,        # True = deploy the Champion to the endpoint
        "skip_baseline": False,        # register: skip the registration baseline
        "wait_for_endpoint": True,     # serve: wait until the endpoint is READY
    },

    # ── 3. Monitoring: score -> monitor -> drift / degradation -> rollback ─────────
    "monitoring": {
        "monitor": "fulfillment_risk",
        # Run in this order; remove a name to skip that stage.
        #   score          batch predictions for periods not yet scored
        #   shift_dates    replay old rows into the monitor window
        #                  (only acts when date_shift_days > 0 in monitoring_config)
        #   baseline       training rows scored by the Champion (gated)
        #   monitor        refresh the Lakehouse monitor (+ dashboard sync)
        #   drift          have the inputs moved?            (detection only)
        #   degradation    has live error worsened?          (detection only)
        #   sync_dashboard repair + verify the monitor dashboard
        #   visualize      prediction / drift / fairness charts (job output)
        #   rollback       promote the Challenger if degraded (gated)
        "stages": ["score", "shift_dates", "baseline", "monitor", "drift",
                   "degradation", "sync_dashboard", "visualize", "rollback"],
        "approve_baseline": False,     # True = overwrite the baseline table
        "approve_rollback": False,     # True = allow the alias swap
        "recreate_monitor": False,     # True only after the inference schema changed
        "wait_for_refresh": True,      # monitor: wait for the refresh to finish
        # While replaying (date_shift_days > 0), scoring again would re-add the
        # original, unshifted dates. Skip score once the shift is in place.
        "skip_score_when_replayed": True,
    },
}
