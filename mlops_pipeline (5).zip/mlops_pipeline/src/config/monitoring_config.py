"""
monitoring_config.py — INPUTS ONLY
-----------------------------------
Batch scoring, Lakehouse monitoring, drift, rollback and alerting inputs, as
plain dictionaries.

No classes, no functions: the dataclasses, validation, SQL helpers and the
builder that turns these dicts into MonitoringConfig objects live in
src/settings/monitoring_settings.py.

Two kinds of entry:
  DERIVED     "use_case": "<name>" — feature table, model name, label column,
              merge keys and excluded columns come from mlops_config; the
              other keys are the arguments of from_use_case().
  STANDALONE  "use_case": None — every key is a MonitoringConfig field.

"slice_groups" (optional) describes a grouping column; it is expanded into
the monitor's slicing expressions (one binary slice per group, needed for
fairness metrics) and the enrichment that adds the column at scoring time.

    python -m src.monitoring.batch_inference  --monitor weekly_orders
    python -m src.monitoring.lakehouse_monitor --monitor weekly_orders
    python -m src.monitoring.check_drift       --monitor weekly_orders
    python -m src.monitoring.check_rollback    --monitor weekly_orders
    python -m src.monitoring.rollback          --monitor weekly_orders --approve
"""

# ── Monitoring config selected when none is given ─────────────────────────
DEFAULT_MONITORING = "delay_days"

# ── Shared values ──────────────────────────────────────────────────────
ASSETS_DIR = "/Workspace/Users/danduprolu.stuthi@latentview.com/monitoring_assets"
ALERT_RECIPIENTS = ["danduprolu.stuthi@latentview.com"]
WEEKLY_ORDERS_CATALOG = "ds_training_1"

# fulfillment_risk warehouse grouping. shares = % of rows per group; they
# drive the hash fallback, and their ORDER defines the CASE default (last).
FR_SLICE_GROUPS = {
    "column": "warehouse_group",          # column added to the inference table
    "source_column": "warehouse",         # raw column it is derived from
    "hash_key": "order_number",           # key for the deterministic fallback
    "shares": {"PHX": 45, "LVL": 33, "ELP": 22},
    "lookup_feature_set": "fulfillment_risk",   # source table with the raw value
    "lookup_use_case": "fulfillment_risk",      # join keys for the lookup
}


# ── Monitored use cases ─────────────────────────────────────────────────
MONITORING_CONFIGS = {

    # ── fulfillment_risk — DERIVED, classification ────────────────────────
    # problem_type, the monitor metric and the rollback direction all follow
    # from search.task in mlops_config — nothing restated here.
    "fulfillment_risk": {
        "use_case": "fulfillment_risk",
        "inference_schema": "dev_platform.mlops",
        "monitor_schema": "dev_platform.mlops",
        # Score the held-back validation rows and compare against their labels.
        "scoring_feature_table": "dev_platform.mlops.fulfillment_risk_validation_features",
        "scoring_target_table": "dev_platform.mlops.fulfillment_risk_validation_truth",
        "assets_dir": ASSETS_DIR,

        # The business date, not the scoring time: a backfill stamps every row
        # with the same prediction_timestamp, which would collapse all rows
        # into one window.
        "time_column": "order_date",
        "monitor_time_basis": "event",

        # Per-warehouse slices for fairness metrics (see FR_SLICE_GROUPS).
        "slice_groups": FR_SLICE_GROUPS,

        # Score the challenger next to the deployed version so the dashboard
        # can compare model versions. Skipped (with a warning) if not set.
        "compare_model_refs": ["challenger"],
        "viz": {"class_labels": {"0": "Low Risk", "1": "Med-Low",
                                 "2": "Med-High", "3": "High Risk"}},

        # "endpoint" scores through the serving endpoint, so the monitored
        # predictions are the ones production returns; "local" loads the model.
        # "local" while on dev_platform: fulfillment-risk-endpoint serves the
        # prod_platform model, not dev_platform.mlops.fulfillment_risk_model_1.
        "scoring_mode": "local",
        "endpoint_batch_size": 100,

        # The validation rows span ~5 days, so "1 day" gives ~5 windows to
        # compare; a 4-week granularity would put every row in one window.
        "granularities": ["2 day"],

        # The validation rows span Sep 16-21; the monitor's 30-day lookback
        # from creation would exclude them. +25 days lands them on Oct 11-16.
        "date_shift_days": 30,

        "alerts": {
            "enabled": True,
            "recipients": ALERT_RECIPIENTS,
            "subject_prefix": "[MLOps][fulfillment_risk]",
        },
    }

    # ── delay_days — DERIVED from mlops_config ────────────────────────────
    # "delay_days": {
    #     "use_case": "delay_days",
    #     "inference_schema": "prod_platform.mlops",
    #     "monitor_schema": "prod_platform.mlops",
    #     "assets_dir": ASSETS_DIR,
    #     "time_column": "DOCDATE",
    #     "alerts": {
    #         "enabled": False,
    #         "recipients": ALERT_RECIPIENTS,
    #         "subject_prefix": "[MLOps][delay_days]",
    #     },
    # },
}

#     # ── weekly_orders — STANDALONE ────────────────────────────────────────
#     # Not wired to a use case in mlops_config; monitors the dataco demand
#     # model. Kept as a fully-written example: every key is a field.
#     "weekly_orders": {
#         "use_case": None,
#         "name": "weekly_orders",
#         "catalog": WEEKLY_ORDERS_CATALOG,
#         "schema": "mlops_models",
#         "model_name": "weekly_demand_forecast_HPOv2",

#         "batch": {
#             "feature_table": f"{WEEKLY_ORDERS_CATALOG}.mlops_featurestore.weekly_orders",
#             "inference_table": f"{WEEKLY_ORDERS_CATALOG}.mlops_inference_results.weekly_orders_predictions",
#             "actual_target_table": f"{WEEKLY_ORDERS_CATALOG}.mlops_ground_truth_schema.weekly_orders_target",
#             # The grain of one prediction, used as the MERGE key so re-scoring
#             # a period updates its rows instead of appending duplicates.
#             "merge_keys": ["week", "product", "category", "department",
#                            "country", "state"],
#             "time_column": "week",
#             "prediction_col": "prediction_final",
#             "label_col": "target_qty",
#             "max_periods_per_run": 52,
#         },

#         "monitor": {
#             "enabled": True,
#             "output_schema": f"{WEEKLY_ORDERS_CATALOG}.mlops_monitoringtables",
#             "assets_dir": ASSETS_DIR,
#             "baseline_table": f"{WEEKLY_ORDERS_CATALOG}.mlops_monitoringtables.weekly_orders_baseline",
#             "problem_type": "regression",
#             "granularities": ["4 weeks"],
#             "prediction_col": "prediction_final",
#             # THE actual outcome column — never the prediction column.
#             "label_col": "target_qty",
#             "model_id_col": "model_version",
#             "timestamp_col": "prediction_timestamp",
#         },

#         "drift": {
#             "drift_table": f"{WEEKLY_ORDERS_CATALOG}.mlops_inference_results.weekly_orders_predictions_drift_metrics",
#             # p-value below threshold = drifted (KS numeric, chi-squared categorical).
#             "ks_pvalue_threshold": 0.05,
#             "chi_pvalue_threshold": 0.05,
#             # 1-2 drifting columns out of ~40 is noise; alert from 5.
#             "min_drifted_columns": 5,
#             # Never drift signals: monitor summary row, identifiers, outputs.
#             "exclude_columns": [
#                 ":table", "product", "category", "department", "country", "state",
#                 "model_name", "model_version", "week",
#                 "prediction_timestamp", "prediction_final", "target_qty",
#             ],
#             "wait_seconds_before_read": 0,
#         },

#         "rollback": {
#             # Live error must be 20% worse than in training...
#             "metric_pct_increase": 0.20,
#             # ...for 3 windows in a row.
#             "consecutive_windows": 3,
#             # Quiet period after a rollback.
#             "settling_hours": 24,
#             # monitor_metric: column in <inference_table>_profile_metrics;
#             # training_metric: what the Champion's MLflow run logged.
#             "monitor_metric": "mean_absolute_error",
#             "training_metric": "best_weighted_mean_mae",
#         },

#         "alerts": {
#             "enabled": False,
#             "recipients": ALERT_RECIPIENTS,
#             "subject_prefix": "[MLOps][weekly_orders]",
#         },

#         "control_table": f"{WEEKLY_ORDERS_CATALOG}.mlops_monitoringtables.mlops_pipeline_control",
#     },
# }
