"""
diagnose_monitor.py
-------------------
Checks the inference table against what the monitor requires.

    python -m src.monitoring.diagnose_monitor --monitor fulfillment_risk

A refresh reports FAILED without saying why. Almost always it is the column
contract rather than infrastructure, and all of it is checkable from the table
itself — in seconds, instead of another 29-minute refresh.
"""
from __future__ import annotations

import argparse
import logging
import sys
from typing import Any, Dict, List, Optional

from pyspark.sql import functions as F

from src.settings.monitoring_settings import (
    DEFAULT_MONITORING,
    MONITORING_CONFIGS,
    MonitoringConfig,
    get_monitoring_config,
)

logging.basicConfig(level=logging.INFO, format="%(levelname)-8s %(message)s")
logger = logging.getLogger(__name__)


def _granularity_days(granularity: str) -> Optional[float]:
    """Approximate day count for a Databricks granularity string."""
    if not granularity:
        return None
    parts = str(granularity).strip().split()
    if len(parts) == 1:
        count, unit = 1, parts[0]
    elif len(parts) == 2 and parts[0].isdigit():
        count, unit = int(parts[0]), parts[1]
    else:
        return None
    unit = unit.rstrip("s").lower()
    per_unit = {"minute": 1 / 1440, "hour": 1 / 24, "day": 1,
                "week": 7, "month": 30, "quarter": 91, "year": 365}
    return count * per_unit[unit] if unit in per_unit else None


def diagnose(spark, cfg: MonitoringConfig) -> Dict[str, Any]:
    m, b = cfg.monitor, cfg.batch
    table = b.inference_table
    problems: List[str] = []

    if not spark.catalog.tableExists(table):
        raise ValueError(f"Inference table '{table}' does not exist. "
                         f"Run the score stage first.")

    df = spark.read.table(table)
    dtypes = dict(df.dtypes)
    total = df.count()

    logger.info("Inference table : %s", table)
    logger.info("Rows            : %d", total)
    logger.info("Problem type    : %s", m.problem_type)

    # ---- 1. required columns exist -------------------------------------
    required = {
        "prediction_col": m.prediction_col,
        "label_col": m.label_col,
        "model_id_col": m.model_id_col,
        "timestamp_col": m.timestamp_col,
    }
    logger.info("\n-- required columns --")
    for role, col in required.items():
        present = col in dtypes
        logger.info("  %-15s %-24s %s", role, col,
                    dtypes.get(col, "MISSING"))
        if not present:
            problems.append(f"{role} '{col}' is not in the table.")

    if problems:
        for p in problems:
            logger.error("  %s", p)
        return {"problems": problems}

    pred_type = dtypes[m.prediction_col]
    label_type = dtypes[m.label_col]

    # ---- 2. dtype match (the usual culprit) ----------------------------
    logger.info("\n-- dtype contract --")
    if m.problem_type == "classification":
        if pred_type != label_type:
            problems.append(
                f"prediction '{m.prediction_col}' is {pred_type} but label "
                f"'{m.label_col}' is {label_type}. A classification monitor "
                f"requires the SAME type — cast predictions to {label_type}."
            )
            logger.error("  MISMATCH: %s (%s) vs %s (%s)",
                         m.prediction_col, pred_type, m.label_col, label_type)
        else:
            logger.info("  OK: both %s", pred_type)
    else:
        numeric = ("double", "float", "int", "bigint", "decimal")
        for role, col, typ in (("prediction", m.prediction_col, pred_type),
                               ("label", m.label_col, label_type)):
            if not any(typ.startswith(n) for n in numeric):
                problems.append(f"{role} '{col}' is {typ}; a regression "
                                f"monitor needs a numeric column.")
        logger.info("  prediction=%s label=%s", pred_type, label_type)

    if not dtypes[m.model_id_col].startswith("string"):
        problems.append(
            f"model_id_col '{m.model_id_col}' is {dtypes[m.model_id_col]}; "
            f"the monitor expects a string."
        )
    ts_type = dtypes.get(m.timestamp_col, "")
    if ts_type.startswith("date") and not ts_type.startswith("timestamp"):
        # A DATE column is accepted by some paths and silently produces no
        # windows in others. TIMESTAMP is what the monitor expects.
        problems.append(
            f"timestamp_col '{m.timestamp_col}' is DATE, not TIMESTAMP. The "
            f"monitor may fail to form windows from it. Cast it in the "
            f"inference table:\n"
            f"    ALTER TABLE {cfg.batch.inference_table} "
            f"ALTER COLUMN {m.timestamp_col} TYPE TIMESTAMP;\n"
            f"or cast at write time in batch_inference."
        )
    elif not ts_type.startswith("timestamp"):
        problems.append(
            f"timestamp_col '{m.timestamp_col}' is {dtypes[m.timestamp_col]}; "
            f"the monitor expects a timestamp."
        )

    # ---- 3. labels actually present ------------------------------------
    logger.info("\n-- label coverage --")
    non_null = df.filter(F.col(m.label_col).isNotNull()).count()
    logger.info("  non-null labels: %d / %d (%.1f%%)",
                non_null, total, 100 * non_null / total if total else 0)
    if non_null == 0:
        problems.append(
            f"Every '{m.label_col}' is NULL. The monitor cannot compute any "
            f"error metric, and the refresh fails. Check that the actuals "
            f"table joined during scoring: {b.actual_target_table}"
        )

    # ---- 4. baseline schema agreement ----------------------------------
    if m.baseline_table:
        logger.info("\n-- baseline table --")
        if not spark.catalog.tableExists(m.baseline_table):
            problems.append(
                f"baseline_table '{m.baseline_table}' does not exist. Either "
                f"create it or set baseline_table=None."
            )
            logger.error("  MISSING: %s", m.baseline_table)
        else:
            base_cols = set(spark.read.table(m.baseline_table).columns)
            infer_cols = set(df.columns)
            missing = [c for c in (m.prediction_col, m.label_col)
                       if c not in base_cols]
            logger.info("  columns: baseline=%d inference=%d shared=%d",
                        len(base_cols), len(infer_cols),
                        len(base_cols & infer_cols))
            if missing:
                problems.append(
                    f"Baseline '{m.baseline_table}' lacks {missing}. The "
                    f"baseline must carry the same prediction and label "
                    f"columns as the inference table."
                )

    # ---- 5. granularity vs data span -----------------------------------
    logger.info("\n-- time span --")
    span = df.select(F.min(m.timestamp_col).alias("lo"),
                     F.max(m.timestamp_col).alias("hi")).collect()[0]
    logger.info("  %s -> %s", span["lo"], span["hi"])
    logger.info("  granularities: %s", m.granularities)

    # A span shorter than the granularity means ONE window, and a single
    # window has nothing to be compared against — drift metrics stay empty
    # however many times the monitor refreshes.
    try:
        span_rows = df.select(F.min(m.timestamp_col).alias("lo"),
                              F.max(m.timestamp_col).alias("hi")).collect()[0]
        lo, hi = span_rows["lo"], span_rows["hi"]
        if lo is not None and hi is not None:
            span_days = (hi - lo).total_seconds() / 86400
            gran = (m.granularities or ["?"])[0]
            logger.info("  span: %.2f day(s)", span_days)
            # Compare the span against the granularity, not against a day.
            # Windows are only comparable if several of them exist; a 5-day
            # span under a 4-week granularity is one bucket, and one bucket
            # has nothing to drift against.
            gran_days = _granularity_days(gran)
            if gran_days and span_days < gran_days:
                n_windows = max(1, int(span_days // gran_days))
                problems.append(
                    f"data spans {span_days:.1f} day(s) but the granularity is "
                    f"'{gran}' (~{gran_days:.0f} days), so everything lands in "
                    f"{n_windows} window. Drift compares windows against each "
                    f"other, so a single window yields nothing. Set a "
                    f"granularity shorter than the span — '1 day' would give "
                    f"about {int(span_days)} windows here — in "
                    f"monitoring_config.py."
                )
            elif span_days < 1:
                problems.append(
                    f"timestamp_col '{m.timestamp_col}' spans only "
                    f"{span_days * 24:.1f} hour(s) across {total} rows, but the "
                    f"granularity is '{gran}'. Every row lands in ONE window, "
                    f"so there is nothing to compare and drift stays empty. "
                    f"This is what happens when the timestamp is the SCORING "
                    f"time rather than the business date — a backfill stamps "
                    f"every row with the same instant. Set "
                    f"monitor_time_basis='event' so windows follow the event "
                    f"date."
                )
    except Exception as exc:
        logger.debug("Could not measure the span: %s", exc)
    if span["lo"] == span["hi"]:
        logger.warning(
            "  Every row shares one timestamp — the monitor cannot form more "
            "than one window, so drift between windows is undefined."
        )

    logger.info("\n%s", "=" * 70)
    if problems:
        logger.error("%d problem(s) found:", len(problems))
        for i, p in enumerate(problems, 1):
            logger.error("  %d. %s", i, p)
    else:
        logger.info("No contract problems found. If the refresh still fails, "
                    "check the monitor's job run in the Databricks UI "
                    "(Quality tab on the table) for the driver error.")
    return {"problems": problems, "rows": total,
            "prediction_type": pred_type, "label_type": label_type}


# ──────────────────────────────────────────────────────────────────────────
# Monitoring charts (read-only). Every table / column / style setting comes
# from the MonitoringConfig (cfg.batch, cfg.drift, cfg.monitor, cfg.viz).
# ──────────────────────────────────────────────────────────────────────────
_NUMERIC_TYPES = ["double", "float", "int", "long", "integer", "bigint"]


def _metric_table(cfg: MonitoringConfig, kind: str) -> str:
    """Profile/drift table the monitor actually writes (config fallback)."""
    try:
        from src.monitoring.lakehouse_monitor import metric_tables
        name = metric_tables(cfg).get(kind)
        if name:
            return name
    except Exception:
        pass
    return (cfg.drift.drift_table if kind == "drift"
            else f"{cfg.batch.inference_table}_profile_metrics")


def _no_data(ax, text):
    ax.text(0.5, 0.5, text, ha="center", va="center", transform=ax.transAxes)


def plot_prediction_distribution(spark, cfg: MonitoringConfig):
    """Chart 1 — prediction class counts per model version over time."""
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates
    import numpy as np
    import pandas as pd

    b, v = cfg.batch, cfg.viz
    T, P, M = b.time_column, b.prediction_col, b.model_version_col
    agg = (spark.table(b.inference_table).groupBy(M, T, P).count()
           .orderBy(M, T, P).toPandas())
    agg[T] = pd.to_datetime(agg[T])
    agg[P] = agg[P].astype(str)

    classes = sorted(agg[P].unique())
    colors = {c: v.palette[i % len(v.palette)] for i, c in enumerate(classes)}
    prefix = "Class" if cfg.monitor.problem_type == "classification" else "Bin"
    labels = {c: v.class_labels.get(c, f"{prefix} {c}") for c in classes}
    versions = sorted(agg[M].unique())

    fig, axes = plt.subplots(1, max(len(versions), 1),
                             figsize=(7 * max(len(versions), 1), 5), squeeze=False)
    fig.suptitle(f"Prediction Distribution by Model Version — {cfg.name}",
                 fontsize=14, fontweight="bold")
    for idx, mv in enumerate(versions):
        ax = axes[0][idx]
        data = agg[agg[M] == mv]
        dates = sorted(data[T].unique())
        bottom = np.zeros(len(dates))
        for cls in classes:
            vals = (data[data[P] == cls].set_index(T).reindex(dates).fillna(0)["count"]
                    .values.astype(float))
            ax.bar(dates, vals, bottom=bottom, label=labels[cls], color=colors[cls],
                   width=0.6, edgecolor="white", linewidth=0.5)
            bottom += vals
        ax.set_title(f"Model v{mv}", fontsize=12)
        ax.set_xlabel(T)
        ax.set_ylabel("Prediction Count")
        ax.legend(title="Class", fontsize=8, title_fontsize=9)
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d"))
        ax.tick_params(axis="x", rotation=45)
        ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    plt.show()
    return {"versions": [str(x) for x in versions], "classes": classes}


def plot_drift(spark, cfg: MonitoringConfig):
    """Chart 2 — KS / JS / Wasserstein drift over time."""
    import matplotlib.pyplot as plt
    import pandas as pd

    d, b, v = cfg.drift, cfg.batch, cfg.viz
    P = b.prediction_col
    drift = spark.table(_metric_table(cfg, "drift"))
    # One row per (window, column): un-sliced, all-versions aggregate, one drift type.
    scoped = (drift.filter(F.col("slice_key").isNull())
              .filter(F.col("drift_type") == v.drift_chart_type))
    if scoped.filter(F.col("model_version") == cfg.dashboard.model_all_token).limit(1).count():
        scoped = scoped.filter(F.col("model_version") == cfg.dashboard.model_all_token)
    drift = scoped

    num = (drift.filter(~F.col("column_name").isin(d.exclude_columns))
           .filter(F.col("ks_test").isNotNull())
           .select(F.col("window.end").alias("window_end"), "column_name",
                   F.col("ks_test.statistic").alias("ks_statistic"),
                   F.col("ks_test.pvalue").alias("ks_pvalue"), "wasserstein_distance")
           .toPandas())
    num["window_end"] = pd.to_datetime(num["window_end"])
    pred = (drift.filter(F.col("column_name") == P)
            .filter(F.col("chi_squared_test").isNotNull())
            .select(F.col("window.end").alias("window_end"),
                    F.col("chi_squared_test.statistic").alias("chi_statistic"),
                    "js_distance")
            .toPandas())
    pred["window_end"] = pd.to_datetime(pred["window_end"])
    pred = pred.sort_values("window_end")

    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    fig.suptitle(f"Prediction & Feature Drift Over Time — {cfg.name}",
                 fontsize=14, fontweight="bold")

    ax = axes[0, 0]
    if not num.empty:
        ks = num.groupby("window_end")["ks_statistic"].agg(["mean", "max"]).reset_index()
        ax.plot(ks["window_end"], ks["mean"], "o-", color=v.palette[4], label="Mean KS", linewidth=2)
        ax.plot(ks["window_end"], ks["max"], "s--", color=v.palette[3], label="Max KS",
                linewidth=1.5, alpha=0.7)
        ax.axhline(y=v.ks_alert_statistic, color="gray", linestyle=":", alpha=0.5,
                   label=f"Alert {v.ks_alert_statistic}")
    else:
        _no_data(ax, "No KS test data")
    ax.set_title("KS Statistic (Numeric Features)")
    ax.set_ylabel("KS Statistic")

    ax = axes[0, 1]
    if not pred.empty:
        js = pred.dropna(subset=["js_distance"])
        col, lab = (("js_distance", "JS Distance") if not js.empty
                    else ("chi_statistic", "Chi-sq Stat"))
        src = js if not js.empty else pred
        ax.plot(src["window_end"], src[col], "D-", color=v.palette[5], linewidth=2, label=lab)
        ax.fill_between(src["window_end"], 0, src[col], alpha=0.2, color=v.palette[5])
    else:
        _no_data(ax, f"No drift data for {P}")
    ax.set_title(f"{P} Drift Over Time")
    ax.set_ylabel("Distance / Statistic")

    ax = axes[1, 0]
    if not num.empty:
        top = (num.groupby("column_name")["ks_statistic"].mean()
               .nlargest(v.top_n_drift_features).index.tolist())
        for feat in top:
            fd = num[num["column_name"] == feat].sort_values("window_end")
            ax.plot(fd["window_end"], fd["ks_pvalue"], "o-", label=feat, linewidth=1.5, markersize=4)
        ax.axhline(y=d.ks_pvalue_threshold, color="red", linestyle="--", alpha=0.7,
                   label=f"p={d.ks_pvalue_threshold}")
        ax.set_yscale("log")
    else:
        _no_data(ax, "No KS p-value data")
    ax.set_title(f"KS p-value by Feature (Top {v.top_n_drift_features} Drifters)")
    ax.set_ylabel("p-value")

    ax = axes[1, 1]
    wass = num.dropna(subset=["wasserstein_distance"]) if not num.empty else num
    if not wass.empty:
        wa = wass.groupby("window_end")["wasserstein_distance"].agg(["mean", "median"]).reset_index()
        ax.bar(wa["window_end"], wa["mean"], width=0.6, color=v.palette[6], alpha=0.7, label="Mean")
        ax.plot(wa["window_end"], wa["median"], "o-", color=v.palette[3], linewidth=2, label="Median")
    else:
        _no_data(ax, "No Wasserstein data")
    ax.set_title("Wasserstein Distance (Numeric Features)")
    ax.set_ylabel("Distance")

    for ax in axes.ravel():
        ax.legend(fontsize=7)
        ax.grid(alpha=0.3)
        ax.tick_params(axis="x", rotation=45)
    plt.tight_layout()
    plt.show()
    return {"numeric_rows": len(num), "prediction_rows": len(pred)}


def plot_quantile_drift(spark, cfg: MonitoringConfig):
    """Chart 3 — numeric feature quantile bands over time."""
    import matplotlib.pyplot as plt
    import pandas as pd

    v = cfg.viz
    base = (spark.table(_metric_table(cfg, "profile"))
            .filter(F.col("quantiles").isNotNull())
            .filter(F.col("log_type") == "INPUT")
            .filter(F.col("slice_key").isNull())
            .filter(~F.col("column_name").isin(cfg.drift.exclude_columns))
            .filter(F.col("data_type").isin(*_NUMERIC_TYPES)))
    cols = [F.col("window.end").alias("window_end"), "column_name", "quantiles"]
    q = base.filter(F.col("model_version") != cfg.dashboard.model_all_token).select(*cols).toPandas()
    if q.empty:
        q = base.select(*cols).toPandas()
    q["window_end"] = pd.to_datetime(q["window_end"])
    for i, ql in enumerate(v.quantile_labels):
        q[ql] = q["quantiles"].apply(lambda x, i=i: x[i] if x is not None and len(x) > i else None)

    n = v.quantile_panels
    lo, q1, med, q3, hi = (v.quantile_labels[k] for k in (1, 2, 3, 4, 5))
    feats = q.groupby("column_name")[med].std().dropna().nlargest(n).index.tolist() \
        or q["column_name"].unique()[:n].tolist()
    ncols = 3
    nrows = max(1, -(-n // ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(6 * ncols, 5 * nrows), squeeze=False)
    fig.suptitle(f"Numerical Feature Quantile Drift — {cfg.name}", fontsize=14, fontweight="bold")
    for idx, feat in enumerate(feats):
        ax = axes[idx // ncols][idx % ncols]
        fd = q[q["column_name"] == feat].sort_values("window_end")
        dt = fd["window_end"]
        ax.fill_between(dt, fd[q1], fd[q3], alpha=0.3, color=v.palette[4], label=f"IQR ({q1}-{q3})")
        ax.fill_between(dt, fd[lo], fd[hi], alpha=0.15, color=v.palette[0], label=f"{lo}-{hi}")
        ax.plot(dt, fd[med], "o-", color=v.palette[3], linewidth=2, markersize=5, label="Median")
        ax.plot(dt, fd[v.quantile_labels[0]], "v", color="gray", markersize=4, alpha=0.5, label="Min")
        ax.plot(dt, fd[v.quantile_labels[-1]], "^", color="gray", markersize=4, alpha=0.5, label="Max")
        ax.set_title(feat, fontsize=10)
        ax.tick_params(axis="x", rotation=45, labelsize=8)
        ax.grid(alpha=0.3)
        if idx == 0:
            ax.legend(fontsize=7, loc="upper left")
    for idx in range(len(feats), nrows * ncols):
        axes[idx // ncols][idx % ncols].set_visible(False)
    plt.tight_layout()
    plt.show()
    return {"features": feats, "windows": int(q["window_end"].nunique())}


def plot_fairness(spark, cfg: MonitoringConfig):
    """Chart 4 — per-group fairness ratios vs the overall rate, over time."""
    import matplotlib.pyplot as plt
    import numpy as np
    import pandas as pd
    from src.monitoring.lakehouse_monitor import protected_groups

    b, v = cfg.batch, cfg.viz
    binary = set(protected_groups(cfg))
    group_exprs = [e for e in cfg.monitor.slicing_exprs if e not in binary]
    if not group_exprs:
        logger.info("No grouping slicing_expr configured — fairness chart skipped.")
        return {"skipped": True}
    T, P, L, G = b.time_column, b.prediction_col, b.label_col, "_fairness_group"
    pdf = (spark.table(b.inference_table).withColumn(G, F.expr(group_exprs[0]))
           .select(T, P, L, G).toPandas())
    pdf[T] = pd.to_datetime(pdf[T])
    pred = pd.to_numeric(pdf[P], errors="coerce")
    label = pd.to_numeric(pdf[L], errors="coerce")
    if cfg.monitor.problem_type == "classification":
        classes = sorted(pred.dropna().unique())
        thr = classes[len(classes) // 2] if classes else 0
    else:
        thr = pred.median()
    pdf["pp"], pdf["ap"] = (pred >= thr).astype(int), (label >= thr).astype(int)

    rows = []
    for (dt, g), grp in pdf.groupby([T, G]):
        tp = int(((grp.pp == 1) & (grp.ap == 1)).sum()); fn = int(((grp.pp == 0) & (grp.ap == 1)).sum())
        fp = int(((grp.pp == 1) & (grp.ap == 0)).sum()); tn = int(((grp.pp == 0) & (grp.ap == 0)).sum())
        rows.append({T: dt, "group": g,
                     "demographic_parity": grp.pp.mean(),
                     "equal_opportunity": tp / (tp + fn) if tp + fn else np.nan,
                     "predictive_equality": fp / (fp + tn) if fp + tn else np.nan,
                     "predictive_parity": tp / (tp + fp) if tp + fp else np.nan})
    fair = pd.DataFrame(rows)
    metrics = [("demographic_parity", "Demographic Parity Ratio", "Positive-prediction rate per group vs overall"),
               ("equal_opportunity", "Equal Opportunity Ratio", "TPR per group vs overall"),
               ("predictive_equality", "Predictive Equality Ratio", "FPR per group vs overall"),
               ("predictive_parity", "Predictive Parity Ratio", "PPV per group vs overall")]
    for m, _, _ in metrics:
        fair[f"{m}_ratio"] = fair[m] / fair.groupby(T)[m].transform("mean").replace(0, np.nan)

    groups = sorted(fair["group"].dropna().unique())
    colors = {g: v.palette[(i + 4) % len(v.palette)] for i, g in enumerate(groups)}
    lo, hi = v.fairness_band
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    fig.suptitle(f"Fairness Ratio Over Time (by {group_exprs[0]}) — {cfg.name}",
                 fontsize=14, fontweight="bold")
    for idx, (m, title, sub) in enumerate(metrics):
        ax = axes[idx // 2][idx % 2]
        for g in groups:
            gd = fair[fair["group"] == g].sort_values(T)
            ax.plot(gd[T], gd[f"{m}_ratio"], "o-", color=colors[g], label=g, linewidth=2, markersize=5)
        ax.axhline(y=1.0, color="black", linestyle="--", alpha=0.5, label="Parity (1.0)")
        ax.axhspan(lo, hi, alpha=0.08, color="green", label=f"{lo:.0%}-{hi:.0%} band")
        ax.set_title(f"{title}\n{sub}", fontsize=10)
        ax.set_ylabel("Ratio")
        ax.legend(fontsize=8)
        ax.grid(alpha=0.3)
        ax.tick_params(axis="x", rotation=45)
    plt.tight_layout()
    plt.show()
    return {"group_expr": group_exprs[0], "groups": [str(g) for g in groups]}


def render_monitoring_charts(spark, cfg: MonitoringConfig) -> Dict[str, Any]:
    """All four charts; one failing chart does not hide the others."""
    out: Dict[str, Any] = {}
    for name, fn in (("predictions", plot_prediction_distribution), ("drift", plot_drift),
                     ("quantiles", plot_quantile_drift), ("fairness", plot_fairness)):
        try:
            out[name] = fn(spark, cfg)
        except Exception as exc:
            logger.error("Chart '%s' failed: %s", name, exc)
            out[name] = {"error": str(exc)}
    return out


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--monitor", default=DEFAULT_MONITORING,
                        choices=sorted(MONITORING_CONFIGS))
    args, _ = parser.parse_known_args()
    return args


def main() -> int:
    from pyspark.sql import SparkSession
    args = parse_args()
    spark = SparkSession.builder.getOrCreate()
    try:
        result = diagnose(spark, get_monitoring_config(args.monitor))
    except Exception as exc:
        logger.error("Diagnosis failed: %s", exc, exc_info=True)
        return 1
    return 1 if result.get("problems") else 0


if __name__ == "__main__":
    sys.exit(main())