"""
lakehouse_monitor.py
--------------------
Creates or refreshes the Databricks quality monitor over the inference table.

    python -m src.monitoring.lakehouse_monitor --monitor weekly_orders
    python -m src.monitoring.lakehouse_monitor --monitor weekly_orders --refresh
    python -m src.monitoring.lakehouse_monitor --monitor weekly_orders --status

The monitor produces the profile and drift metric tables that check_drift and
check_rollback read, so nothing downstream works until this has run once.
"""
from __future__ import annotations

import argparse
import logging
import sys
import time
from typing import Any, Dict, List, Optional

from src.settings.monitoring_settings import (
    DEFAULT_MONITORING,
    MONITORING_CONFIGS,
    MonitoringConfig,
    get_monitoring_config,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


def _client():
    try:
        from databricks.sdk import WorkspaceClient
    except ImportError as exc:
        raise RuntimeError(
            "databricks-sdk is not installed:\n"
            "    %pip install databricks-sdk --upgrade"
        ) from exc
    return WorkspaceClient()


def _sdk():
    from databricks.sdk.service.catalog import (
        MonitorInferenceLog,
        MonitorInferenceLogProblemType,
        MonitorRefreshInfoState,
    )
    return MonitorInferenceLog, MonitorInferenceLogProblemType, MonitorRefreshInfoState


def monitor_exists(table_name: str, client=None) -> bool:
    from databricks.sdk.errors import ResourceDoesNotExist
    client = client or _client()
    try:
        client.quality_monitors.get(table_name=table_name)
        return True
    except ResourceDoesNotExist:
        return False


def _problem_type(cfg: MonitoringConfig):
    _, ProblemType, _ = _sdk()
    return (ProblemType.PROBLEM_TYPE_REGRESSION
            if cfg.monitor.problem_type == "regression"
            else ProblemType.PROBLEM_TYPE_CLASSIFICATION)


def create_monitor(cfg: MonitoringConfig, client=None) -> Dict[str, Any]:
    MonitorInferenceLog, _, _ = _sdk()
    client = client or _client()
    m = cfg.monitor

    logger.info("Creating monitor on %s", cfg.batch.inference_table)
    logger.info("  prediction=%s | label=%s | model_id=%s | timestamp=%s",
                m.prediction_col, m.label_col, m.model_id_col, m.timestamp_col)

    kwargs = dict(
        table_name=cfg.batch.inference_table,
        assets_dir=m.assets_dir,
        output_schema_name=m.output_schema,
        inference_log=MonitorInferenceLog(
            problem_type=_problem_type(cfg),
            prediction_col=m.prediction_col,
            model_id_col=m.model_id_col,
            label_col=m.label_col,
            timestamp_col=m.timestamp_col,
            granularities=m.granularities,
        ),
    )
    if m.baseline_table:
        kwargs["baseline_table_name"] = m.baseline_table
    if m.slicing_exprs:
        kwargs["slicing_exprs"] = m.slicing_exprs

    monitor = client.quality_monitors.create(**kwargs)
    logger.info("Created. status=%s dashboard=%s",
                getattr(monitor, "status", "?"),
                getattr(monitor, "dashboard_id", "?"))
    return {"action": "created",
            "dashboard_id": getattr(monitor, "dashboard_id", None)}


def refresh_monitor(cfg: MonitoringConfig, wait: bool = True,
                    client=None) -> Dict[str, Any]:
    _, _, RefreshState = _sdk()
    client = client or _client()
    table = cfg.batch.inference_table

    refresh = client.quality_monitors.run_refresh(table_name=table)
    refresh_id = refresh.refresh_id
    logger.info("Refresh %s started for %s", refresh_id, table)

    if not wait:
        return {"action": "refresh_started", "refresh_id": refresh_id}

    deadline = time.time() + cfg.monitor.refresh_timeout_minutes * 60
    info = None
    while True:
        info = client.quality_monitors.get_refresh(
            table_name=table, refresh_id=refresh_id)
        state = info.state
        logger.info("  state: %s", state)
        if state in (RefreshState.SUCCESS, RefreshState.FAILED,
                     RefreshState.CANCELED):
            break
        if time.time() > deadline:
            raise TimeoutError(
                f"Refresh {refresh_id} still running after "
                f"{cfg.monitor.refresh_timeout_minutes} minutes."
            )
        time.sleep(cfg.monitor.refresh_poll_seconds)

    if state != RefreshState.SUCCESS:
        # The state alone says nothing about WHY. Surface every field the SDK
        # returns, then the likely causes — a failed refresh is almost always
        # a column contract problem, not an infrastructure one.
        detail = {k: v for k, v in vars(info).items()
                  if v is not None and not k.startswith("_")}
        raise RuntimeError(
            f"Monitor refresh ended as {state}.\n"
            f"Refresh details: {detail}\n\n"
            f"Most common causes, in order:\n"
            f"  1. prediction_col and label_col have DIFFERENT dtypes. For a "
            f"classification monitor Databricks requires them to match — a "
            f"float prediction against an int label fails.\n"
            f"       prediction_col={cfg.monitor.prediction_col} "
            f"label_col={cfg.monitor.label_col}\n"
            f"  2. label_col is entirely NULL in the window — nothing to "
            f"score against.\n"
            f"  3. model_id_col is not a string.\n"
            f"  4. The baseline table's schema does not match the inference "
            f"table's: {cfg.monitor.baseline_table}\n\n"
            f"Run: python -m src.monitoring.diagnose_monitor --monitor {cfg.name}"
        )
    logger.info("Refresh complete.")
    return {"action": "refreshed", "refresh_id": refresh_id, "state": str(state)}


def metric_tables(cfg: MonitoringConfig, client=None) -> Dict[str, Optional[str]]:
    """
    The profile and drift table names the monitor ACTUALLY writes.

    Constructing these from the inference table name guesses at a convention
    Databricks owns; asking the monitor is authoritative. Returns None values
    when no monitor exists or the first refresh has not produced them yet.
    """
    client = client or _client()
    table = cfg.batch.inference_table
    try:
        monitor = client.quality_monitors.get(table_name=table)
    except Exception as exc:
        logger.info("No monitor on %s (%s).", table, exc)
        return {"profile": None, "drift": None, "status": None}

    return {
        "profile": getattr(monitor, "profile_metrics_table_name", None),
        "drift": getattr(monitor, "drift_metrics_table_name", None),
        "status": str(getattr(monitor, "status", "")),
    }


def monitor_status(cfg: MonitoringConfig, client=None) -> Dict[str, Any]:
    client = client or _client()
    table = cfg.batch.inference_table

    if not monitor_exists(table, client):
        logger.info("No monitor on %s.", table)
        return {"exists": False}

    monitor = client.quality_monitors.get(table_name=table)
    status = {
        "exists": True,
        "status": str(getattr(monitor, "status", "?")),
        "dashboard_id": getattr(monitor, "dashboard_id", None),
        "profile_metrics_table": getattr(monitor, "profile_metrics_table_name", None),
        "drift_metrics_table": getattr(monitor, "drift_metrics_table_name", None),
    }
    for key, value in status.items():
        logger.info("  %-22s %s", key, value)

    # The drift config must point at the table the monitor actually writes.
    actual = status["drift_metrics_table"]
    if actual and cfg.drift.drift_table and actual != cfg.drift.drift_table:
        logger.warning(
            "drift_table in monitoring_config is '%s' but the monitor writes "
            "'%s'. check_drift will read the wrong table.",
            cfg.drift.drift_table, actual,
        )
    return status


def wait_for_active(cfg: MonitoringConfig, client=None,
                    timeout_minutes: int = 20) -> str:
    """
    Block until the monitor leaves PENDING.

    A newly created monitor is PENDING while Databricks provisions its metric
    tables and dashboard, and rejects refresh calls until it is ACTIVE.
    """
    client = client or _client()
    table = cfg.batch.inference_table
    deadline = time.time() + timeout_minutes * 60

    while True:
        monitor = client.quality_monitors.get(table_name=table)
        status = str(getattr(monitor, "status", ""))
        if "PENDING" not in status:
            logger.info("Monitor status: %s", status)
            return status
        if time.time() > deadline:
            raise TimeoutError(
                f"Monitor still PENDING after {timeout_minutes} minutes. "
                f"Check the Quality tab on {table} in the UI."
            )
        logger.info("  status: %s — waiting", status)
        time.sleep(cfg.monitor.refresh_poll_seconds)


def delete_monitor(cfg: MonitoringConfig, client=None) -> Dict[str, Any]:
    """
    Remove the monitor. Its metric tables and dashboard are left behind.

    Needed because a monitor pins the schema of the table it was created
    against, while the score stage writes with overwriteSchema=true. Once the
    column types change underneath it, every refresh fails — and the only
    repair is to drop and recreate.
    """
    client = client or _client()
    table = cfg.batch.inference_table
    if not monitor_exists(table, client):
        logger.info("No monitor on %s to delete.", table)
        return {"action": "absent"}

    client.quality_monitors.delete(table_name=table)
    logger.info("Deleted the monitor on %s. Its metric tables remain and will "
                "be reused on recreate.", table)
    return {"action": "deleted"}


def recreate_monitor(cfg: MonitoringConfig, wait: bool = True) -> Dict[str, Any]:
    """Delete and create again, against the table's CURRENT schema."""
    client = _client()
    delete_monitor(cfg, client)

    # The delete is asynchronous; creating immediately can hit the old record.
    time.sleep(5)

    result = create_monitor(cfg, client)

    if not wait:
        logger.info("Created. It stays PENDING for a few minutes, then runs "
                    "its own first refresh.")
        return result

    # A new monitor computes its first metrics by itself once ACTIVE, so there
    # is nothing to trigger — only to wait for.
    logger.info("Waiting for the monitor to become ACTIVE.")
    status = wait_for_active(cfg, client)
    result["status"] = status
    logger.info("Monitor is %s. Its first refresh runs automatically; check "
                "with --status.", status)
    return result


def ensure_monitor(cfg: MonitoringConfig, refresh: bool = True,
                   wait: bool = True, recreate: bool = False) -> Dict[str, Any]:
    cfg.validate()
    if not cfg.monitor.enabled:
        logger.info("Monitor disabled in config.")
        return {"action": "disabled"}

    if recreate:
        return recreate_monitor(cfg, wait=wait)

    client = _client()
    if not monitor_exists(cfg.batch.inference_table, client):
        result = create_monitor(cfg, client)
        # A freshly created monitor computes its first metrics automatically.
        return result

    logger.info("Monitor already exists on %s.", cfg.batch.inference_table)
    if refresh:
        return refresh_monitor(cfg, wait=wait, client=client)
    return {"action": "unchanged"}


# ──────────────────────────────────────────────────────────────────────────
# Dashboard sync
# ──────────────────────────────────────────────────────────────────────────
# The dashboard the monitor generates has defects that make slices, model
# versions and fairness unusable. sync_dashboards() repairs them in place,
# driven only by config + monitor metadata. Idempotent — run after every
# monitor (re)create, since each create generates a new dashboard.
#   1. drift/profile datasets hardcode `isnull(slice_key) AND isnull(slice_value)`
#      -> parameterised by Slice Key / Slice Value filters
#   2. `(:Model Id = '*' OR model_version = :Model Id)` mixes the '*'
#      aggregate with per-version rows -> exact match
#   3. quantile dataset UNIONs a TIMESTAMP Window with 'Baseline'
#      -> CAST_INVALID_INPUT under ANSI -> Window cast to STRING
#   4. baseline is profiled for the champion only -> COALESCE fallback
#   5. fairness datasets filter on slice_value -> filter on populated metrics,
#      protected-group filter has no default -> first binary slicing expr
#   6. Model Id params have no default -> all-versions token
#   7. Top K filter has no options and a type-mismatched default
_FAIRNESS_COLS = ("statistical_parity", "equal_opportunity",
                  "predictive_equality", "predictive_parity")


def _q_ident(table: str) -> str:
    return ".".join(f"`{p}`" for p in table.split("."))


def _wid(*parts: str) -> str:
    import hashlib
    return hashlib.md5("|".join(parts).encode()).hexdigest()[:8]


def _sel(value: str, data_type: str = "STRING") -> Dict[str, Any]:
    return {"defaultSelection": {"values": {"dataType": data_type,
                                            "values": [{"value": value}]}}}


def _query_text(ds: Dict[str, Any]) -> str:
    return "".join(ds.get("queryLines", [ds.get("query", "")]))


def _set_query(ds: Dict[str, Any], q: str) -> None:
    ds.pop("query", None)
    ds["queryLines"] = q.splitlines(keepends=True)


def protected_groups(cfg: MonitoringConfig) -> List[str]:
    """Binary slicing expressions — the only slices fairness is computed for."""
    import re
    binary = re.compile(r"(=|<>|!=|<|>|\bIN\b|\bLIKE\b|\bIS\b)", re.IGNORECASE)
    return [e for e in cfg.monitor.slicing_exprs if binary.search(e)]


def monitor_dashboard_ids(cfg: MonitoringConfig, client=None) -> List[str]:
    """The monitor's current dashboard (+ every one it generated before)."""
    client = client or _client()
    info = client.quality_monitors.get(table_name=cfg.batch.inference_table)
    ids = {info.dashboard_id} if info.dashboard_id else set()
    if cfg.dashboard.sync_all_dashboards and info.assets_dir:
        folder = f"{info.assets_dir.rstrip('/')}/{cfg.batch.inference_table}"
        try:
            ids |= {o.resource_id for o in client.workspace.list(folder)
                    if o.path.endswith(".lvdash.json") and o.resource_id}
        except Exception as exc:
            logger.warning("Could not list %s: %s", folder, exc)
    return sorted(ids)


def _patch_dashboard(sd: Dict[str, Any], did: str, cfg: MonitoringConfig,
                     profile_tbl: str) -> Dict[str, Any]:
    import re
    d = cfg.dashboard
    P_KEY, P_VAL, P_MODEL, NO = (d.slice_key_param, d.slice_value_param,
                                 d.model_param, d.no_slice_label)
    prof = _q_ident(profile_tbl)
    model_any = re.compile(r"\(\s*:`" + re.escape(P_MODEL) + r"`\s*=\s*'" + re.escape(d.model_all_token)
                           + r"'\s+OR\s+`?model_version`?\s*=\s*:`" + re.escape(P_MODEL) + r"`\s*\)")
    model_exact = f"`model_version` = :`{P_MODEL}`"
    baseline_model = (f"`model_version` = COALESCE("
                      f"(SELECT max(model_version) FROM {prof} WHERE log_type = 'BASELINE' AND model_version = :`{P_MODEL}`), "
                      f"(SELECT max(model_version) FROM {prof} WHERE log_type = 'BASELINE'))")
    slice_hard = re.compile(r"isnull\(slice_key\)\s+AND\s+isnull\(slice_value\)", re.IGNORECASE)
    slice_param = (f"COALESCE(slice_key, '{NO}') = :`{P_KEY}` "
                   f"AND COALESCE(slice_value, '{NO}') = :`{P_VAL}`")
    fair_slice_where = re.compile(
        r'WHERE\s+slice_value\s+(IS\s+NOT\s+NULL|in\s*\(\s*"true"\s*,\s*"false"\s*\))', re.IGNORECASE)
    fair_where = "WHERE " + " AND ".join(f"{c} IS NOT NULL" for c in _FAIRNESS_COLS)

    def patch_query(q: str) -> str:
        if baseline_model not in q:      # baseline CTE first (idempotent)
            q = re.sub(r"(log_type\s*=\s*\"BASELINE\"[\s\S]{0,300}?)(?:" + model_any.pattern
                       + r"|`?model_version`?\s*=\s*:`" + re.escape(P_MODEL) + r"`)",
                       lambda m: m.group(1) + baseline_model, q)
        q = model_any.sub(model_exact, q)
        q = slice_hard.sub(slice_param, q)
        q = re.sub(r"SELECT\s+window\.start\s+AS\s+Window,(\s*column_name,\s*quantiles)",
                   r"SELECT CAST(window.start AS STRING) AS Window,\1", q)
        return q

    page = sd["pages"][0]
    sliced, fair = [], []

    # 1-5. dataset SQL
    for ds in sd["datasets"]:
        q0 = _query_text(ds)
        q = patch_query(q0)
        if all(c in q for c in _FAIRNESS_COLS) and "unpivot" in q.lower():
            q = fair_slice_where.sub(fair_where, q)
            fair.append(ds["name"])
        if f":`{P_KEY}`" in q:
            sliced.append(ds["name"])
            kws = {p["keyword"] for p in ds.get("parameters", [])}
            for p in (P_KEY, P_VAL):
                if p not in kws:
                    ds.setdefault("parameters", []).append(
                        {"displayName": p, "keyword": p, "dataType": "STRING", **_sel(NO)})
        if ds["displayName"] == "distinct_model":
            # only versions still present in the inference table (+ '*')
            restrict = (f"\n  AND (model_version = '{d.model_all_token}' "
                        f"OR model_version IN (SELECT DISTINCT CAST({cfg.batch.model_version_col} AS STRING) "
                        f"FROM {_q_ident(cfg.batch.inference_table)}))")
            q = q.replace(restrict, "")          # idempotent: drop earlier copies
            q = q.replace("AND model_version IS NOT NULL",
                          "AND model_version IS NOT NULL" + restrict, 1)
        if q != q0:
            _set_query(ds, q)

    # Options for the slice filters: every slice the monitor produced
    opt = _wid(did, "distinct_slices")
    if not any(x["name"] == opt for x in sd["datasets"]):
        sd["datasets"].append({"name": opt, "displayName": "distinct_slices", "queryLines": [
            f"SELECT DISTINCT COALESCE(slice_key, '{NO}') AS `{P_KEY}`,\n",
            f"       COALESCE(slice_value, '{NO}') AS `{P_VAL}`\n",
            f"FROM {prof}\n", "ORDER BY 1, 2"]})

    # Slice Key / Slice Value filter widgets bound to every sliced dataset
    existing = {it["widget"]["name"]: it for it in page["layout"]}
    new_filters = []
    for i, p in enumerate((P_KEY, P_VAL)):
        name = _wid(did, "filter", p)
        fq = f"slicefilter_{opt}_{p}"
        queries = [{"name": fq, "query": {"datasetName": opt, "fields": [
            {"name": p, "expression": f"`{p}`"},
            {"name": f"{p}_associativity", "expression": "COUNT_IF(`associative_filter_predicate_group`)"}],
            "disaggregated": False}}]
        fields = [{"displayName": p, "fieldName": p, "queryName": fq}]
        for dsn in sliced:
            pq = f"sliceparam_{dsn}_{p}"
            queries.append({"name": pq, "query": {"datasetName": dsn,
                            "parameters": [{"name": p, "keyword": p}], "disaggregated": False}})
            fields.append({"parameterName": p, "queryName": pq})
        widget = {"name": name, "queries": queries, "spec": {
            "version": 2, "widgetType": "filter-single-select", "disallowAll": True,
            "encodings": {"fields": fields}, "selection": _sel(NO),
            "frame": {"showTitle": True, "title": f"{p} (drift & profile)"}}}
        if name in existing:
            existing[name]["widget"] = widget
        else:
            new_filters.append({"widget": widget,
                                "position": {"x": 3 * i, "y": 3, "width": 3, "height": 2}})
    if new_filters:
        for it in page["layout"]:
            if it["position"]["y"] >= 3:
                it["position"]["y"] += 2
        page["layout"].extend(new_filters)

    # 6. Model Id defaults on every dataset parameter
    for ds in sd["datasets"]:
        for p in ds.get("parameters", []):
            if p["keyword"] == P_MODEL and not (p.get("defaultSelection") or {}).get("values"):
                p.update(_sel(d.model_all_token))

    # 7. Top K options typed like the parameter
    tk = next((p for x in sd["datasets"] for p in x.get("parameters", [])
               if p["keyword"] == d.top_k_param), None)
    tk_type = (tk or {}).get("dataType", "DECIMAL")
    tk_def = (((tk or {}).get("defaultSelection") or {}).get("values", {}).get("values")
              or [{"value": "5"}])[0]["value"]
    sql_type = {"DECIMAL": "DECIMAL(10,0)", "INTEGER": "INT"}.get(tk_type, "STRING")
    tk_name = _wid(did, "top_k_options")
    sd["datasets"] = [x for x in sd["datasets"] if x["name"] != tk_name] + [{
        "name": tk_name, "displayName": "top_k_options", "queryLines": [
            f"SELECT CAST(k AS {sql_type}) AS {d.top_k_param} FROM (\n",
            "  SELECT explode(sequence(1, GREATEST(1, max(size(frequent_items))))) AS k\n",
            f"  FROM {prof} WHERE frequent_items IS NOT NULL)\n", "ORDER BY k"]}]

    groups = protected_groups(cfg)
    default_group = d.default_protected_group or (groups[0] if groups else None)
    fair_filters = []
    for it in page["layout"]:
        wd, sp = it["widget"], it["widget"].get("spec", {})
        if not sp.get("widgetType", "").startswith("filter"):
            continue
        params = {pp["keyword"] for q in wd.get("queries", []) for pp in q["query"].get("parameters", [])}
        if P_MODEL in params and not sp.get("selection"):
            sp["selection"] = _sel(d.model_all_token)
        if params == {d.top_k_param}:
            if not any(q["query"].get("datasetName") == tk_name for q in wd["queries"]):
                fq = f"topkfilter_{tk_name}"
                wd["queries"].insert(0, {"name": fq, "query": {"datasetName": tk_name, "fields": [
                    {"name": d.top_k_param, "expression": f"`{d.top_k_param}`"},
                    {"name": f"{d.top_k_param}_associativity",
                     "expression": "COUNT_IF(`associative_filter_predicate_group`)"}],
                    "disaggregated": False}})
                sp.setdefault("encodings", {}).setdefault("fields", []).insert(
                    0, {"displayName": d.top_k_param, "fieldName": d.top_k_param, "queryName": fq})
            sp["selection"] = _sel(tk_def, tk_type)
            sp["disallowAll"] = True
        # 5b. protected-group filter default
        uses_fair = any(q["query"].get("datasetName") in fair for q in wd.get("queries", []))
        fields = sp.get("encodings", {}).get("fields", [])
        if default_group and uses_fair and any(f.get("fieldName") == "Slice key" for f in fields):
            sp["selection"] = _sel(default_group)
            fair_filters.append(sp.get("frame", {}).get("title", wd["name"]))

    return {"sliced_datasets": len(sliced), "fairness_datasets": len(fair),
            "new_filters": len(new_filters), "fairness_filters": fair_filters,
            "protected_group_default": default_group}


def verify_dashboard(spark, cfg: MonitoringConfig, dashboard_id: str,
                     client=None) -> Dict[str, Any]:
    """Run each dataset with the dashboard defaults; report rows / errors."""
    import json
    client = client or _client()
    d = cfg.dashboard
    sd = json.loads(client.lakeview.get(dashboard_id).serialized_dashboard or "{}")
    groups = protected_groups(cfg)
    out: Dict[str, Any] = {}
    for ds in sd.get("datasets", []):
        args, types = {}, {}
        for p in ds.get("parameters", []):
            vals = ((p.get("defaultSelection") or {}).get("values") or {}).get("values") or []
            args[p["keyword"]] = vals[0]["value"] if vals else d.model_all_token
            types[p["keyword"]] = p.get("dataType", "STRING")
        q = (_query_text(ds).rstrip().rstrip(";")
             .replace(":`Time Window Start`", "current_timestamp() - INTERVAL 12 MONTHS")
             .replace(":`Time Window End`", "current_timestamp()"))
        for k, v in args.items():
            if k in ("Time Window Start", "Time Window End"):
                continue
            numeric = types.get(k) in ("DECIMAL", "INTEGER") and str(v).isdigit()
            lit = str(v) if numeric else "'" + str(v).replace("'", "\\'") + "'"
            q = q.replace(f":`{k}`", lit).replace(f":{k}", lit)
        try:
            out[ds["displayName"]] = spark.sql(q).count()
        except Exception as exc:
            out[ds["displayName"]] = f"ERROR: {str(exc).splitlines()[0][:150]}"
    if groups:
        out["_protected_groups"] = groups
    return out


def sync_dashboards(cfg: MonitoringConfig, spark=None,
                    verify: bool = True) -> Dict[str, Any]:
    """Repair every dashboard the monitor generated (see notes above)."""
    import json
    from databricks.sdk.service.dashboards import Dashboard

    client = _client()
    info = client.quality_monitors.get(table_name=cfg.batch.inference_table)
    profile_tbl = info.profile_metrics_table_name
    results: Dict[str, Any] = {}
    for did in monitor_dashboard_ids(cfg, client):
        dash = client.lakeview.get(did)
        sd = json.loads(dash.serialized_dashboard or "{}")
        if not sd.get("datasets") or not sd.get("pages"):
            logger.info("Skipped %s (%s) — empty dashboard", dash.display_name, did)
            continue
        summary = _patch_dashboard(sd, did, cfg, profile_tbl)
        client.lakeview.update(did, Dashboard(display_name=dash.display_name,
                                              serialized_dashboard=json.dumps(sd),
                                              warehouse_id=dash.warehouse_id))
        logger.info("Synced dashboard '%s' (%s): %s", dash.display_name, did, summary)
        results[did] = summary

    if verify and spark is not None and info.dashboard_id in results:
        check = verify_dashboard(spark, cfg, info.dashboard_id, client)
        errors = {k: v for k, v in check.items() if isinstance(v, str) and v.startswith("ERROR")}
        empty = sorted(k for k, v in check.items() if v == 0)
        logger.info("Verify %s: %d datasets, errors=%s, empty=%s",
                    info.dashboard_id, len(check), errors, empty)
        results["verify"] = check
    logger.info("Close open dashboard tabs and hard-reload before editing — a stale "
                "tab overwrites these fixes on its next save.")
    return results


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--monitor", default=DEFAULT_MONITORING,
                        choices=sorted(MONITORING_CONFIGS))
    parser.add_argument("--refresh", action="store_true",
                        help="Force a refresh on an existing monitor.")
    parser.add_argument("--status", action="store_true")
    parser.add_argument("--recreate", action="store_true",
                        help="Delete and recreate against the table's current "
                             "schema. Use when refreshes fail after the "
                             "inference table was rewritten.")
    parser.add_argument("--delete", action="store_true")
    parser.add_argument("--no_wait", action="store_true")
    args, _ = parser.parse_known_args()
    return args


def main() -> int:
    args = parse_args()
    cfg = get_monitoring_config(args.monitor)
    try:
        if args.status:
            monitor_status(cfg)
        elif args.delete:
            delete_monitor(cfg)
        else:
            ensure_monitor(cfg, refresh=args.refresh or True,
                           wait=not args.no_wait, recreate=args.recreate)
    except Exception as exc:
        logger.error("Monitor operation failed: %s", exc, exc_info=True)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())