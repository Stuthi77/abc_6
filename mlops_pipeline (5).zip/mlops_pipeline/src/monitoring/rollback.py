"""
rollback.py
-----------
Promotes the Challenger to Champion. Requires explicit approval.

    python -m src.monitoring.rollback --monitor weekly_orders            # plan
    python -m src.monitoring.rollback --monitor weekly_orders --approve  # execute

The demoted Champion is kept as the new Challenger rather than discarded, so a
rollback can itself be undone. The original deleted the challenger alias and
left the old Champion unreferenced, which made the swap one-way.
"""
from __future__ import annotations

import argparse
import logging
import sys
from typing import Any, Dict, Optional

from mlflow.tracking import MlflowClient

from src.settings.monitoring_settings import (
    DEFAULT_MONITORING,
    MONITORING_CONFIGS,
    MonitoringConfig,
    get_monitoring_config,
)
from src.monitoring.common import check_model_state, send_alert, write_control_event

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


def run_rollback(spark, cfg: MonitoringConfig,
                 approved: bool = False) -> Dict[str, Any]:
    cfg.validate()
    client = MlflowClient()
    model_name = cfg.full_model_name
    state = check_model_state(client, cfg)

    logger.info("ROLLBACK | %s", model_name)
    logger.info("  champion   : v%s", state["champion_version"])
    logger.info("  challenger : v%s", state["challenger_version"])

    if not state["has_champion"]:
        logger.error("No Champion — nothing to roll back.")
        return {"status": "no_champion"}
    if not state["can_rollback"]:
        logger.error("No Challenger — nothing to roll back to.")
        return {"status": "no_challenger"}

    old_champion = state["champion_version"]
    new_champion = state["challenger_version"]

    if not approved:
        logger.warning(
            "\n%s\nNOT EXECUTED — this would make v%s the Champion and demote "
            "v%s, changing what every consumer of the '%s' alias receives.\n"
            "Re-run with --approve.\n%s",
            "=" * 70, new_champion, old_champion, cfg.champion_alias, "=" * 70,
        )
        return {"status": "pending_approval",
                "would_promote": new_champion, "would_demote": old_champion}

    try:
        # Promote first: the alias points at a valid version throughout, so a
        # failure part-way never leaves consumers without a Champion.
        client.set_registered_model_alias(
            name=model_name, alias=cfg.champion_alias, version=new_champion)
        logger.info("Champion -> v%s", new_champion)

        # Keep the demoted version reachable as the Challenger.
        client.set_registered_model_alias(
            name=model_name, alias=cfg.challenger_alias, version=old_champion)
        logger.info("Challenger -> v%s (the demoted Champion)", old_champion)
    except Exception as exc:
        logger.error("Alias update failed: %s", exc, exc_info=True)
        return {"status": "failed", "error": str(exc)}

    # Record it so the settling window suppresses alerts on metrics that the
    # previous Champion produced.
    try:
        write_control_event(spark, cfg, "rollback_complete")
    except Exception as exc:
        logger.warning(
            "Rollback succeeded but the control event failed to write: %s. "
            "The %dh settling window will not be enforced.",
            exc, cfg.rollback.settling_hours,
        )

    send_alert(
        cfg.alerts, f"Rollback executed — {cfg.name}",
        f"Model     : {model_name}\n"
        f"Champion  : v{old_champion} -> v{new_champion}\n"
        f"Challenger: v{new_champion} -> v{old_champion}\n\n"
        f"Serving pins a version, so any endpoint still serves the old one "
        f"until it is redeployed.",
    )

    logger.warning(
        "Registry updated. If this model is served, the endpoint still has the "
        "previous version pinned — redeploy to roll it out."
    )
    return {"status": "rolled_back", "new_champion": new_champion,
            "demoted": old_champion}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--monitor", default=DEFAULT_MONITORING,
                        choices=sorted(MONITORING_CONFIGS))
    parser.add_argument("--approve", action="store_true",
                        help="Required — the alias swap changes production.")
    args, _ = parser.parse_known_args()
    return args


def main() -> int:
    from pyspark.sql import SparkSession
    args = parse_args()
    spark = SparkSession.builder.getOrCreate()
    try:
        result = run_rollback(spark, get_monitoring_config(args.monitor),
                              approved=args.approve)
    except Exception as exc:
        logger.error("Rollback failed: %s", exc, exc_info=True)
        return 1
    return 0 if result.get("status") in ("rolled_back", "pending_approval") else 1


if __name__ == "__main__":
    sys.exit(main())
