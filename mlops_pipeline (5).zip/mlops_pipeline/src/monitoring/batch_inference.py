"""
batch_inference.py
------------------
Scores the Champion over periods that have no prediction yet and upserts the
results into the inference table that monitoring reads.

    python -m src.monitoring.batch_inference --monitor weekly_orders
    python -m src.monitoring.batch_inference --monitor weekly_orders --dry_run

Only unscored periods are processed, so a re-run is cheap and does not
duplicate rows.
"""
from __future__ import annotations

import argparse
import logging
import sys
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import mlflow
from mlflow.tracking import MlflowClient
from pyspark.sql import functions as F

from src.settings.monitoring_settings import (
    DEFAULT_MONITORING,
    MONITORING_CONFIGS,
    MonitoringConfig,
    get_monitoring_config,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


def resolve_endpoint(cfg: MonitoringConfig) -> Tuple[str, Optional[str]]:
    """
    (endpoint_name, served_version) for endpoint scoring.

    The served version is read from the endpoint, NOT from the champion alias.
    Serving pins a version, so the endpoint can be serving something older
    than the current Champion — and the predictions must be attributed to the
    version that actually produced them, or the monitor's per-model metrics
    are wrong.
    """
    from src.settings.mlops_settings import serving_config
    from src.serving.endpoint_manager import get_endpoint

    name = cfg.batch.endpoint_name or serving_config(cfg.name).endpoint_name
    endpoint = get_endpoint(name)
    if endpoint is None:
        raise RuntimeError(
            f"scoring_mode='endpoint' but '{name}' does not exist. Deploy it "
            f"first, or set scoring_mode='local'."
        )

    state = getattr(endpoint, "state", None)
    ready = str(getattr(state, "ready", ""))
    if "READY" not in ready.upper():
        logger.warning("Endpoint '%s' is %s — requests may fail or cold-start.",
                       name, ready)

    served_version = None
    config = getattr(endpoint, "config", None) or getattr(endpoint, "pending_config", None)
    for entity in (getattr(config, "served_entities", None) or []):
        served_version = getattr(entity, "entity_version", None)
        break

    logger.info("Scoring via endpoint '%s' (serving version %s).",
                name, served_version)
    return name, served_version


def warn_if_endpoint_lags(cfg: MonitoringConfig, served_version: Optional[str]) -> None:
    """Flag the case where the endpoint is behind the registry."""
    if served_version is None:
        return
    try:
        mlflow.set_registry_uri("databricks-uc")
        champion = MlflowClient().get_model_version_by_alias(
            cfg.full_model_name, cfg.champion_alias)
    except Exception:
        return
    if str(champion.version) != str(served_version):
        logger.warning(
            "Endpoint serves v%s but the Champion alias is v%s. These "
            "predictions describe the DEPLOYED model — redeploy if you meant "
            "to monitor the Champion.", served_version, champion.version,
        )


def to_jsonable(frame: pd.DataFrame) -> List[Dict[str, Any]]:
    """
    Convert a frame to records the HTTP client can serialize.

    Local scoring hands the DataFrame straight to the model, so these types
    never mattered. Over the wire every value must be a JSON primitive:

      Decimal      Spark DECIMAL columns arrive as decimal.Decimal
      np.int64 /
      np.float32   numpy scalars are not JSON types
      Timestamp    dates need an ISO string
      NaN / NaT    must be null, never the string "nan"
    """
    import datetime as _dt
    from decimal import Decimal

    def convert(value: Any) -> Any:
        if value is None:
            return None
        # NaN/NaT: checked before anything else, since they are float/datetime.
        try:
            if pd.isna(value):
                return None
        except (TypeError, ValueError):
            pass            # arrays and the like are not NA-checkable
        if isinstance(value, Decimal):
            return float(value)
        if isinstance(value, (np.integer,)):
            return int(value)
        if isinstance(value, (np.floating,)):
            return float(value)
        if isinstance(value, (np.bool_,)):
            return bool(value)
        if isinstance(value, (pd.Timestamp, _dt.datetime, _dt.date)):
            return value.isoformat()
        if isinstance(value, np.ndarray):
            return value.tolist()
        return value

    return [{k: convert(v) for k, v in row.items()}
            for row in frame.to_dict(orient="records")]


def score_batch_via_endpoint(endpoint_name: str, frame: pd.DataFrame,
                             batch_size: int) -> np.ndarray:
    """Send a frame to the endpoint in batches and return the predictions."""
    from src.serving.endpoint_manager import query_endpoint

    records = to_jsonable(frame)

    out: List[Any] = []
    for start in range(0, len(records), batch_size):
        chunk = records[start:start + batch_size]
        response = query_endpoint(endpoint_name, chunk)
        preds = getattr(response, "predictions", response)
        out.extend(np.asarray(preds).ravel().tolist())

    if len(out) != len(frame):
        raise RuntimeError(
            f"Endpoint returned {len(out)} prediction(s) for {len(frame)} row(s)."
        )
    return np.asarray(out)


def load_champion(cfg: MonitoringConfig):
    """Load the Champion and report which version it is."""
    mlflow.set_registry_uri("databricks-uc")
    client = MlflowClient()
    mv = client.get_model_version_by_alias(cfg.full_model_name, cfg.champion_alias)

    try:
        model = mlflow.pyfunc.load_model(cfg.champion_uri)
    except ModuleNotFoundError as exc:
        missing = getattr(exc, "name", None) or str(exc)
        raise RuntimeError(
            f"Cannot load the Champion: '{missing}' is not installed here.\n"
            f"    path = mlflow.pyfunc.get_model_dependencies('{cfg.champion_uri}')\n"
            f"    %pip install -r $path"
        ) from exc

    logger.info("Champion: %s v%s", cfg.full_model_name, mv.version)
    return model, str(mv.version), cfg.full_model_name


def resolve_model_ref(cfg: MonitoringConfig, ref: str) -> Optional[str]:
    """An alias ('challenger') or a version number -> version, or None."""
    if str(ref).isdigit():
        return str(ref)
    mlflow.set_registry_uri("databricks-uc")
    try:
        return str(MlflowClient().get_model_version_by_alias(
            cfg.full_model_name, ref).version)
    except Exception:
        logger.warning("Alias '%s' is not set on %s — skipped.", ref,
                       cfg.full_model_name)
        return None


def load_model_version(cfg: MonitoringConfig, version: str):
    mlflow.set_registry_uri("databricks-uc")
    logger.info("Loading %s v%s", cfg.full_model_name, version)
    return mlflow.pyfunc.load_model(f"models:/{cfg.full_model_name}/{version}")


def enrich(spark, cfg: MonitoringConfig, sdf):
    """Add the configured grouping column (cfg.batch.enrichment), if any."""
    e = cfg.batch.enrichment
    if e is None:
        return sdf
    if e.column in sdf.columns:
        sdf = sdf.drop(e.column)
    value = None
    if e.source_table:
        # One value per key — a key seen in several source rows must not
        # multiply the scored rows.
        lookup = (spark.read.table(e.source_table)
                  .select(*e.join_keys, F.expr(e.source_expr).alias(e.column))
                  .groupBy(*e.join_keys).agg(F.max(e.column).alias(e.column)))
        sdf = sdf.join(lookup, on=e.join_keys, how="left")
        value = F.col(e.column)
    if e.fallback_expr:
        value = (F.expr(e.fallback_expr) if value is None
                 else F.coalesce(value, F.expr(e.fallback_expr)))
    return sdf.withColumn(e.column, value)


def finalize_output(spark, cfg: MonitoringConfig, pdf: pd.DataFrame):
    """Scored pandas frame -> Spark frame in the inference-table contract."""
    b = cfg.batch
    sdf = enrich(spark, cfg, spark.createDataFrame(pdf))
    if b.categorical_output:
        # Same type for both, or a classification monitor refresh fails.
        for col in (b.prediction_col, b.label_col):
            if col in sdf.columns:
                sdf = sdf.withColumn(col, F.col(col).cast("string"))
    return sdf


def pending_periods(spark, cfg: MonitoringConfig,
                    model_version: Optional[str] = None) -> List[Any]:
    """Periods present in the features but absent from the inference table
    (for model_version, when given — each version is scored independently)."""
    b = cfg.batch
    feature_periods = (
        spark.read.table(b.feature_table)
        .select(F.col(b.time_column))
        .distinct()
    )

    if spark.catalog.tableExists(b.inference_table):
        scored_df = spark.read.table(b.inference_table)
        if model_version is not None and b.model_version_col in scored_df.columns:
            scored_df = scored_df.filter(
                F.col(b.model_version_col).cast("string") == str(model_version))
        scored = scored_df.select(F.col(b.time_column)).distinct()
        pending_df = feature_periods.join(scored, on=b.time_column, how="left_anti")
    else:
        logger.info("Inference table does not exist yet — scoring everything.")
        pending_df = feature_periods

    periods = [r[0] for r in pending_df.orderBy(b.time_column).collect()]
    if len(periods) > b.max_periods_per_run:
        logger.warning(
            "%d period(s) pending; capping at max_periods_per_run=%d. "
            "Re-run to continue.", len(periods), b.max_periods_per_run,
        )
        periods = periods[: b.max_periods_per_run]
    return periods


def _predict_input(features_pd: pd.DataFrame, cfg: MonitoringConfig,
                   model) -> pd.DataFrame:
    """Drop non-features, then align to the model signature."""
    b = cfg.batch
    drop = set(b.exclude_from_features) | {b.label_col}
    out = features_pd.drop(columns=[c for c in drop if c in features_pd.columns])

    # Reuse the registration module's alignment so scoring behaves identically
    # in both places (dtype casts, signature order, LightGBM categoricals).
    try:
        from src.model_registration.model_registration import score_with_model
        return out
    except Exception:
        return out


def score_period(spark, cfg: MonitoringConfig, period, model,
                 model_version: str, model_name: str,
                 actuals: Optional[pd.DataFrame],
                 endpoint_name: Optional[str] = None,
                 feature_table: Optional[str] = None) -> pd.DataFrame:
    """Score one period (period=None scores the whole feature_table).
    Uses the endpoint when endpoint_name is set, otherwise the loaded model."""
    b = cfg.batch
    features = spark.read.table(feature_table or b.feature_table)
    if period is not None:
        features = features.filter(F.col(b.time_column) == F.lit(period))
    features_pd = features.toPandas()
    if features_pd.empty:
        return features_pd

    predict_input = _predict_input(features_pd, cfg, model)

    if endpoint_name:
        values = score_batch_via_endpoint(
            endpoint_name, predict_input, cfg.batch.endpoint_batch_size)
    else:
        from src.model_registration.model_registration import score_with_model
        raw = score_with_model(model, predict_input)
        values = (raw.iloc[:, 0].values if isinstance(raw, pd.DataFrame)
                  else np.asarray(raw).ravel())

    out = features_pd.copy()

    # Dtype matters here, not just the value. A classification monitor requires
    # prediction_col and label_col to be the SAME type; writing float32
    # predictions against an integer label makes the refresh fail ~30 minutes
    # later with nothing but "FAILED". Classifiers also return class labels,
    # so int is the correct representation anyway.
    if cfg.monitor.problem_type == "classification":
        out[b.prediction_col] = np.rint(values.astype(float)).astype(np.int32)
    else:
        out[b.prediction_col] = values.astype(np.float32)
    out[b.model_version_col] = str(model_version)   # monitor expects a string
    out[b.model_name_col] = model_name
    out[b.timestamp_col] = datetime.now(timezone.utc)

    # The monitor windows on cfg.monitor.timestamp_col, which may be the event
    # date rather than the scoring time. Spark infers a DATE column from
    # pandas dates, and the monitor needs a TIMESTAMP to form windows — so
    # coerce it here rather than discovering the problem after a long refresh.
    window_col = cfg.monitor.timestamp_col
    if window_col in out.columns:
        out[window_col] = pd.to_datetime(out[window_col], errors="coerce")
        n_bad = int(out[window_col].isna().sum())
        if n_bad:
            logger.warning("%d row(s) have an unparseable %s — the monitor "
                           "cannot window those.", n_bad, window_col)
    else:
        logger.warning(
            "Monitor windows on '%s' but that column is not in the scored "
            "frame. No windows will be formed and the dashboard parameters "
            "will stay empty.", window_col,
        )

    if actuals is not None:
        keys = [k for k in b.merge_keys if k in actuals.columns]
        out = out.merge(actuals[keys + [b.label_col]], on=keys, how="left")
        matched = int(out[b.label_col].notna().sum())
        logger.info("  actuals joined: %d/%d", matched, len(out))

        # Match the prediction dtype, for the same reason as above. Rows with
        # no actual stay NULL rather than becoming a bogus class.
        if cfg.monitor.problem_type == "classification":
            out[b.label_col] = out[b.label_col].astype("Int32")
        else:
            out[b.label_col] = out[b.label_col].astype(np.float32)

        if matched == 0:
            logger.warning(
                "No actuals matched on %s. The monitor cannot compute error "
                "metrics and its refresh will fail — check the key dtypes in "
                "'%s'.", keys, b.actual_target_table,
            )
    else:
        out[b.label_col] = (pd.Series([pd.NA] * len(out), dtype="Int32")
                            if cfg.monitor.problem_type == "classification"
                            else np.full(len(out), np.nan, dtype=np.float32))

    return out


def upsert(spark, cfg: MonitoringConfig, pdf: pd.DataFrame) -> None:
    """MERGE on merge_keys so re-scoring updates rather than duplicates."""
    b = cfg.batch
    sdf = finalize_output(spark, cfg, pdf)

    if not spark.catalog.tableExists(b.inference_table):
        sdf.write.format("delta").mode("overwrite") \
           .option("overwriteSchema", "true").saveAsTable(b.inference_table)
        logger.info("Created inference table '%s' with %d row(s).",
                    b.inference_table, len(pdf))
        return

    view = f"_tmp_infer_{abs(hash(b.inference_table)) % 10**8}"
    sdf.createOrReplaceTempView(view)
    on_clause = " AND ".join(f"t.`{k}` = s.`{k}`" for k in b.upsert_keys())
    spark.sql(f"""
        MERGE INTO {b.inference_table} AS t
        USING {view} AS s
        ON {on_clause}
        WHEN MATCHED THEN UPDATE SET *
        WHEN NOT MATCHED THEN INSERT *
    """)
    logger.info("Merged %d row(s) into '%s'.", len(pdf), b.inference_table)


def run_batch_inference(spark, cfg: MonitoringConfig,
                        dry_run: bool = False) -> Dict[str, Any]:
    cfg.validate()
    b = cfg.batch
    logger.info("BATCH INFERENCE | %s -> %s", b.feature_table, b.inference_table)
    logger.info("  scoring mode: %s", b.scoring_mode)

    actuals = None
    if b.actual_target_table and spark.catalog.tableExists(b.actual_target_table):
        actuals = spark.read.table(b.actual_target_table).toPandas()
        logger.info("Loaded %d actual(s).", len(actuals))
    else:
        logger.warning(
            "No actuals table — predictions will be written without labels, and "
            "the monitor cannot compute error metrics until they arrive.")

    model = None
    endpoint_name = None
    name = cfg.full_model_name

    if cfg.batch.scoring_is_remote():
        endpoint_name, version = resolve_endpoint(cfg)
        warn_if_endpoint_lags(cfg, version)
        if version is None:
            raise RuntimeError(
                f"Could not read the served version from '{endpoint_name}'. "
                f"Predictions could not be attributed to a model version."
            )
    else:
        model, version, name = load_champion(cfg)

    # Deployed/Champion version first, then the configured comparison versions
    # (always local — the endpoint serves one version).
    targets = [(version, model, endpoint_name)]
    for ref in b.compare_model_refs:
        v = resolve_model_ref(cfg, ref)
        if v and v not in [t[0] for t in targets]:
            targets.append((v, None, None))

    summary: Dict[str, Any] = {"versions": {}, "rows": 0,
                               "model_version": version, "dry_run": dry_run}
    for v, m, ep in targets:
        periods = pending_periods(spark, cfg, model_version=v)
        logger.info("v%s: %d pending period(s)%s", v, len(periods),
                    f" ({periods[0]} ... {periods[-1]})" if periods else "")
        summary["versions"][v] = {"periods": len(periods), "rows": 0}
        if not periods or dry_run:
            continue
        if m is None and ep is None:
            m = load_model_version(cfg, v)
        for period in periods:
            logger.info("Scoring v%s %s", v, period)
            scored = score_period(spark, cfg, period, m, v, name, actuals, ep)
            if scored.empty:
                continue
            upsert(spark, cfg, scored)
            summary["versions"][v]["rows"] += len(scored)
            summary["rows"] += len(scored)

    if dry_run:
        logger.info("DRY RUN — nothing scored or written.")
    logger.info("Done: %s", summary)
    return summary


def build_baseline(spark, cfg: MonitoringConfig,
                   dry_run: bool = False) -> Dict[str, Any]:
    """
    Score the TRAINING features with the Champion and write the monitor's
    baseline table (cfg.monitor.baseline_table).

    The baseline is the reference distribution — what the model looked like on
    known data — that drift is measured against. It goes through the same
    finalize_output() as live scoring (enrichment column, output types), so
    its schema matches the inference table, which the monitor requires.
    """
    from src.settings.mlops_settings import get_use_case

    cfg.validate()
    target = cfg.monitor.baseline_table
    if not target:
        logger.info("No baseline_table configured — nothing to build.")
        return {"action": "disabled"}

    s = get_use_case(cfg.name).shared
    logger.info("BASELINE | %s (+ %s) -> %s", s.feature_table, s.target_table, target)

    actuals = spark.read.table(s.target_table).toPandas()
    model, version, name = load_champion(cfg)
    scored = score_period(spark, cfg, None, model, version, name, actuals,
                          endpoint_name=None, feature_table=s.feature_table)
    sdf = finalize_output(spark, cfg, scored)

    matched = int(scored[cfg.batch.label_col].notna().sum())
    result = {"table": target, "rows": len(scored), "actuals_matched": matched,
              "model_version": version, "columns": len(sdf.columns),
              "dry_run": dry_run}
    if cfg.batch.enrichment:
        col = cfg.batch.enrichment.column
        result[col] = {r[0]: r[1] for r in sdf.groupBy(col).count().collect()}

    # Schema contract with the inference table (the monitor rejects a mismatch)
    if spark.catalog.tableExists(cfg.batch.inference_table):
        inf = dict(spark.read.table(cfg.batch.inference_table).dtypes)
        diff = {c: (t, inf.get(c)) for c, t in sdf.dtypes if c in inf and inf[c] != t}
        missing = sorted(set(inf) - set(sdf.columns))
        if diff or missing:
            logger.warning("Baseline vs inference schema: type diffs=%s missing=%s",
                           diff, missing)
        result["schema_matches_inference"] = not diff and not missing

    if dry_run:
        logger.info("DRY RUN — baseline not written: %s", result)
        return result

    (sdf.write.format("delta").mode("overwrite")
        .option("overwriteSchema", "true").saveAsTable(target))
    logger.info("Baseline written: %s", result)
    return result


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--monitor", default=DEFAULT_MONITORING,
                        choices=sorted(MONITORING_CONFIGS))
    parser.add_argument("--dry_run", action="store_true")
    args, _ = parser.parse_known_args()
    return args


def main() -> int:
    from pyspark.sql import SparkSession
    args = parse_args()
    spark = SparkSession.builder.getOrCreate()
    try:
        run_batch_inference(spark, get_monitoring_config(args.monitor),
                            dry_run=args.dry_run)
    except Exception as exc:
        logger.error("Batch inference failed: %s", exc, exc_info=True)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())