"""
common.py
---------
Shared monitoring helpers: model state, the control table that enforces
settling windows, and alert dispatch.

Replaces the src/utils/shared.py and src/utils/mailers.py that the original
monitoring scripts imported but which were never in the repo.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

from mlflow.tracking import MlflowClient

from src.settings.monitoring_settings import AlertConfig, MonitoringConfig

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────
# Model state
# ──────────────────────────────────────────────────────────────────────────
def check_model_state(client: MlflowClient, cfg: MonitoringConfig) -> Dict[str, Any]:
    """
    Which aliases exist and whether a rollback is even possible.

    Rollback means promoting the Challenger, so without one there is nothing to
    roll back to — worth knowing before degradation is detected, not after.
    """
    model_name = cfg.full_model_name
    state: Dict[str, Any] = {
        "model_name": model_name,
        "has_champion": False,
        "has_challenger": False,
        "champion_version": None,
        "challenger_version": None,
        "champion_run_id": None,
        "challenger_run_id": None,
    }

    for alias, prefix in ((cfg.champion_alias, "champion"),
                          (cfg.challenger_alias, "challenger")):
        try:
            mv = client.get_model_version_by_alias(model_name, alias)
            state[f"has_{prefix}"] = True
            state[f"{prefix}_version"] = mv.version
            state[f"{prefix}_run_id"] = mv.run_id
        except Exception as exc:
            logger.debug("No '%s' alias on %s: %s", alias, model_name, exc)

    state["can_rollback"] = state["has_champion"] and state["has_challenger"]
    return state


# ──────────────────────────────────────────────────────────────────────────
# Control table — settling windows
# ──────────────────────────────────────────────────────────────────────────
CONTROL_SCHEMA = "model_key STRING, event_type STRING, event_timestamp TIMESTAMP"


def ensure_control_table(spark, cfg: MonitoringConfig) -> None:
    spark.sql(
        f"CREATE TABLE IF NOT EXISTS {cfg.control_table} ({CONTROL_SCHEMA}) USING DELTA"
    )


def write_control_event(spark, cfg: MonitoringConfig, event_type: str) -> None:
    """Record an event so later runs can honour the settling window."""
    ensure_control_table(spark, cfg)
    now = datetime.now(timezone.utc)
    (
        spark.createDataFrame([(cfg.name, event_type, now)],
                              ["model_key", "event_type", "event_timestamp"])
        .write.format("delta").mode("append").saveAsTable(cfg.control_table)
    )
    logger.info("Control event '%s' recorded for '%s' at %s.",
                event_type, cfg.name, now.isoformat())


def is_in_settling_window(spark, cfg: MonitoringConfig) -> bool:
    """
    True when a rollback happened recently enough that metrics are still
    contaminated by the previous Champion.
    """
    hours = cfg.rollback.settling_hours
    if hours <= 0:
        return False

    if not spark.catalog.tableExists(cfg.control_table):
        logger.info("No control table yet — not in a settling window.")
        return False

    from pyspark.sql import functions as F

    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    recent = (
        spark.table(cfg.control_table)
        .filter((F.col("model_key") == cfg.name)
                & (F.col("event_timestamp") >= F.lit(cutoff)))
        .count()
    )
    if recent:
        logger.info(
            "'%s' is inside its %dh settling window (%d recent event(s)) — "
            "skipping.", cfg.name, hours, recent,
        )
        return True
    return False


# ──────────────────────────────────────────────────────────────────────────
# Alerts
# ──────────────────────────────────────────────────────────────────────────
def send_alert(cfg: AlertConfig, subject: str, body: str) -> bool:
    """
    Dispatch an alert. Always logs; sends only when configured.

    Returns True when it actually went somewhere external.
    """
    full_subject = f"{cfg.subject_prefix} {subject}".strip()
    logger.warning("ALERT | %s\n%s", full_subject, body)

    if not cfg.enabled:
        logger.info("Alerts disabled — logged only.")
        return False

    if cfg.approval_pipeline_url:
        body = f"{body}\n\nApprove / trigger: {cfg.approval_pipeline_url}"

    if cfg.webhook_url:
        try:
            import json
            import urllib.request

            payload = json.dumps({"text": f"*{full_subject}*\n{body}"}).encode()
            request = urllib.request.Request(
                cfg.webhook_url, data=payload,
                headers={"Content-Type": "application/json"},
            )
            urllib.request.urlopen(request, timeout=10)
            logger.info("Alert posted to webhook.")
            return True
        except Exception as exc:
            logger.error("Webhook alert failed: %s", exc)

    if cfg.recipients:
        # No SMTP server is assumed. Wire this to your mail relay, or set
        # webhook_url instead.
        logger.warning(
            "Email alerting is configured for %s but no transport is wired up. "
            "Set webhook_url, or implement the send here against your relay.",
            cfg.recipients,
        )
    return False
