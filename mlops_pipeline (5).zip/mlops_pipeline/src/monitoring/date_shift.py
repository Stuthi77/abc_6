"""
date_shift.py
-------------
Replay support: move the inference table's time column forward by
cfg.batch.date_shift_days so historical rows fall inside the monitor's
30-day lookback. Same logic as the notebook's "Shift inference dates" cell.

The shift already applied is measured against the scoring feature table
(max inference date - max feature date), so running it again is a no-op.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from pyspark.sql import functions as F

from src.settings.monitoring_settings import MonitoringConfig

logger = logging.getLogger(__name__)


def _table_exists(spark, name: str) -> bool:
    return spark.catalog.tableExists(name)


def applied_shift_days(spark, cfg: MonitoringConfig) -> Optional[int]:
    """Days the inference table is already shifted by; None if it has no rows."""
    b = cfg.batch
    if not _table_exists(spark, b.inference_table):
        return None
    src_max = spark.read.table(b.feature_table).agg(F.max(b.time_column)).first()[0]
    inf_max = spark.read.table(b.inference_table).agg(F.max(b.time_column)).first()[0]
    if src_max is None or inf_max is None:
        return None
    return (inf_max - src_max).days


def replay_applied(spark, cfg: MonitoringConfig) -> bool:
    """True when date_shift_days > 0 and the inference table is fully shifted."""
    days = cfg.batch.date_shift_days
    return days > 0 and applied_shift_days(spark, cfg) == days


def shift_inference_dates(spark, cfg: MonitoringConfig) -> Dict[str, Any]:
    b = cfg.batch
    result: Dict[str, Any] = {"table": b.inference_table, "column": b.time_column,
                              "target_days": b.date_shift_days, "shifted_days": 0}
    if b.date_shift_days == 0:
        logger.info("date_shift_days=0 for '%s' — nothing to shift.", cfg.name)
        return result

    already = applied_shift_days(spark, cfg)
    if already is None:
        logger.warning("No rows in '%s' yet — run score first.", b.inference_table)
        return result

    delta = b.date_shift_days - already
    if delta == 0:
        logger.info("Already shifted by %d day(s) — nothing to do.", already)
    else:
        (spark.read.table(b.inference_table)
            .withColumn(b.time_column,
                        F.col(b.time_column) + F.expr(f"INTERVAL {delta} DAYS"))
            .write.format("delta").mode("overwrite")
            .saveAsTable(b.inference_table))
        logger.info("Shifted %s by %d day(s) (total %d).",
                    b.time_column, delta, b.date_shift_days)
        result["shifted_days"] = delta

    row = spark.sql(f"SELECT min({b.time_column}) AS lo, max({b.time_column}) AS hi, "
                    f"count(*) AS n FROM {b.inference_table}").first()
    result.update({"min": str(row.lo), "max": str(row.hi), "rows": row.n})
    logger.info("Inference window: %s .. %s (%d rows)", row.lo, row.hi, row.n)
    return result
