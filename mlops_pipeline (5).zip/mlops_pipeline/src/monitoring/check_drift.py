"""
check_drift.py
--------------
Reads the monitor's drift metrics table, decides whether the latest window has
drifted, and alerts.

    python -m src.monitoring.check_drift --monitor weekly_orders

Detection only. It never changes an alias — drift means "look at this", not
"roll back", and the two decisions deserve separate evidence.
"""
from __future__ import annotations

import argparse
import logging
import sys
import time
from typing import Any, Dict, List, Optional

from mlflow.tracking import MlflowClient
from pyspark.sql import functions as F

from src.settings.monitoring_settings import (
    DEFAULT_MONITORING,
    MONITORING_CONFIGS,
    MonitoringConfig,
    get_monitoring_config,
)
from src.monitoring.common import check_model_state, is_in_settling_window, send_alert

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


def detect_drift(spark, cfg: MonitoringConfig) -> Optional[Dict[str, Any]]:
    """
    Drifted columns in the most recent window, or None.

    A column counts as drifted when either the KS test (numeric) or the
    chi-squared test (categorical) falls below its p-value threshold.
    """
    d = cfg.drift

    if not spark.catalog.tableExists(d.drift_table):
        logger.warning(
            "Drift table '%s' does not exist. Has the monitor run? "
            "python -m src.monitoring.lakehouse_monitor --monitor %s",
            d.drift_table, cfg.name,
        )
        return None

    if d.wait_seconds_before_read:
        logger.info("Waiting %ds for monitor metrics to settle.",
                    d.wait_seconds_before_read)
        time.sleep(d.wait_seconds_before_read)

    df = (
        spark.table(d.drift_table)
        .select("window", "column_name", "data_type", "ks_test", "chi_squared_test")
        .filter(~F.col("column_name").isin(d.exclude_columns))
        .withColumn("window_end", F.col("window.end"))
        .withColumn("ks_pvalue", F.col("ks_test.pvalue"))
        .withColumn("chi_pvalue", F.col("chi_squared_test.pvalue"))
    )

    if df.count() == 0:
        logger.info("No drift rows to evaluate (after excluding %d column(s)).",
                    len(d.exclude_columns))
        return None

    # The drift table accumulates one row per column per window. Only the
    # most recent window is of interest — older ones were already evaluated on
    # previous runs, and including them would re-alert on resolved drift.
    latest = df.select("window_end").orderBy(F.col("window_end").desc()) \
               .limit(1).collect()[0][0]
    window_df = df.filter(F.col("window_end") == latest).dropDuplicates()

    drifted = (
        window_df.filter(
            (F.col("ks_pvalue") < d.ks_pvalue_threshold)
            | (F.col("chi_pvalue") < d.chi_pvalue_threshold)
        )
        .select("column_name").distinct()
    )
    columns = sorted(r["column_name"] for r in drifted.collect())
    evaluated = window_df.select("column_name").distinct().count()

    logger.info("Window ending %s: %d of %d column(s) drifted (threshold: %d).",
                latest, len(columns), evaluated, d.min_drifted_columns)
    if columns:
        logger.info("  drifted: %s", columns)

    if len(columns) < d.min_drifted_columns:
        return None

    return {
        "drift_detected": True,
        "drifted_columns": columns,
        "drift_count": len(columns),
        "columns_evaluated": evaluated,
        "window_end": str(latest),
    }


def run_drift_check(spark, cfg: MonitoringConfig) -> Optional[Dict[str, Any]]:
    cfg.validate()
    logger.info("DRIFT CHECK | %s", cfg.drift.drift_table)

    drift = detect_drift(spark, cfg)
    if drift is None:
        logger.info("No drift above threshold.")
        return None

    if is_in_settling_window(spark, cfg):
        logger.info("Inside the settling window — alert suppressed.")
        return {**drift, "suppressed": "settling_window"}

    client = MlflowClient()
    state = check_model_state(client, cfg)

    if not state["has_champion"]:
        send_alert(cfg.alerts, f"No Champion for {cfg.name}",
                   f"Drift detected but {cfg.full_model_name} has no "
                   f"'{cfg.champion_alias}' alias.")
        return {**drift, "suppressed": "no_champion"}

    body = (
        f"Model      : {cfg.full_model_name}\n"
        f"Champion   : v{state['champion_version']}\n"
        f"Challenger : {'v' + str(state['challenger_version'])
                        if state['has_challenger'] else 'none'}\n"
        f"Window end : {drift['window_end']}\n"
        f"Drifted    : {drift['drift_count']} of {drift['columns_evaluated']} "
        f"columns\n"
        f"             {', '.join(drift['drifted_columns'][:15])}\n\n"
        f"Drift means the inputs have moved, not that the model has degraded. "
        f"Check check_rollback for live error metrics before acting."
    )
    send_alert(cfg.alerts, f"Drift detected — {cfg.name}", body)

    if not state["has_challenger"]:
        logger.warning(
            "No Challenger registered — if this turns into degradation there "
            "is nothing to roll back to."
        )
    return {**drift, "model_state": state}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--monitor", default=DEFAULT_MONITORING,
                        choices=sorted(MONITORING_CONFIGS))
    args, _ = parser.parse_known_args()
    return args


def main() -> int:
    from pyspark.sql import SparkSession
    args = parse_args()
    spark = SparkSession.builder.getOrCreate()
    try:
        run_drift_check(spark, get_monitoring_config(args.monitor))
    except Exception as exc:
        logger.error("Drift check failed: %s", exc, exc_info=True)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
