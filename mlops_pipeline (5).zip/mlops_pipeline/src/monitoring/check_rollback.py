"""
check_rollback.py
-----------------
Compares the live Champion's error metric against the value it achieved at
training time, and flags degradation when the gap persists.

    python -m src.monitoring.check_rollback --monitor weekly_orders

Detection only — it alerts, it does not swap aliases. rollback.py does that,
and only with explicit approval.
"""
from __future__ import annotations

import argparse
import logging
import sys
from typing import Any, Dict, Optional, Tuple

from mlflow.tracking import MlflowClient
from pyspark.sql import functions as F

from src.settings.monitoring_settings import (
    DEFAULT_MONITORING,
    MONITORING_CONFIGS,
    MonitoringConfig,
    get_monitoring_config,
)
from src.monitoring.common import check_model_state, is_in_settling_window, send_alert

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


def _profile_table(cfg: MonitoringConfig) -> str:
    """The monitor's profile metrics table, derived from the inference table."""
    table = cfg.batch.inference_table.rsplit(".", 1)[-1]
    return f"{cfg.monitor.output_schema}.{table}_profile_metrics"


def champion_training_metric(client: MlflowClient, cfg: MonitoringConfig,
                             state: Dict[str, Any]) -> Optional[float]:
    """The metric the Champion's own training run recorded."""
    run_id = state.get("champion_run_id")
    if not run_id:
        return None
    try:
        run = client.get_run(run_id)
    except Exception as exc:
        logger.warning("Cannot read Champion run %s: %s", run_id, exc)
        return None

    key = cfg.rollback.training_metric
    value = run.data.metrics.get(key)
    if value is None:
        logger.warning(
            "Champion run has no metric '%s'. Available: %s. Set "
            "rollback.training_metric to one of these.",
            key, sorted(run.data.metrics),
        )
    return value


def evaluate_degradation(spark, client: MlflowClient, cfg: MonitoringConfig,
                         state: Dict[str, Any]) -> Dict[str, Any]:
    """
    How many consecutive recent windows breach the threshold.

    Counting consecutive windows rather than reacting to one is what keeps a
    single noisy period from triggering a rollback.
    """
    r = cfg.rollback
    result = {"is_degraded": False, "consecutive": 0,
              "latest_metric": None, "training_metric": None}

    baseline = champion_training_metric(client, cfg, state)
    if baseline is None:
        return result
    result["training_metric"] = baseline

    if baseline <= 0:
        logger.warning("Champion training metric is %s — cannot compute a "
                       "relative increase.", baseline)
        return result

    profile_table = _profile_table(cfg)
    if not spark.catalog.tableExists(profile_table):
        logger.warning("Profile table '%s' not found — has the monitor run?",
                       profile_table)
        return result

    lookback = r.consecutive_windows + 2

    # New monitor schema: metrics are top-level columns, not metric_name/value rows.
    _struct_metrics = {"f1_score", "precision", "recall", "false_positive_rate"}
    if r.monitor_metric in _struct_metrics:
        _metric_expr = F.col(f"{r.monitor_metric}.weighted")
    else:
        _metric_expr = F.col(r.monitor_metric)

    rows = (
        spark.table(profile_table)
        # ":table" is the monitor's table-level summary row, as opposed to
        # per-column rows. Error metrics like MAE live there.
        .filter(F.col("column_name") == ":table")
        .orderBy(F.col("window.end").desc())
        .limit(lookback)
        .select(_metric_expr.alias("metric_value"),
                F.col("window.end").alias("window_end"))
        .collect()
    )
    if not rows:
        logger.warning(
            "No '%s' rows in '%s'. The monitor computes error metrics only "
            "when labels are present in the inference table.",
            r.monitor_metric, profile_table,
        )
        return result

    result["latest_metric"] = float(rows[0]["metric_value"])

    # Count breaches from the most recent window backwards, stopping at the
    # first healthy one. "3 consecutive" must mean the 3 most recent — a model
    # that was bad in March and fine since is not currently degraded.
    consecutive = 0
    for row in rows:
        value = float(row["metric_value"])

        # Which direction counts as worse depends on the metric. MAE rising is
        # degradation; f1 falling is. Using the wrong one makes a decaying
        # classifier look like it is improving.
        if r.direction == "lower_is_better":
            pct = (baseline - value) / baseline        # score dropped
        else:
            pct = (value - baseline) / baseline        # error grew
        breached = pct >= r.metric_pct_increase
        logger.info("  window %s: %s=%.4f vs training %.4f (%+.1f%% worse) %s",
                    row["window_end"], r.monitor_metric, value, baseline,
                    pct * 100, "BREACH" if breached else "ok")
        if breached:
            consecutive += 1
        else:
            break

    result["consecutive"] = consecutive
    result["is_degraded"] = consecutive >= r.consecutive_windows
    return result


def run_rollback_check(spark, cfg: MonitoringConfig) -> Dict[str, Any]:
    cfg.validate()
    r = cfg.rollback
    logger.info("ROLLBACK CHECK | %s | %s vs %s, +%.0f%% over %d window(s)",
                cfg.full_model_name, r.monitor_metric, r.training_metric,
                r.metric_pct_increase * 100, r.consecutive_windows)

    client = MlflowClient()
    state = check_model_state(client, cfg)

    if not state["has_champion"]:
        send_alert(cfg.alerts, f"No Champion for {cfg.name}",
                   f"{cfg.full_model_name} has no '{cfg.champion_alias}' alias.")
        return {"status": "no_champion"}

    if is_in_settling_window(spark, cfg):
        return {"status": "settling_window"}

    evaluation = evaluate_degradation(spark, client, cfg, state)

    if not evaluation["is_degraded"]:
        logger.info(
            "Champion healthy — latest %s=%s, training=%s, consecutive "
            "breaches=%d (needs %d).",
            r.monitor_metric, evaluation["latest_metric"],
            evaluation["training_metric"], evaluation["consecutive"],
            r.consecutive_windows,
        )
        return {"status": "healthy", **evaluation}

    logger.warning("Degradation confirmed over %d consecutive window(s).",
                   evaluation["consecutive"])

    if not state["can_rollback"]:
        send_alert(
            cfg.alerts, f"Degradation with no rollback target — {cfg.name}",
            f"Model      : {cfg.full_model_name}\n"
            f"Champion   : v{state['champion_version']}\n"
            f"Challenger : none — there is nothing to roll back to.\n"
            f"Live {r.monitor_metric}: {evaluation['latest_metric']}\n"
            f"Training   : {evaluation['training_metric']}\n\n"
            f"Retrain, or register a Challenger.",
        )
        return {"status": "degraded_no_target", **evaluation}

    send_alert(
        cfg.alerts, f"Degradation detected — {cfg.name}",
        f"Model      : {cfg.full_model_name}\n"
        f"Champion   : v{state['champion_version']}\n"
        f"Challenger : v{state['challenger_version']}\n"
        f"Live {r.monitor_metric}: {evaluation['latest_metric']:.4f}\n"
        f"Training   : {evaluation['training_metric']:.4f}\n"
        f"Breached   : {evaluation['consecutive']} consecutive window(s)\n\n"
        f"To roll back (promotes the Challenger):\n"
        f"    python -m src.monitoring.rollback --monitor {cfg.name} --approve",
    )
    return {"status": "degraded", **evaluation, "model_state": state}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--monitor", default=DEFAULT_MONITORING,
                        choices=sorted(MONITORING_CONFIGS))
    args, _ = parser.parse_known_args()
    return args


def main() -> int:
    from pyspark.sql import SparkSession
    args = parse_args()
    spark = SparkSession.builder.getOrCreate()
    try:
        run_rollback_check(spark, get_monitoring_config(args.monitor))
    except Exception as exc:
        logger.error("Rollback check failed: %s", exc, exc_info=True)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
