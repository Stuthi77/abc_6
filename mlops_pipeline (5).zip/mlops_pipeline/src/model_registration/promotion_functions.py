"""
promotion_functions.py
----------------------
Champion/Challenger helpers for Unity Catalog model registration.

Parameterized vs. the earlier version:
  * the model artifact path is passed in, not hardcoded as "runs:/{id}/model"
  * alias names come from RegistryConfig, not the literals "champion"/"challenger"
  * no sys.path hack to another project's workspace folder
  * metric tags are capped, so a run with window-stamped metric keys does not
    write dozens of tags onto every model version

Everything configurable lives in src/config/registry_config.py.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import mlflow
import pandas as pd
from mlflow.exceptions import MlflowException
from mlflow.tracking import MlflowClient

from src.settings.mlops_settings import RegistryConfig
from src.utils.retry import _retry

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────
# Retry-wrapped MLflow calls
# ──────────────────────────────────────────────────────────────────────────
@_retry()
def _safe_register_model(model_uri: str, name: str, tags: dict):
    return mlflow.register_model(model_uri=model_uri, name=name, tags=tags)


@_retry()
def _safe_set_alias(client: MlflowClient, name: str, alias: str, version: str):
    client.set_registered_model_alias(name=name, alias=alias, version=version)


@_retry()
def _safe_delete_alias(client: MlflowClient, name: str, alias: str):
    client.delete_registered_model_alias(name=name, alias=alias)


@_retry()
def _safe_update_version(client: MlflowClient, name: str, version: str, description: str):
    client.update_model_version(name=name, version=version, description=description)


@_retry()
def _safe_get_alias(client: MlflowClient, name: str, alias: str):
    return client.get_model_version_by_alias(name=name, alias=alias)


@_retry()
def _safe_search_versions(client: MlflowClient, filter_string: str):
    return client.search_model_versions(filter_string)


@_retry()
def _safe_get_run(client: MlflowClient, run_id: str):
    return client.get_run(run_id)


def _now_str() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


# ──────────────────────────────────────────────────────────────────────────
# Shared registration path
# ──────────────────────────────────────────────────────────────────────────
def _build_model_uri(run_id: str, model_artifact_path: str,
                     model_uri: Optional[str] = None) -> str:
    """
    URI of the logged model inside a run.

    The artifact path is a parameter because training jobs do not all log to
    "model" — mlflow.<flavor>.log_model(..., name=...) decides the directory,
    and a mismatch surfaces as 'Unable to find a logged_model with
    artifact_path model under run ...'.
    """
    if model_uri:
        return model_uri
    return f"runs:/{run_id}/{model_artifact_path.strip('/')}"


def _build_tags(
    new_run,
    metric: str,
    role: str,
    registry: RegistryConfig,
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, str]:
    """Version tags: capped metrics, run provenance, role, plus config extras."""
    tags: Dict[str, str] = {}

    if registry.copy_metrics_as_tags:
        metrics = dict(new_run.data.metrics)
        selected: Dict[str, float] = {}
        # The comparison metric always makes the cut.
        if metric in metrics:
            selected[metric] = metrics.pop(metric)
        for key in sorted(metrics)[: max(0, registry.max_metric_tags - len(selected))]:
            selected[key] = metrics[key]
        if len(new_run.data.metrics) > len(selected):
            logger.info(
                "Tagging %d of %d run metrics (max_metric_tags=%d).",
                len(selected), len(new_run.data.metrics), registry.max_metric_tags,
            )
        tags.update({k: str(v) for k, v in selected.items()})

    tags.update({
        "model_type": new_run.data.tags.get("model_type", "N/A"),
        "run_name": new_run.data.tags.get("mlflow.runName", "N/A"),
        "role": role,
        "metric_name": metric,
        "registered_date": _now_str(),
    })
    tags.update({k: str(v) for k, v in registry.extra_tags.items()})
    if extra:
        tags.update({k: str(v) for k, v in extra.items()})
    return tags


def _drop_alias_if_present(client: MlflowClient, name: str, alias: str) -> None:
    try:
        _safe_delete_alias(client, name, alias)
    except MlflowException as exc:
        logger.debug("No existing '%s' alias to remove: %s", alias, exc)
    except Exception as exc:                       # retry wrapper re-raises
        logger.debug("Could not remove '%s' alias: %s", alias, exc)


def _register_version(
    client: MlflowClient,
    run_id: str,
    registered_model_name: str,
    new_run,
    metric: str,
    role: str,
    registry: RegistryConfig,
    model_artifact_path: str,
    extra_tags: Optional[Dict[str, Any]] = None,
    model_uri: Optional[str] = None,
):
    model_uri = _build_model_uri(run_id, model_artifact_path, model_uri)
    logger.info("Registering %s from %s", role, model_uri)
    return _safe_register_model(
        model_uri=model_uri,
        name=registered_model_name,
        tags=_build_tags(new_run, metric, role, registry, extra_tags),
    )


# ──────────────────────────────────────────────────────────────────────────
# Scenario 1 — first registration
# ──────────────────────────────────────────────────────────────────────────
def _register_as_champion(
    client: MlflowClient,
    run_id: str,
    registered_model_name: str,
    new_run,
    new_metric_value: float,
    metric: str,
    registry: Optional[RegistryConfig] = None,
    model_artifact_path: str = "model",
    model_uri: Optional[str] = None,
) -> dict:
    """Register a version and give it the champion alias."""
    registry = registry or RegistryConfig()

    model_version = _register_version(
        client, run_id, registered_model_name, new_run, metric,
        role=registry.champion_alias, registry=registry,
        model_artifact_path=model_artifact_path, model_uri=model_uri,
    )
    _safe_set_alias(client, registered_model_name,
                    registry.champion_alias, model_version.version)
    _safe_update_version(
        client,
        name=registered_model_name,
        version=model_version.version,
        description=(
            f"Production Champion Model\n\n"
            f"Performance : {metric} = {new_metric_value:.4f}\n"
            f"Registered  : {_now_str()}\n"
            f"Run ID      : {run_id}"
        ),
    )
    logger.info("Registered as Champion — version: %s | %s: %.4f",
                model_version.version, metric, new_metric_value)

    return {
        "action": "registered_as_champion",
        "new_version": model_version.version,
        "new_alias": registry.champion_alias,
        "champion_version": model_version.version,
        "metric_value": new_metric_value,
        "run_id": run_id,
        "scenario": "first_registration",
    }


# ──────────────────────────────────────────────────────────────────────────
# Scenario 2A — new model wins
# ──────────────────────────────────────────────────────────────────────────
def _promote_to_champion(
    client: MlflowClient,
    run_id: str,
    registered_model_name: str,
    new_run,
    new_metric_value: float,
    metric: str,
    old_champion_version: str,
    registry: Optional[RegistryConfig] = None,
    model_artifact_path: str = "model",
    model_uri: Optional[str] = None,
) -> dict:
    """New version becomes Champion; the previous one becomes Challenger."""
    registry = registry or RegistryConfig()

    model_version = _register_version(
        client, run_id, registered_model_name, new_run, metric,
        role=registry.champion_alias, registry=registry,
        model_artifact_path=model_artifact_path, model_uri=model_uri,
        extra_tags={
            "promoted_from": "new_registration",
            "replaced_version": old_champion_version,
        },
    )

    # Order matters: free the alias before reassigning it.
    _drop_alias_if_present(client, registered_model_name, registry.champion_alias)
    _safe_set_alias(client, registered_model_name,
                    registry.champion_alias, model_version.version)

    _drop_alias_if_present(client, registered_model_name, registry.challenger_alias)
    _safe_set_alias(client, registered_model_name,
                    registry.challenger_alias, old_champion_version)

    _safe_update_version(
        client,
        name=registered_model_name,
        version=model_version.version,
        description=(
            f"Production Champion Model (Promoted)\n\n"
            f"Performance     : {metric} = {new_metric_value:.4f}\n"
            f"Promoted        : {_now_str()}\n"
            f"Replaced version: {old_champion_version}\n"
            f"Run ID          : {run_id}"
        ),
    )
    logger.info("Promoted to Champion — new version: %s | demoted: %s | %s: %.4f",
                model_version.version, old_champion_version, metric, new_metric_value)

    return {
        "action": "promoted_to_champion",
        "new_version": model_version.version,
        "new_alias": registry.champion_alias,
        "champion_version": model_version.version,
        "demoted_version": old_champion_version,
        "metric_value": new_metric_value,
        "run_id": run_id,
        "scenario": "promoted",
    }


# ──────────────────────────────────────────────────────────────────────────
# Scenario 2B — champion holds
# ──────────────────────────────────────────────────────────────────────────
def _register_as_challenger(
    client: MlflowClient,
    run_id: str,
    registered_model_name: str,
    new_run,
    new_metric_value: float,
    metric: str,
    champion_version: str,
    registry: Optional[RegistryConfig] = None,
    model_artifact_path: str = "model",
    model_uri: Optional[str] = None,
) -> dict:
    """Register as Challenger; the Champion is untouched."""
    registry = registry or RegistryConfig()

    model_version = _register_version(
        client, run_id, registered_model_name, new_run, metric,
        role=registry.challenger_alias, registry=registry,
        model_artifact_path=model_artifact_path, model_uri=model_uri,
        extra_tags={"current_champion_version": champion_version},
    )

    _drop_alias_if_present(client, registered_model_name, registry.challenger_alias)
    _safe_set_alias(client, registered_model_name,
                    registry.challenger_alias, model_version.version)

    _safe_update_version(
        client,
        name=registered_model_name,
        version=model_version.version,
        description=(
            f"Challenger Model (Did not outperform Champion)\n\n"
            f"Performance      : {metric} = {new_metric_value:.4f}\n"
            f"Registered       : {_now_str()}\n"
            f"Current Champion : Version {champion_version}\n"
            f"Run ID           : {run_id}"
        ),
    )
    logger.info("Registered as Challenger — version: %s | champion remains: %s | %s: %.4f",
                model_version.version, champion_version, metric, new_metric_value)

    return {
        "action": "registered_as_challenger",
        "new_version": model_version.version,
        "new_alias": registry.challenger_alias,
        "champion_version": champion_version,
        "metric_value": new_metric_value,
        "run_id": run_id,
        "scenario": "challenger",
    }


# ──────────────────────────────────────────────────────────────────────────
# Lookup + comparison
# ──────────────────────────────────────────────────────────────────────────
def _get_champion_version(
    client: MlflowClient,
    registered_model_name: str,
    existing_versions=None,
    registry: Optional[RegistryConfig] = None,
):
    """ModelVersion holding the champion alias, or None. Alias is authoritative."""
    registry = registry or RegistryConfig()
    try:
        champion = _safe_get_alias(client, registered_model_name, registry.champion_alias)
        logger.info("Found Champion: version %s", champion.version)
        return champion
    except MlflowException as exc:
        logger.info("No '%s' alias on '%s': %s",
                    registry.champion_alias, registered_model_name, exc)
        return None
    except Exception as exc:
        logger.info("Could not resolve '%s' alias on '%s': %s",
                    registry.champion_alias, registered_model_name, exc)
        return None


def _is_model_better(
    new_value: float,
    champion_value: Optional[float],
    metric_direction: str,
    improvement_threshold: float,
) -> bool:
    """
    True when new_value beats champion_value by at least improvement_threshold
    (a fraction: 0.02 == 2%).
    """
    if champion_value is None:
        return True

    if champion_value == 0:
        logger.warning(
            "Champion metric is 0 — relative improvement is undefined; "
            "comparing absolutely."
        )
        return new_value < 0 if metric_direction == "minimize" else new_value > 0

    if metric_direction == "minimize":
        improvement = (champion_value - new_value) / abs(champion_value)
    else:
        improvement = (new_value - champion_value) / abs(champion_value)

    logger.info("Improvement over Champion: %.2f%% (threshold %.2f%%)",
                improvement * 100, improvement_threshold * 100)
    return improvement >= improvement_threshold


# ──────────────────────────────────────────────────────────────────────────
# Summary
# ──────────────────────────────────────────────────────────────────────────
def _print_final_state(
    client: MlflowClient,
    registered_model_name: str,
    metric: str,
    registry: Optional[RegistryConfig] = None,
) -> None:
    """Log every version with its alias and metric value."""
    registry = registry or RegistryConfig()

    logger.info("=" * 80)
    logger.info("FINAL MODEL REGISTRY STATE — %s", registered_model_name)
    logger.info("=" * 80)

    all_versions = _safe_search_versions(client, f"name='{registered_model_name}'")
    if not all_versions:
        logger.info("No versions found.")
        return

    # Resolve aliases once rather than per version.
    alias_by_version: Dict[str, str] = {}
    for alias in (registry.champion_alias, registry.challenger_alias):
        try:
            mv = _safe_get_alias(client, registered_model_name, alias)
            alias_by_version[str(mv.version)] = alias
        except Exception:
            pass

    rows = []
    for version in all_versions:
        try:
            run = _safe_get_run(client, version.run_id)
            value = run.data.metrics.get(metric)
            # Window-stamped keys differ per run; fall back to the tag the
            # registration wrote.
            if value is None:
                tagged = (version.tags or {}).get(metric)
                value = float(tagged) if tagged is not None else None
            metric_str = f"{value:.4f}" if value is not None else "N/A"
        except Exception as exc:
            logger.warning("Could not fetch run for version %s: %s", version.version, exc)
            metric_str = "N/A"

        rows.append({
            "Version": version.version,
            "Alias": alias_by_version.get(str(version.version), "-"),
            metric: metric_str,
            "Created": pd.to_datetime(
                version.creation_timestamp, unit="ms"
            ).strftime("%Y-%m-%d %H:%M"),
            "Run ID": version.run_id[:8] + "...",
        })

    summary = pd.DataFrame(rows).sort_values("Version", ascending=False)
    logger.info("\n%s", summary.to_string(index=False))
