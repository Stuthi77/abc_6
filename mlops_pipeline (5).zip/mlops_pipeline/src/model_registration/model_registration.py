"""
model_registration.py
---------------------
MLflow model registration to Unity Catalog with Champion/Challenger management.

Run as a script:
    python model_registration.py --pipeline total_cost --validate_only
    python model_registration.py --pipeline total_cost
    python model_registration.py --pipeline delay_days --skip_baseline

Run inside a notebook (no sys.exit, real tracebacks):
    import mlflow
    from src.config.registry_config import get_pipeline
    from src.model_registration.model_registration import run_pipeline

    mlflow.set_registry_uri("databricks-uc")
    pipeline = get_pipeline("total_cost")
    run_pipeline(spark, pipeline, fail_fast=True)

Everything table- or column-specific lives in src/config/registry_config.py.

Promotion logic:
    1. Nothing registered       -> new model becomes Champion
    2. New model is better      -> new = Champion, old = Challenger
    3. New model is not better  -> new = Challenger, Champion stays
"""
from __future__ import annotations

import argparse
import logging
import re
import sys
from datetime import datetime
from types import SimpleNamespace
from typing import Any, Dict, List, Optional, TypedDict

import numpy as np
import pandas as pd
from dateutil.relativedelta import relativedelta
from pyspark.sql import Column, DataFrame, SparkSession, functions as F

import mlflow
from mlflow.exceptions import MlflowException
from mlflow.tracking import MlflowClient

from src.settings.mlops_settings import (
    DEFAULT_USE_CASE as DEFAULT_PIPELINE,
    USE_CASES as PIPELINES,
    ModelSpec,
    PipelineConfig,
    RegistryConfig,
    TableConfig,
    registration_pipeline as get_pipeline,
)
from src.model_registration.model_formats import load_model_file, log_model_object
from src.model_registration.promotion_functions import (
    _get_champion_version,
    _is_model_better,
    _print_final_state,
    _promote_to_champion,
    _register_as_challenger,
    _register_as_champion,
    _safe_get_run,
)
from src.utils.retry import _retry

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

# Name of the DATE column this module adds to the feature DataFrame.
EVENT_DATE_COL = "__event_date"


class RegistrationResult(TypedDict):
    registered_model_name: str
    new_version: str
    new_alias: str           # "champion" | "challenger"
    champion_version: str
    run_id: str
    metric: str
    metric_value: float
    scenario: str            # first_registration | promoted | challenger | skipped_duplicate


# ──────────────────────────────────────────────────────────────────────────
# Date resolution + schema guards
# ──────────────────────────────────────────────────────────────────────────
def _date_from_parts(year: str, month: str, day: str) -> Column:
    """
    Compose a DATE from three numeric columns without ever raising.

    Why this is not simply make_date(y, m, d):
      * try_make_date does not exist on every DBR version (UNRESOLVED_ROUTINE)
      * make_date RAISES on impossible dates (e.g. Feb 30) when ANSI mode is on,
        and wrapping it in when(...) does NOT help — Spark evaluates both
        branches, so the exception fires anyway

    Strategy that is safe on every runtime and ANSI setting:
      1. clamp year/month into always-valid ranges, so the date call cannot fail
      2. build the FIRST of that month — always a real date
      3. add (day - 1) days with date_add — arithmetic, never throws
      4. if the month changed, the day overflowed (Feb 30 -> Mar 1) -> NULL
      5. NULL out anything implausible from the start
    """
    y = F.col(year).cast("int")
    m = F.col(month).cast("int")
    d = F.col(day).cast("int")

    plausible = (
        y.isNotNull() & m.isNotNull() & d.isNotNull()
        & y.between(1000, 9999) & m.between(1, 12) & d.between(1, 31)
    )

    # Clamped inputs — guarantee the construction itself cannot raise.
    y_safe = F.when(y.between(1000, 9999), y).otherwise(F.lit(2000))
    m_safe = F.when(m.between(1, 12), m).otherwise(F.lit(1))
    d_safe = F.when(d.between(1, 31), d).otherwise(F.lit(1))

    # First of month from a zero-padded string: always a valid date, so
    # to_date never has to fail, and no make_date/try_make_date is needed.
    first_of_month = F.to_date(
        F.concat(
            F.lpad(y_safe.cast("string"), 4, "0"),
            F.lpad(m_safe.cast("string"), 2, "0"),
            F.lit("01"),
        ),
        "yyyyMMdd",
    )

    candidate = F.date_add(first_of_month, d_safe - F.lit(1))

    # Month drift means the day overflowed that month's length.
    in_month = F.month(candidate) == m_safe

    return F.when(plausible & in_month, candidate).otherwise(F.lit(None).cast("date"))


def to_date_col(cfg: TableConfig) -> Column:
    """
    Build a DATE Column from the feature table according to cfg.date_kind.

    "parts" exists because tables like sample_data_prepared store the date as
    three separate INT columns (REQ_YEAR / REQ_MONTH / REQ_DAY) and there is
    no single column to cast.
    """
    kind = cfg.date_kind

    if kind == "parts":
        return _date_from_parts(*cfg.date_parts)

    if kind == "yyyymmdd_int":                   # 20240131
        return F.to_date(F.col(cfg.date_col).cast("string"), "yyyyMMdd")

    if kind == "unix_days":                      # days since 1970-01-01
        return F.date_from_unix_date(F.col(cfg.date_col).cast("int"))

    if kind == "unix_seconds":                   # epoch seconds
        return F.to_date(F.from_unixtime(F.col(cfg.date_col).cast("long")))

    if cfg.date_format:                          # string column
        return F.to_date(F.col(cfg.date_col).cast("string"), cfg.date_format)

    return F.col(cfg.date_col).cast("date")      # already DATE/TIMESTAMP


def date_source_columns(cfg: TableConfig) -> List[str]:
    """Which raw columns feed the event date."""
    return list(cfg.date_parts) if cfg.date_kind == "parts" else [cfg.date_col]


def with_event_date(df: DataFrame, cfg: TableConfig) -> DataFrame:
    """Attach the resolved DATE column and drop sentinel rows."""
    out = df.withColumn(EVENT_DATE_COL, to_date_col(cfg))
    if cfg.min_valid_date:
        out = out.filter(F.col(EVENT_DATE_COL) >= F.to_date(F.lit(cfg.min_valid_date)))
    return out


def require_columns(df: DataFrame, columns: List[str], table_name: str) -> None:
    """Readable failure naming the table and its actual columns."""
    available = set(df.columns)
    missing = [c for c in columns if c not in available]
    if missing:
        raise ValueError(
            f"Table '{table_name}' is missing column(s) {missing}.\n"
            f"Available columns: {sorted(available)}\n"
            f"Fix the names in registry_config.py."
        )


def validate_table_config(spark: SparkSession, cfg: TableConfig) -> None:
    """Check the column contract before any MLflow work happens."""
    cfg.validate()

    features = spark.read.table(cfg.feature_table)
    require_columns(features, date_source_columns(cfg), cfg.feature_table)
    if cfg.join_keys:
        require_columns(features, cfg.join_keys, cfg.feature_table)
    for col in cfg.exclude_from_features:
        if col not in features.columns:
            logger.warning(
                "exclude_from_features lists '%s', absent from '%s' — ignoring.",
                col, cfg.feature_table,
            )

    if cfg.actual_table and spark.catalog.tableExists(cfg.actual_table):
        actuals = spark.read.table(cfg.actual_table)
        require_columns(
            actuals, cfg.resolved_join_keys() + [cfg.label_col], cfg.actual_table
        )

    # Did the date actually resolve?
    usable = (
        features.select(to_date_col(cfg).alias("d"))
        .filter(F.col("d").isNotNull())
        .limit(1)
        .count()
    )
    if usable == 0:
        dtypes = dict(features.dtypes)
        detail = {c: dtypes.get(c) for c in date_source_columns(cfg)}
        raise ValueError(
            f"Could not build a DATE from '{cfg.feature_table}' with "
            f"date_kind='{cfg.date_kind}' and columns {detail} — all NULL.\n"
            f"  separate year/month/day INTs -> date_kind='parts'\n"
            f"  INT like 20240131            -> date_kind='yyyymmdd_int'\n"
            f"  INT days since epoch         -> date_kind='unix_days'\n"
            f"  STRING                       -> date_kind='auto' + date_format"
        )

    if cfg.min_valid_date:
        total = features.count()
        kept = with_event_date(features, cfg).count()
        logger.info(
            "Date coverage: %d / %d rows on or after %s (%d dropped as sentinel/NULL).",
            kept, total, cfg.min_valid_date, total - kept,
        )
        if kept == 0:
            raise ValueError(
                f"Every row in '{cfg.feature_table}' falls before "
                f"min_valid_date={cfg.min_valid_date}. Lower or remove it."
            )

    logger.info("Config validated against %s", cfg.feature_table)


# ──────────────────────────────────────────────────────────────────────────
# Retry-wrapped MLflow calls
# ──────────────────────────────────────────────────────────────────────────
@_retry()
def _safe_search_runs(client: MlflowClient, experiment_ids: List[str],
                      order_by: List[str], max_results: int,
                      filter_string: Optional[str] = None):
    return client.search_runs(
        experiment_ids=experiment_ids,
        filter_string=filter_string or "",
        order_by=order_by,
        max_results=max_results,
    )


@_retry()
def _safe_search_model_versions(client: MlflowClient, filter_string: str):
    return client.search_model_versions(filter_string)


def _run_already_registered(existing_versions, run_id: str, model_name: str) -> bool:
    for v in existing_versions:
        if v.run_id == run_id:
            logger.warning(
                "Run '%s' is already version %s of '%s'. Skipping.",
                run_id, v.version, model_name,
            )
            return True
    return False


def _build_model_name(catalog: str, schema: str, model_name: str) -> str:
    return f"{catalog}.{schema}.{model_name}"


# ──────────────────────────────────────────────────────────────────────────
# Resolve a ModelSpec to a run
# ──────────────────────────────────────────────────────────────────────────
def _log_file_as_run(spec: ModelSpec, input_example: Optional[pd.DataFrame] = None) -> str:
    """Load a .pkl/.ubj/.cb/... file, log it under the right flavor, return run_id."""
    model, fmt = load_model_file(spec.model_path, spec.model_format, spec.loader_kwargs)

    if spec.experiment_path:
        mlflow.set_experiment(spec.experiment_path)

    run_name = f"{spec.model_name}_{fmt.name}_{datetime.utcnow():%Y%m%d_%H%M%S}"
    with mlflow.start_run(run_name=run_name) as run:
        mlflow.set_tags({
            "model_type": fmt.name,
            "source_artifact": spec.model_path,
            "registered_via": "file",
            **spec.tags,
        })
        if spec.params:
            mlflow.log_params(spec.params)
        mlflow.log_metrics(spec.metrics)

        log_model_object(
            model,
            fmt,
            artifact_path="model",
            input_example=input_example,
            extra_pip_requirements=fmt.pip_requirements,
        )
        logger.info("Logged %s model from %s as run %s",
                    fmt.name, spec.model_path, run.info.run_id)
        return run.info.run_id


@_retry()
def _safe_list_artifacts(client: MlflowClient, run_id: str, path: Optional[str] = None):
    return client.list_artifacts(run_id, path)


def _logged_models_for_run(client: MlflowClient, run_id: str) -> List[Any]:
    """
    MLflow 3 LoggedModel entities produced by this run.

    In MLflow 3 a logged model is a first-class entity linked to the run via
    run.outputs.model_outputs; its files live under the model's own location,
    so list_artifacts(run_id) may show nothing even though a model exists.
    MLflow 2 has no such entity and this returns [].
    """
    models: List[Any] = []
    try:
        run = _safe_get_run(client, run_id)
        outputs = getattr(run, "outputs", None)
        for out in (getattr(outputs, "model_outputs", None) or []):
            try:
                models.append(client.get_logged_model(out.model_id))
            except Exception as exc:
                logger.debug("Could not fetch logged model %s: %s",
                             getattr(out, "model_id", "?"), exc)
    except Exception as exc:
        logger.debug("Could not read run outputs for %s: %s", run_id, exc)
    return models


def _model_artifact_dirs(client: MlflowClient, run_id: str) -> List[str]:
    """
    Names under which this run logged a model — LoggedModel names (MLflow 3)
    plus artifact directories containing an MLmodel file (MLflow 2).

    Empty means the run logged no model at all, the normal case for
    hyperparameter trials that log metrics only.
    """
    found: List[str] = [m.name for m in _logged_models_for_run(client, run_id)
                        if getattr(m, "name", None)]

    try:
        entries = _safe_list_artifacts(client, run_id)
    except Exception as exc:
        logger.debug("Could not list artifacts for run %s: %s", run_id, exc)
        return list(dict.fromkeys(found))

    for entry in entries:
        if not getattr(entry, "is_dir", False):
            continue
        try:
            children = _safe_list_artifacts(client, run_id, entry.path)
        except Exception:
            continue
        if any(c.path.rsplit("/", 1)[-1] == "MLmodel" for c in children):
            found.append(entry.path)
    return list(dict.fromkeys(found))


def _has_model_at(client: MlflowClient, run_id: str, artifact_path: str) -> bool:
    """True when this run has a registrable model under `artifact_path`."""
    # MLflow 3 first. On Databricks a logged model is a separate entity
    # attached to the run, and the run's own artifact tree is often empty —
    # so checking artifacts alone reports "no model" for a run that has one.
    for model in _logged_models_for_run(client, run_id):
        if getattr(model, "name", None) == artifact_path:
            return True

    try:
        children = _safe_list_artifacts(client, run_id, artifact_path)
    except Exception:
        return False
    return any(c.path.rsplit("/", 1)[-1] == "MLmodel" for c in children)


def _resolve_model_uri(client: MlflowClient, run_id: str, artifact_path: str) -> str:
    """
    URI to register from.

    Prefers the MLflow 3 models:/<model_id> form, which addresses the logged
    model directly; falls back to runs:/<run_id>/<artifact_path>.
    """
    for model in _logged_models_for_run(client, run_id):
        if getattr(model, "name", None) == artifact_path:
            model_id = getattr(model, "model_id", None)
            if model_id:
                logger.info("Registering from logged model %s (%s).",
                            model_id, artifact_path)
                return f"models:/{model_id}"
    return f"runs:/{run_id}/{artifact_path.strip('/')}"


def _resolve_metric(run, spec: ModelSpec) -> tuple[str, float]:
    """
    Find the metric to compare on in one run. Returns (key, value).

    Exact `metric` wins when present. Otherwise `metric_pattern` is matched
    against the run's metric keys — needed when keys carry a window stamp
    (rmse_val_2025-01-10_2025-03-07) and so differ run to run.
    """
    metrics = run.data.metrics

    if spec.metric and spec.metric in metrics:
        return spec.metric, metrics[spec.metric]

    if spec.metric_pattern:
        rx = re.compile(spec.metric_pattern)
        matches = sorted(k for k in metrics if rx.search(k))
        if matches:
            key = matches[-1] if spec.metric_select == "latest" else matches[0]
            if len(matches) > 1:
                logger.info(
                    "Pattern '%s' matched %d keys; using '%s' (%s).",
                    spec.metric_pattern, len(matches), key, spec.metric_select,
                )
            return key, metrics[key]

    wanted = spec.metric or f"pattern {spec.metric_pattern!r}"
    raise ValueError(
        f"No metric matching {wanted} in run '{run.info.run_id}'. "
        f"Available: {sorted(metrics)}"
    )


def _require_model_artifact(client: MlflowClient, run_id: str, spec: ModelSpec) -> None:
    """
    Fail early and clearly when a run has no model to register.

    Without this the failure surfaces much later as an opaque
    'Unable to find a logged_model with artifact_path model under run ...',
    wrapped in a retry that repeats it three times.
    """
    if _has_model_at(client, run_id, spec.model_artifact_path):
        return

    other = _model_artifact_dirs(client, run_id)
    if other:
        raise ValueError(
            f"Run '{run_id}' logs its model under {other}, not "
            f"'{spec.model_artifact_path}'. Set model_artifact_path='{other[0]}' "
            f"on this ModelSpec in registry_config.py."
        )

    # Say what was actually inspected — "no model" is easy to misread when the
    # run plainly finished training.
    try:
        artifact_roots = [a.path for a in _safe_list_artifacts(client, run_id)]
    except Exception:
        artifact_roots = ["<could not list>"]
    raise ValueError(
        f"Run '{run_id}' has no registrable model.\n"
        f"  logged models (MLflow 3): none linked to this run\n"
        f"  run artifacts           : {artifact_roots}\n"
        f"Either this is a metric-only hyperparameter trial, or training "
        f"failed before log_model. Check that the run finished and logged a "
        f"model under '{spec.model_artifact_path}'."
    )


def _find_experiment(path: str):
    """
    Look up an experiment, tolerating a trailing slash.

    MLflow matches experiment names exactly, so
    '/Workspace/Users/me/sample_model/' and '.../sample_model' are different
    strings and only one of them exists.
    """
    candidates = [path, path.rstrip("/")]
    if not path.endswith("/"):
        candidates.append(path + "/")

    for candidate in dict.fromkeys(candidates):          # preserve order, dedupe
        experiment = mlflow.get_experiment_by_name(candidate)
        if experiment is not None:
            if candidate != path:
                logger.info("Matched experiment as '%s'.", candidate)
            return experiment

    raise ValueError(
        f"Experiment '{path}' not found (also tried with/without a trailing "
        f"slash). Use the workspace path (/Workspace/Users/...), not the "
        f"browser URL. List what exists with:\n"
        f"    mlflow.search_experiments()"
    )


def _resolve_source_run(client: MlflowClient, spec: ModelSpec,
                        input_example: Optional[pd.DataFrame] = None):
    if spec.source == "run":
        logger.info("Source: run_id %s", spec.run_id)
        _require_model_artifact(client, spec.run_id, spec)
        return _safe_get_run(client, spec.run_id), spec.run_id

    if spec.source == "file":
        logger.info("Source: file %s", spec.model_path)
        run_id = _log_file_as_run(spec, input_example=input_example)
        return _safe_get_run(client, run_id), run_id

    logger.info("Source: best run in %s", spec.experiment_path)
    experiment = _find_experiment(spec.experiment_path)

    # Always rank client-side.
    #
    # The obvious approach — order_by=["metrics.X ASC"], max_results=1 — does
    # NOT work. MLflow sorts on the metric but does not exclude runs that lack
    # it, so the top result can be a run with no metric and no model. In
    # practice it returned a FAILED nested Optuna trial. Hence: fetch a page,
    # filter to FINISHED runs that actually have the metric, rank here.
    runs = _safe_search_runs(
        client,
        experiment_ids=[experiment.experiment_id],
        order_by=["attributes.start_time DESC"],
        max_results=spec.search_max_results,
        filter_string=spec.run_filter,
    )
    if not runs:
        raise ValueError(
            f"No runs found in experiment '{spec.experiment_path}'"
            + (f" matching filter {spec.run_filter!r}." if spec.run_filter else ".")
        )

    scored, skipped_status, skipped_metric = [], 0, 0
    for run in runs:
        if spec.require_finished and run.info.status != "FINISHED":
            skipped_status += 1
            continue
        try:
            key, value = _resolve_metric(run, spec)
        except ValueError:
            skipped_metric += 1             # trial run, or predates the metric
            continue
        scored.append((value, key, run))

    logger.info(
        "Candidates: %d scanned, %d skipped (not FINISHED), %d skipped "
        "(no matching metric), %d scoreable.",
        len(runs), skipped_status, skipped_metric, len(scored),
    )

    if not scored:
        wanted = spec.metric or spec.metric_pattern
        sample = sorted(runs[0].data.metrics) if runs else []
        raise ValueError(
            f"No FINISHED run in '{spec.experiment_path}' has a metric matching "
            f"{wanted!r}.\n"
            f"Metrics on the most recent run ({runs[0].info.run_id}, status "
            f"{runs[0].info.status}): {sample}\n"
            f"Nested hyperparameter trials log per-split metrics; the parent "
            f"refit run logs the summary metric. Narrow the search with "
            f"run_filter, e.g. \"tags.stage = 'best_model_refit'\"."
        )

    # Best first. A run only qualifies if it actually logged a model —
    # hyperparameter trials log metrics without one, and they often score best.
    scored.sort(key=lambda t: t[0], reverse=(spec.metric_direction == "maximize"))

    skipped_no_model = 0
    for value, key, run in scored[: spec.max_artifact_checks]:
        if _has_model_at(client, run.info.run_id, spec.model_artifact_path):
            if skipped_no_model:
                logger.info(
                    "Skipped %d better-scoring run(s) with no logged model.",
                    skipped_no_model,
                )
            logger.info(
                "Best registrable run = %s (%s: %.4f)", run.info.run_id, key, value
            )
            return run, run.info.run_id

        skipped_no_model += 1
        other = _model_artifact_dirs(client, run.info.run_id)
        if other:
            raise ValueError(
                f"Run '{run.info.run_id}' logs its model under {other}, not "
                f"'{spec.model_artifact_path}'. Set model_artifact_path='{other[0]}' "
                f"on this ModelSpec in registry_config.py."
            )

    checked = min(len(scored), spec.max_artifact_checks)
    raise ValueError(
        f"None of the top {checked} runs by '{spec.metric or spec.metric_pattern}' in "
        f"'{spec.experiment_path}' have a model logged at "
        f"'{spec.model_artifact_path}'. These look like metric-only "
        f"hyperparameter trials. Either log the model on the winning run, or "
        f"point the spec at it directly with source='run' + run_id, or raise "
        f"max_artifact_checks (currently {spec.max_artifact_checks})."
    )


# ──────────────────────────────────────────────────────────────────────────
# Core registration
# ──────────────────────────────────────────────────────────────────────────
def model_registration(
    spec: ModelSpec,
    catalog: str,
    schema: str,
    input_example: Optional[pd.DataFrame] = None,
    registry: Optional[RegistryConfig] = None,
) -> RegistrationResult:
    """Register one ModelSpec with Champion/Challenger handling."""
    spec.validate()
    registry = registry or RegistryConfig()

    client = MlflowClient()
    registered_model_name = _build_model_name(catalog, schema, spec.model_name)

    logger.info("Target model : %s", registered_model_name)
    logger.info("Metric       : %s (%s)",
                spec.metric or spec.metric_pattern, spec.metric_direction)

    new_run, new_run_id = _resolve_source_run(client, spec, input_example)
    new_metric_key, new_metric_value = _resolve_metric(new_run, spec)
    model_uri = _resolve_model_uri(client, new_run_id, spec.model_artifact_path)

    logger.info(
        "New model — run_id: %s | run_name: %s | model_type: %s | %s: %.4f",
        new_run_id,
        new_run.data.tags.get("mlflow.runName", "N/A"),
        new_run.data.tags.get("model_type", "N/A"),
        new_metric_key,
        new_metric_value,
    )

    try:
        existing_versions = _safe_search_model_versions(
            client, f"name='{registered_model_name}'"
        )
        model_exists = len(existing_versions) > 0
    except MlflowException as exc:
        if "RESOURCE_DOES_NOT_EXIST" in str(exc):
            logger.info("Model not yet registered in Unity Catalog.")
            model_exists, existing_versions = False, []
        else:
            raise

    if model_exists and _run_already_registered(
        existing_versions, new_run_id, registered_model_name
    ):
        return RegistrationResult(
            registered_model_name=registered_model_name,
            new_version="N/A",
            new_alias="already_registered",
            champion_version="N/A",
            run_id=new_run_id,
            metric=new_metric_key,
            metric_value=new_metric_value,
            scenario="skipped_duplicate",
        )

    champion_version = (
        _get_champion_version(client, registered_model_name, existing_versions,
                              registry=registry)
        if model_exists else None
    )

    if champion_version is None:
        if model_exists:
            logger.warning("Versions exist but no Champion alias — registering as Champion.")
        else:
            logger.info("SCENARIO: first registration — registering as Champion.")
        result = _register_as_champion(
            client=client,
            run_id=new_run_id,
            registered_model_name=registered_model_name,
            new_run=new_run,
            new_metric_value=new_metric_value,
            metric=new_metric_key,
            registry=registry,
            model_artifact_path=spec.model_artifact_path,
            model_uri=model_uri,
        )
    else:
        try:
            champion_run = _safe_get_run(client, champion_version.run_id)
        except MlflowException as exc:
            if "RESOURCE_DOES_NOT_EXIST" not in str(exc):
                raise
            # The Champion's source run is not reachable from this workspace
            # (logged elsewhere on the metastore, or its experiment was
            # deleted). Registration copies run metrics onto version tags, so
            # compare against those instead.
            logger.warning(
                "Champion run %s not found in this workspace; using version %s tags as metrics.",
                champion_version.run_id, champion_version.version,
            )
            full_version = client.get_model_version(
                registered_model_name, champion_version.version
            )
            tag_metrics: Dict[str, float] = {}
            for k, v in (full_version.tags or {}).items():
                try:
                    tag_metrics[k] = float(v)
                except (TypeError, ValueError):
                    pass
            champion_run = SimpleNamespace(
                info=SimpleNamespace(run_id=champion_version.run_id),
                data=SimpleNamespace(metrics=tag_metrics),
            )
        # Resolve separately: with window-stamped keys the Champion's metric
        # name differs from the challenger's, even for the same measure.
        champion_metric_key, champion_metric_value = _resolve_metric(champion_run, spec)

        logger.info("Current Champion — version: %s | %s: %.4f",
                    champion_version.version, champion_metric_key, champion_metric_value)
        if champion_metric_key != new_metric_key:
            logger.info(
                "Comparing across differently-stamped keys: new '%s' vs champion '%s'.",
                new_metric_key, champion_metric_key,
            )

        if _is_model_better(
            new_value=new_metric_value,
            champion_value=champion_metric_value,
            metric_direction=spec.metric_direction,
            improvement_threshold=spec.improvement_threshold,
        ):
            logger.info("SCENARIO: new model wins — promoting; old Champion -> Challenger.")
            result = _promote_to_champion(
                client=client,
                run_id=new_run_id,
                registered_model_name=registered_model_name,
                new_run=new_run,
                new_metric_value=new_metric_value,
                metric=new_metric_key,
                old_champion_version=champion_version.version,
                registry=registry,
                model_artifact_path=spec.model_artifact_path,
                model_uri=model_uri,
            )
        else:
            logger.info("SCENARIO: Champion holds — registering new model as Challenger.")
            result = _register_as_challenger(
                client=client,
                run_id=new_run_id,
                registered_model_name=registered_model_name,
                new_run=new_run,
                new_metric_value=new_metric_value,
                metric=new_metric_key,
                champion_version=champion_version.version,
                registry=registry,
                model_artifact_path=spec.model_artifact_path,
                model_uri=model_uri,
            )

    _print_final_state(client, registered_model_name, new_metric_key, registry)
    result["registered_model_name"] = registered_model_name
    result["metric"] = new_metric_key
    return result


def run_all_registrations(
    models: Dict[str, ModelSpec],
    catalog: str,
    schema: str,
    input_example: Optional[pd.DataFrame] = None,
    fail_fast: bool = False,
    registry: Optional[RegistryConfig] = None,
) -> Dict[str, Any]:
    """
    Register every spec. Returns key -> RegistrationResult | {"error": ...}.

    Errors are captured so one bad model does not abort the rest. Pass
    fail_fast=True (or --fail_fast) to let the exception propagate instead —
    useful in a notebook, where a caught error only shows up as SystemExit: 1.
    """
    results: Dict[str, Any] = {}
    for model_key, spec in models.items():
        logger.info("=" * 70)
        logger.info("Processing model key: %s", model_key)
        try:
            results[model_key] = model_registration(
                spec, catalog=catalog, schema=schema,
                input_example=input_example, registry=registry,
            )
        except Exception as exc:
            if fail_fast:
                raise
            logger.error("Registration failed for '%s': %s", model_key, exc, exc_info=True)
            results[model_key] = {"error": str(exc)}
    return results


# ──────────────────────────────────────────────────────────────────────────
# Test window + baseline
# ──────────────────────────────────────────────────────────────────────────
def _daily_counts(spark: SparkSession, cfg: TableConfig) -> pd.Series:
    """Row count per event date, ascending. One aggregation, not one per probe."""
    pdf = (
        with_event_date(spark.read.table(cfg.feature_table), cfg)
        .groupBy(F.col(EVENT_DATE_COL).alias("d"))
        .count()
        .toPandas()
    )
    if pdf.empty:
        raise ValueError(
            f"No usable dates in '{cfg.feature_table}' with date_kind="
            f"'{cfg.date_kind}' on {date_source_columns(cfg)}. "
            f"Table may be empty or every date is a sentinel."
        )
    series = pd.Series(pdf["count"].values, index=pd.to_datetime(pdf["d"]))
    return series.sort_index()


def _window_rows(counts: pd.Series, start, end) -> int:
    """Rows in [start, end]."""
    return int(counts.loc[(counts.index >= start) & (counts.index <= end)].sum())


def get_test_ranges(spark: SparkSession, cfg: TableConfig) -> tuple[str, str]:
    """
    Pick the baseline scoring window.

    "fixed"    — the last cfg.test_months before MAX(date).
    "anchored" — walk the end date back until the window holds at least
                 cfg.min_baseline_rows, giving up after
                 cfg.max_anchor_lookback_months. Sparse recent data otherwise
                 produces a window of a few rows, and a reference distribution
                 that small makes drift comparison meaningless.
    """
    features = spark.read.table(cfg.feature_table)
    require_columns(features, date_source_columns(cfg), cfg.feature_table)

    counts = _daily_counts(spark, cfg)
    max_date = counts.index.max()

    if cfg.baseline_window_mode == "fixed":
        end = max_date
        start = end - relativedelta(months=cfg.test_months)
        rows = _window_rows(counts, start, end)
        logger.info("Test window — %s -> %s (%d months, %d rows)",
                    start.date(), end.date(), cfg.test_months, rows)
        if rows < cfg.min_baseline_rows:
            logger.warning(
                "Only %d rows in the window (min_baseline_rows=%d). A reference "
                "distribution this small is not usable for drift detection — "
                "consider baseline_window_mode='anchored' or a larger "
                "test_months.", rows, cfg.min_baseline_rows,
            )
        return start.strftime("%Y-%m-%d"), end.strftime("%Y-%m-%d")

    # Anchored: try each observed date as the window end, newest first.
    floor_date = max_date - relativedelta(months=cfg.max_anchor_lookback_months)
    candidates = [d for d in counts.index[::-1] if d >= floor_date]

    best_rows, best_end = -1, None
    for end in candidates:
        start = end - relativedelta(months=cfg.test_months)
        rows = _window_rows(counts, start, end)
        if rows > best_rows:
            best_rows, best_end = rows, end
        if rows >= cfg.min_baseline_rows:
            if end != max_date:
                logger.info(
                    "Anchored the window at %s rather than MAX(date) %s — "
                    "recent data is too sparse.", end.date(), max_date.date(),
                )
            logger.info("Test window — %s -> %s (%d months, %d rows)",
                        start.date(), end.date(), cfg.test_months, rows)
            return start.strftime("%Y-%m-%d"), end.strftime("%Y-%m-%d")

    best_start = best_end - relativedelta(months=cfg.test_months) if best_end is not None else None

    # Work out what WOULD satisfy min_baseline_rows, so the fix is a value to
    # copy rather than a number to guess at.
    suggestion = _suggest_window(counts, cfg)

    span_months = max(
        1,
        (max_date.year - counts.index.min().year) * 12
        + (max_date.month - counts.index.min().month),
    )
    raise ValueError(
        f"No {cfg.test_months}-month window in '{cfg.feature_table}' holds "
        f"{cfg.min_baseline_rows} rows (searched back "
        f"{cfg.max_anchor_lookback_months} months from {max_date.date()}).\n"
        f"Best found: {best_rows} rows ending "
        f"{best_end.date() if best_end is not None else 'n/a'} "
        f"(from {best_start.date() if best_start is not None else 'n/a'}).\n"
        f"Data: {int(counts.sum())} rows from {counts.index.min().date()} to "
        f"{max_date.date()} (~{span_months} months, "
        f"{int(counts.sum()) / span_months:.0f}/month).\n"
        f"{suggestion}"
    )


def _suggest_window(counts: pd.Series, cfg: TableConfig) -> str:
    """Smallest test_months that would satisfy min_baseline_rows, if any."""
    max_date = counts.index.max()
    total_span = max(
        1,
        (max_date.year - counts.index.min().year) * 12
        + (max_date.month - counts.index.min().month),
    )

    for months in range(cfg.test_months + 1, total_span + 1):
        floor_date = max_date - relativedelta(months=cfg.max_anchor_lookback_months)
        for end in (d for d in counts.index[::-1] if d >= floor_date):
            start = end - relativedelta(months=months)
            if _window_rows(counts, start, end) >= cfg.min_baseline_rows:
                note = ""
                if months > cfg.max_anchor_lookback_months:
                    note = (f" (also raise max_anchor_lookback_months to at "
                            f"least {months})")
                return (f"Fix: set test_months={months} in registry_config.py — "
                        f"a {months}-month window ending {end.date()} holds "
                        f"{_window_rows(counts, start, end)} rows{note}.")

    reachable = int(counts.sum())
    return (
        f"No window of any length reaches {cfg.min_baseline_rows} rows within "
        f"max_anchor_lookback_months={cfg.max_anchor_lookback_months}. The whole "
        f"table holds {reachable} rows, so either raise "
        f"max_anchor_lookback_months to cover more history, or lower "
        f"min_baseline_rows to match the data you actually have."
    )


def build_predict_input(features_pd: pd.DataFrame, cfg: TableConfig) -> pd.DataFrame:
    """Drop identifiers, helper columns and labels before model.predict()."""
    drop = set(cfg.exclude_from_features) | {EVENT_DATE_COL, cfg.label_col}
    return features_pd.drop(columns=[c for c in drop if c in features_pd.columns])


def align_to_signature(df: pd.DataFrame, model) -> pd.DataFrame:
    """
    Cast the scoring frame to the dtypes the model's signature declares.

    Training may convert columns before fitting (categoricals to str, decimals
    to float), and the signature records the result. The baseline reads the raw
    table, so a column the model saw as string can arrive as int16 and schema
    enforcement rejects the whole frame. Rather than restating the training
    conversions in config — where they would drift apart — take the dtypes from
    the model itself.

    Returns the frame with signature columns in signature order; a no-op when
    the model carries no signature.
    """
    try:
        schema = model.metadata.get_input_schema()
    except Exception as exc:
        logger.debug("No readable input schema: %s", exc)
        return df
    if schema is None:
        return df

    out = df.copy()
    recast, missing = [], []

    for spec in schema.inputs:
        name = spec.name
        if name not in out.columns:
            missing.append(name)
            continue

        want = spec.type.name if hasattr(spec.type, "name") else str(spec.type)
        before = str(out[name].dtype)
        try:
            if want == "string":
                # NaN must not become the literal "nan".
                out[name] = out[name].astype("object").where(out[name].notna(), None)
                out[name] = out[name].map(lambda v: v if v is None else str(v))
            elif want in ("integer", "long"):
                out[name] = pd.to_numeric(out[name], errors="coerce").astype(
                    "int32" if want == "integer" else "int64"
                )
            elif want in ("double", "float"):
                out[name] = pd.to_numeric(out[name], errors="coerce").astype(
                    "float64" if want == "double" else "float32"
                )
            elif want == "boolean":
                out[name] = out[name].astype(bool)
            elif want == "datetime":
                out[name] = pd.to_datetime(out[name], errors="coerce")
        except Exception as exc:
            raise ValueError(
                f"Cannot cast column '{name}' from {before} to the signature "
                f"type '{want}': {exc}"
            ) from exc

        if str(out[name].dtype) != before:
            recast.append(f"{name}: {before} -> {want}")

    if missing:
        raise ValueError(
            f"The model expects column(s) {missing} that are not in the scoring "
            f"frame. exclude_from_features in registry_config.py must match "
            f"drop_cols in the training config."
        )

    if recast:
        logger.info("Aligned %d column(s) to the model signature: %s",
                    len(recast), ", ".join(recast[:8])
                    + (" ..." if len(recast) > 8 else ""))

    ordered = [s.name for s in schema.inputs]
    extra = [c for c in out.columns if c not in ordered]
    if extra:
        logger.info("Dropping %d column(s) not in the signature: %s",
                    len(extra), extra[:8])
    return out[ordered]


def score_with_model(model, df: pd.DataFrame) -> Any:
    """
    Predict, handling each flavor's input expectations.

    LightGBM is a special case: the signature records its categorical columns
    as strings, but the booster refuses anything except pandas Categorical with
    the exact training levels — while pyfunc's schema enforcement refuses
    Categorical because the signature says string. The two cannot both be
    satisfied through pyfunc, so for LightGBM we restore the dtype and call the
    native model directly, skipping enforcement.
    """
    aligned = align_to_signature(df, model)

    cats = _lightgbm_pandas_categorical(model)
    if cats:
        schema = model.metadata.get_input_schema()
        aligned = _restore_lightgbm_categoricals(aligned, model, schema)
        native = getattr(getattr(model, "_model_impl", None), "lgb_model", None)
        if native is not None:
            logger.info("Scoring via the native LightGBM model "
                        "(pyfunc enforcement rejects Categorical).")
            return native.predict(aligned)
        logger.warning("LightGBM categories restored but the native model is "
                       "unreachable; falling back to pyfunc.")

    try:
        return model.predict(aligned)
    except Exception as exc:
        if "categor" not in str(exc).lower():
            raise
        raise RuntimeError(
            f"The model was trained on pandas Categorical columns, but its "
            f"signature records them as strings and the category levels were "
            f"not saved with the model, so they cannot be reconstructed "
            f"safely.\n"
            f"XGBoost encodes categories by position, so guessing the level "
            f"order would produce silently wrong predictions rather than an "
            f"error.\n"
            f"Fix in the TRAINING job — either log the mapping alongside the "
            f"model (mlflow.log_dict of {{column: [levels]}}) and apply it "
            f"here, or encode the categoricals to integers before fitting so "
            f"the signature is self-describing.\n"
            f"Original error: {exc}"
        ) from exc


def _lightgbm_pandas_categorical(model) -> Optional[List[List[Any]]]:
    """
    The category lists LightGBM recorded at fit time, or None.

    LightGBM stores them positionally, in the order the categorical columns
    appeared in the training frame, and refuses to predict unless the scoring
    frame presents the same number of category columns.
    """
    try:
        if "lightgbm" not in (model.metadata.flavors or {}):
            return None
    except Exception:
        return None

    impl = getattr(model, "_model_impl", None)
    candidate = getattr(impl, "lgb_model", impl)
    # sklearn wrapper keeps the Booster on .booster_
    booster = getattr(candidate, "booster_", candidate)
    cats = getattr(booster, "pandas_categorical", None)
    return cats or None


def _restore_lightgbm_categoricals(df: pd.DataFrame, model, schema) -> pd.DataFrame:
    """
    Re-apply pandas Categorical dtype for a LightGBM model.

    The signature records these columns as plain strings, so aligning to it
    leaves LightGBM seeing zero categorical columns against the N it stored —
    "train and valid dataset categorical_feature do not match". Restore the
    dtype using the model's own recorded categories so the levels match
    exactly, including order.
    """
    cats = _lightgbm_pandas_categorical(model)
    if not cats:
        return df

    string_cols = [s.name for s in schema.inputs
                   if (s.type.name if hasattr(s.type, "name") else str(s.type)) == "string"]

    if len(string_cols) != len(cats):
        raise ValueError(
            f"LightGBM recorded {len(cats)} categorical column(s) at training "
            f"time, but the signature has {len(string_cols)} string column(s) "
            f"{string_cols}. Cannot map categories positionally — the model and "
            f"the scoring frame disagree on which columns are categorical."
        )

    out = df.copy()
    unseen_report = []
    for name, categories in zip(string_cols, cats):
        values = out[name].astype("object")
        unseen = set(values.dropna().unique()) - set(categories)
        if unseen:
            unseen_report.append(f"{name}: {sorted(unseen)[:5]}")
        # Values outside the training categories become NaN, which is how
        # LightGBM itself treats an unseen level.
        out[name] = pd.Categorical(values, categories=categories)

    logger.info("Restored LightGBM categorical dtype on %d column(s): %s",
                len(string_cols), string_cols[:8])
    if unseen_report:
        logger.warning(
            "Values not seen during training (scored as NaN) — %s",
            "; ".join(unseen_report[:5]),
        )
    return out


def create_baseline_after_registration(
    spark: SparkSession,
    registration_result: dict,
    cfg: TableConfig,
    test_start_date: str,
    test_end_date: str,
    registry: Optional[RegistryConfig] = None,
) -> None:
    """Score the test window with the Champion, join actuals, overwrite the baseline."""
    registry = registry or RegistryConfig()
    # A duplicate registration is not a reason to skip the baseline: the run is
    # already a version, so a Champion exists, but the baseline table may not.
    # Scoring is idempotent — it overwrites — so refreshing is always safe.
    if registration_result.get("scenario") == "skipped_duplicate":
        logger.info(
            "Registration was skipped (run already registered); refreshing the "
            "baseline against the current Champion anyway."
        )

    model_name = registration_result["registered_model_name"]
    client = MlflowClient()
    mv = client.get_model_version_by_alias(model_name, registry.champion_alias)

    model_uri = f"models:/{model_name}@{registry.champion_alias}"
    try:
        model = mlflow.pyfunc.load_model(model_uri)
    except ModuleNotFoundError as exc:
        # Loading a flavor-specific model imports its library to rebuild the
        # estimator. The registration cluster often lacks what the training
        # cluster had.
        missing = getattr(exc, "name", None) or str(exc)
        raise RuntimeError(
            f"Cannot load the Champion: '{missing}' is not installed on this "
            f"cluster.\n"
            f"Install the model's own pinned dependencies:\n"
            f"    path = mlflow.pyfunc.get_model_dependencies('{model_uri}')\n"
            f"    %pip install -r $path\n"
            f"    dbutils.library.restartPython()\n"
            f"For a scheduled job, add them as cluster libraries instead. "
            f"Registration itself succeeded — only baseline scoring needs the "
            f"library, so --skip_baseline bypasses this."
        ) from exc

    logger.info("Baseline — model: %s | version: %s | window: %s -> %s",
                model_name, mv.version, test_start_date, test_end_date)

    features_df = with_event_date(spark.read.table(cfg.feature_table), cfg).filter(
        (F.col(EVENT_DATE_COL) >= F.to_date(F.lit(test_start_date)))
        & (F.col(EVENT_DATE_COL) <= F.to_date(F.lit(test_end_date)))
    )

    row_count = features_df.count()
    if row_count == 0:
        raise ValueError(
            f"No rows in '{cfg.feature_table}' between {test_start_date} and "
            f"{test_end_date}. Check date_kind and test_months."
        )
    logger.info("Feature rows in test window: %d", row_count)
    if row_count < cfg.min_baseline_rows:
        logger.warning(
            "Baseline will hold %d rows, below min_baseline_rows=%d. Drift "
            "comparisons against a reference this small are unreliable.",
            row_count, cfg.min_baseline_rows,
        )

    features_pd = features_df.toPandas()
    raw_preds = score_with_model(model, build_predict_input(features_pd, cfg))

    if isinstance(raw_preds, pd.DataFrame):
        pred_values = (
            raw_preds[cfg.prediction_col].values
            if cfg.prediction_col in raw_preds.columns
            else raw_preds.iloc[:, 0].values
        )
    else:
        pred_values = np.asarray(raw_preds).ravel()

    if len(pred_values) != len(features_pd):
        raise ValueError(
            f"Model returned {len(pred_values)} predictions for {len(features_pd)} rows."
        )

    features_pd["event_date"] = pd.to_datetime(features_pd[EVENT_DATE_COL])
    features_pd = features_pd.drop(columns=[EVENT_DATE_COL])
    features_pd["prediction_final"] = pred_values.astype(np.float32)
    features_pd["model_version"] = str(mv.version)
    features_pd["model_name"] = model_name
    features_pd["prediction_timestamp"] = datetime.utcnow()

    if cfg.actual_table and spark.catalog.tableExists(cfg.actual_table):
        join_keys = cfg.resolved_join_keys()
        actuals_sdf = spark.read.table(cfg.actual_table)
        require_columns(actuals_sdf, join_keys + [cfg.label_col], cfg.actual_table)

        total = actuals_sdf.count()
        distinct = actuals_sdf.select(*join_keys).distinct().count()
        if total != distinct:
            logger.warning(
                "'%s' has %d rows but only %d distinct %s — the join will fan out "
                "and inflate the baseline. Add columns to join_keys.",
                cfg.actual_table, total, distinct, join_keys,
            )

        actuals_pd = actuals_sdf.select(*join_keys, cfg.label_col).toPandas()
        before = len(features_pd)
        features_pd = features_pd.merge(actuals_pd, on=join_keys, how="left")
        if len(features_pd) != before:
            logger.warning("Join changed row count: %d -> %d.", before, len(features_pd))

        features_pd[cfg.label_col] = features_pd[cfg.label_col].astype(np.float32)
        matched = int(features_pd[cfg.label_col].notna().sum())
        logger.info("Actuals joined: %d / %d rows have '%s'",
                    matched, len(features_pd), cfg.label_col)
        if matched == 0:
            logger.warning(
                "Join on %s matched nothing — check key dtypes on both sides "
                "(a string/bigint mismatch joins to zero rows silently).", join_keys,
            )
    else:
        logger.warning("Actuals table '%s' not found — labels will be NULL.", cfg.actual_table)
        features_pd[cfg.label_col] = np.full(len(features_pd), np.nan, dtype=np.float32)

    (
        spark.createDataFrame(features_pd)
        .write.format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(cfg.baseline_table)
    )
    logger.info("Baseline written: '%s' | %d rows | model version %s",
                cfg.baseline_table, len(features_pd), mv.version)


# ──────────────────────────────────────────────────────────────────────────
# Entrypoint
# ──────────────────────────────────────────────────────────────────────────
def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pipeline", default=DEFAULT_PIPELINE,
                        choices=sorted(PIPELINES), help="Which PIPELINES entry to run.")
    parser.add_argument("--catalog", default=None, help="Override pipeline catalog.")
    parser.add_argument("--schema", default=None, help="Override pipeline schema.")
    parser.add_argument("--experiment_path", default=None,
                        help="Override experiment_path on experiment-sourced models.")
    parser.add_argument("--test_months", type=int, default=None)
    parser.add_argument("--skip_baseline", action="store_true")
    parser.add_argument("--validate_only", action="store_true",
                        help="Check the column contract and exit.")
    parser.add_argument("--fail_fast", action="store_true",
                        help="Raise the first exception instead of capturing it. "
                             "Use in notebooks, where a captured error shows "
                             "only as SystemExit: 1.")
    args, _ = parser.parse_known_args()
    return args


def run_pipeline(spark: SparkSession, pipeline: PipelineConfig,
                 skip_baseline: bool = False, fail_fast: bool = False) -> int:
    """Validate, register every model, refresh baselines. Returns a POSIX exit code."""
    cfg = pipeline.tables
    validate_table_config(spark, cfg)
    test_start_date, test_end_date = get_test_ranges(spark, cfg)

    input_example = None
    if any(s.source == "file" for s in pipeline.models.values()):
        sample = with_event_date(spark.read.table(cfg.feature_table), cfg).limit(5).toPandas()
        input_example = build_predict_input(sample, cfg)

    results = run_all_registrations(
        pipeline.models,
        catalog=pipeline.catalog,
        schema=pipeline.schema,
        input_example=input_example,
        fail_fast=fail_fast,
        registry=pipeline.registry,
    )

    failures: List[str] = []
    for key, res in results.items():
        logger.info("Result for %s: %s", key, res)
        if not isinstance(res, dict) or "error" in res:
            failures.append(f"{key}: registration — {res.get('error', 'unknown')}")
            continue
        if skip_baseline or not pipeline.models[key].create_baseline:
            continue
        try:
            create_baseline_after_registration(
                spark=spark,
                registration_result=res,
                cfg=cfg,
                test_start_date=test_start_date,
                test_end_date=test_end_date,
                registry=pipeline.registry,
            )
        except Exception as exc:
            if fail_fast:
                raise
            failures.append(f"{key}: baseline — {exc}")
            logger.error("Baseline creation failed for '%s': %s", key, exc, exc_info=True)

    # Spell out why the exit code is non-zero — in a notebook the caller only
    # sees "SystemExit: 1" otherwise.
    logger.info("=" * 70)
    if failures:
        logger.error("Pipeline '%s' finished with %d failure(s):", pipeline.name, len(failures))
        for line in failures:
            logger.error("  - %s", line)
        logger.error("Re-run with fail_fast=True to get the full traceback.")
        return 1

    logger.info("Pipeline '%s' completed successfully.", pipeline.name)
    return 0


def main() -> int:
    args = parse_args()
    spark = SparkSession.builder.getOrCreate()
    mlflow.set_registry_uri("databricks-uc")

    pipeline = get_pipeline(args.pipeline)
    logger.info("Pipeline: %s", pipeline.name)

    if args.catalog:
        pipeline.catalog = args.catalog
    if args.schema:
        pipeline.schema = args.schema
    if args.test_months is not None:
        pipeline.tables.test_months = args.test_months
    if args.experiment_path:
        pipeline.experiment_path = args.experiment_path
        for spec in pipeline.models.values():
            if spec.source == "experiment":
                spec.experiment_path = args.experiment_path

    if args.validate_only:
        validate_table_config(spark, pipeline.tables)
        start, end = get_test_ranges(spark, pipeline.tables)
        logger.info("Validation passed. Test window: %s -> %s", start, end)
        return 0

    return run_pipeline(
        spark,
        pipeline,
        skip_baseline=args.skip_baseline,
        fail_fast=args.fail_fast,
    )


if __name__ == "__main__":
    sys.exit(main())
