"""
model_training.py
-----------------
Optuna hyperparameter search with rolling time-based validation, logged to
MLflow. Contains no table names, column names or tuning literals — all of
that lives in config.py.

Run as a script:
    python model_training.py --config total_cost
    python model_training.py --config total_cost --models xgboost --n_trials 5
    python model_training.py --config delay_days --dry_run

Run in a notebook:
    from config import get_training_config
    from model_training import run_training

    cfg = get_training_config("total_cost")
    results = run_training(spark, cfg)

Structure of an MLflow run:
    parent run (run_name=<model>)        <- the refit model is logged HERE
      ├── trial_0 (nested)               <- metrics only, no model
      ├── trial_1 (nested)
      └── ...
Metrics on the parent: best_<metric>_<split_name> and
best_weighted_mean_<primary_metric> — the latter is a FIXED key, which is what
model registration should select on.
"""
from __future__ import annotations

import argparse
import logging
import sys
import tempfile
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

import mlflow
from mlflow.models import infer_signature
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from src.settings.mlops_settings import (
    DEFAULT_USE_CASE as DEFAULT_CONFIG,
    USE_CASES as TRAINING_CONFIGS,
    DataConfig,
    SearchConfig,
    SplitConfig,
    TrainingConfig,
    training_config as get_training_config,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)
logging.getLogger("mlflow.tracking.context.registry").setLevel(logging.ERROR)


# ──────────────────────────────────────────────────────────────────────────
# Model registry — imports are lazy so a missing library only breaks the
# model that needs it, not the whole module.
# ──────────────────────────────────────────────────────────────────────────
def _load_estimator(model_name: str, task: str = "regression"):
    """Estimator class for a model name, picked by task."""
    classify = task == "classification"

    if model_name == "xgboost":
        from xgboost import XGBClassifier, XGBRegressor
        return XGBClassifier if classify else XGBRegressor
    if model_name == "lightgbm":
        from lightgbm import LGBMClassifier, LGBMRegressor
        return LGBMClassifier if classify else LGBMRegressor
    if model_name == "catboost":
        from catboost import CatBoostClassifier, CatBoostRegressor
        return CatBoostClassifier if classify else CatBoostRegressor
    if model_name == "random_forest":
        from sklearn.ensemble import (RandomForestClassifier,
                                      RandomForestRegressor)
        return RandomForestClassifier if classify else RandomForestRegressor
    if model_name == "extra_trees":
        from sklearn.ensemble import ExtraTreesClassifier, ExtraTreesRegressor
        return ExtraTreesClassifier if classify else ExtraTreesRegressor
    if model_name == "hist_gradient_boosting":
        from sklearn.ensemble import (HistGradientBoostingClassifier,
                                      HistGradientBoostingRegressor)
        return (HistGradientBoostingClassifier if classify
                else HistGradientBoostingRegressor)
    if model_name == "logistic_regression":
        if not classify:
            raise ValueError("logistic_regression supports classification only.")
        from sklearn.linear_model import LogisticRegression
        return LogisticRegression
    raise ValueError(
        f"Unknown model '{model_name}'. Add it to _load_estimator and "
        f"_model_log_fn in model_training.py, plus a search space in config.py."
    )


def _model_log_fn(model_name: str):
    """MLflow flavor used to log each model type."""
    if model_name == "xgboost":
        import mlflow.xgboost
        return mlflow.xgboost.log_model
    if model_name == "lightgbm":
        import mlflow.lightgbm
        return mlflow.lightgbm.log_model
    if model_name == "catboost":
        import mlflow.catboost
        return mlflow.catboost.log_model
    import mlflow.sklearn
    return mlflow.sklearn.log_model


def _disable_autolog() -> None:
    """
    Turn off autologging so the one explicit log_model stays the only model.

    Each flavor is attempted independently — importing mlflow.xgboost pulls in
    xgboost, so a cluster without it would otherwise fail here even when
    training a model that does not need it.
    """
    for flavor in ("xgboost", "lightgbm", "catboost", "sklearn"):
        try:
            getattr(__import__(f"mlflow.{flavor}", fromlist=[flavor]), "autolog")(
                disable=True
            )
        except Exception:
            logger.debug("Autolog not disabled for %s (library absent).", flavor)


def _log_model_compat(log_fn, model, artifact_path: str, signature=None):
    """Tolerate both the old (artifact_path=) and new (name=) signatures."""
    kwargs = {"signature": signature} if signature is not None else {}
    try:
        return log_fn(model, name=artifact_path, **kwargs)
    except TypeError:
        return log_fn(model, artifact_path=artifact_path, **kwargs)


# ──────────────────────────────────────────────────────────────────────────
# Metrics
# ──────────────────────────────────────────────────────────────────────────
def compute_regression_metrics(y_true, y_pred,
                               metric_names: Sequence[str]) -> Dict[str, float]:
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    residual = y_true - y_pred

    out: Dict[str, float] = {}

    if "rmse" in metric_names:
        out["rmse"] = float(np.sqrt(mean_squared_error(y_true, y_pred)))
    if "mae" in metric_names:
        out["mae"] = float(mean_absolute_error(y_true, y_pred))
    if "r2" in metric_names:
        out["r2"] = float(r2_score(y_true, y_pred))
    if "mape" in metric_names:
        nonzero = y_true != 0
        out["mape"] = (
            float(np.mean(np.abs(residual[nonzero] / y_true[nonzero])) * 100)
            if nonzero.any() else float("nan")
        )
    if "wmape" in metric_names:
        total = np.sum(np.abs(y_true))
        out["wmape"] = (
            float(np.sum(np.abs(residual)) / total * 100) if total > 0 else float("nan")
        )
    if "smape" in metric_names:
        denom = np.abs(y_true) + np.abs(y_pred)
        mask = denom != 0
        out["smape"] = (
            float(np.mean(2 * np.abs(residual[mask]) / denom[mask]) * 100)
            if mask.any() else float("nan")
        )
    return out


def compute_classification_metrics(y_true, y_pred, y_proba,
                                   metric_names: Sequence[str]) -> Dict[str, float]:
    """
    Classification metrics.

    macro averaging weights every class equally, so a rare "High risk" class
    counts as much as a common "Low". With imbalanced classes that is usually
    what you want — plain accuracy can be high while the class you actually
    care about is never predicted.
    """
    from sklearn.metrics import (accuracy_score, balanced_accuracy_score,
                                 f1_score, log_loss, precision_score,
                                 recall_score, roc_auc_score)

    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    out: Dict[str, float] = {}

    if "accuracy" in metric_names:
        out["accuracy"] = float(accuracy_score(y_true, y_pred))
    if "balanced_accuracy" in metric_names:
        out["balanced_accuracy"] = float(balanced_accuracy_score(y_true, y_pred))
    if "f1_macro" in metric_names:
        out["f1_macro"] = float(f1_score(y_true, y_pred, average="macro",
                                         zero_division=0))
    if "f1_weighted" in metric_names:
        out["f1_weighted"] = float(f1_score(y_true, y_pred, average="weighted",
                                            zero_division=0))
    if "precision_macro" in metric_names:
        out["precision_macro"] = float(precision_score(y_true, y_pred,
                                                       average="macro",
                                                       zero_division=0))
    if "recall_macro" in metric_names:
        out["recall_macro"] = float(recall_score(y_true, y_pred, average="macro",
                                                 zero_division=0))

    # Probability metrics need every class present in the window, which a
    # short validation slice cannot guarantee.
    if y_proba is not None:
        classes = np.unique(y_true)
        if "roc_auc_ovr" in metric_names:
            try:
                out["roc_auc_ovr"] = float(
                    roc_auc_score(y_true, y_proba, multi_class="ovr",
                                  average="macro"))
            except Exception as exc:
                logger.debug("roc_auc_ovr unavailable: %s", exc)
                out["roc_auc_ovr"] = float("nan")
        if "log_loss" in metric_names:
            try:
                out["log_loss"] = float(log_loss(y_true, y_proba,
                                                 labels=list(range(y_proba.shape[1]))))
            except Exception as exc:
                logger.debug("log_loss unavailable: %s", exc)
                out["log_loss"] = float("nan")
    return out


def compute_metrics(y_true, y_pred, y_proba, metric_names: Sequence[str],
                    task: str) -> Dict[str, float]:
    if task == "classification":
        return compute_classification_metrics(y_true, y_pred, y_proba, metric_names)
    return compute_regression_metrics(y_true, y_pred, metric_names)


# ──────────────────────────────────────────────────────────────────────────
# Data loading
# ──────────────────────────────────────────────────────────────────────────
def _build_event_date(df: pd.DataFrame, data: DataConfig) -> pd.Series:
    """Resolve the event date from either a real column or three int parts."""
    if data.date_from == "column":
        if data.date_column not in df.columns:
            raise ValueError(
                f"date_column '{data.date_column}' not found in "
                f"'{data.feature_table}'. Available: {sorted(df.columns)}"
            )
        return pd.to_datetime(df[data.date_column], errors="coerce")

    y_col, m_col, d_col = data.date_parts
    missing = [c for c in (y_col, m_col, d_col) if c not in df.columns]
    if missing:
        raise ValueError(
            f"Date part column(s) {missing} not found in '{data.feature_table}'. "
            f"If this table has a real date column instead, set "
            f"date_from='column' and date_column=... in config.py. "
            f"Available: {sorted(df.columns)}"
        )
    return pd.to_datetime(
        df[[y_col, m_col, d_col]].rename(
            columns={y_col: "year", m_col: "month", d_col: "day"}
        ),
        errors="coerce",
    )


def load_training_frame(spark, data: DataConfig) -> pd.DataFrame:
    """Load features, attach the label, build the event date, drop sentinels."""
    features_sdf = spark.read.table(data.feature_table)

    if data.target_table:
        target_sdf = spark.read.table(data.target_table)

        missing = [c for c in data.join_keys if c not in features_sdf.columns]
        if missing:
            raise ValueError(
                f"'{data.feature_table}' is missing join key(s) {missing}. "
                f"Available: {sorted(features_sdf.columns)}"
            )
        missing = [c for c in data.join_keys + [data.source_label_col]
                   if c not in target_sdf.columns]
        if missing:
            raise ValueError(
                f"'{data.target_table}' is missing {missing}. "
                f"Available: {sorted(target_sdf.columns)}"
            )

        # Keep only the keys and the label from the target side. Any other
        # shared column (VENDORID, DOCDATE, ...) would otherwise appear TWICE
        # in the joined frame, and df["DOCDATE"] would then return a DataFrame
        # rather than a Series — which breaks pd.to_datetime and anything else
        # addressing that column by name.
        overlap = [
            c for c in target_sdf.columns
            if c in features_sdf.columns and c not in data.join_keys
        ]
        if overlap:
            logger.info(
                "Columns %s exist on both sides; keeping the feature-table "
                "copy and taking only %s from '%s'.",
                overlap, [data.source_label_col], data.target_table,
            )
        target_sdf = target_sdf.select(*data.join_keys, data.source_label_col)

        # The label name itself may also collide with a feature column.
        if data.target_col in features_sdf.columns:
            logger.warning(
                "'%s' already has a '%s' column; dropping it in favour of "
                "'%s' from the target table.",
                data.feature_table, data.target_col, data.source_label_col,
            )
            features_sdf = features_sdf.drop(data.target_col)

        merged = (
            features_sdf.join(target_sdf, on=data.join_keys, how="inner")
            .withColumnRenamed(data.source_label_col, data.target_col)
            .toPandas()
        )

        dupes = merged.columns[merged.columns.duplicated()].tolist()
        if dupes:
            raise ValueError(
                f"Joined frame still has duplicate column(s) {dupes}. "
                f"Add them to join_keys if they are part of the grain."
            )
        if len(merged) == 0:
            raise ValueError(
                f"No rows after joining '{data.feature_table}' to "
                f"'{data.target_table}' on {data.join_keys}. Check that the key "
                f"dtypes match on both sides and that the tables overlap."
            )
    else:
        if data.target_col not in features_sdf.columns:
            raise ValueError(
                f"target_col '{data.target_col}' not in '{data.feature_table}' "
                f"and no target_table configured. Available: "
                f"{sorted(features_sdf.columns)}"
            )
        merged = features_sdf.toPandas()
        logger.info("Label '%s' taken from the feature table (no join).",
                    data.target_col)

    for col in list(data.numeric_cols) + [data.target_col]:
        if col in merged.columns:
            merged[col] = pd.to_numeric(merged[col], errors="coerce")

    merged[data.date_col] = _build_event_date(merged, data)

    n_bad_date = int(merged[data.date_col].isna().sum())
    if n_bad_date:
        logger.warning("%d row(s) have an unparseable event date — dropped.", n_bad_date)

    before = len(merged)
    merged = merged.loc[
        merged[data.date_col] >= pd.Timestamp(data.min_valid_date)
    ].reset_index(drop=True)
    logger.info(
        "Loaded %d rows; dropped %d outside/invalid on %s (min_valid_date=%s).",
        len(merged), before - len(merged),
        ", ".join(data.date_source_columns()), data.min_valid_date,
    )
    if len(merged) == 0:
        raise ValueError(
            f"Every row fell before min_valid_date={data.min_valid_date} or had "
            f"an unparseable date. Check {data.date_source_columns()}."
        )

    n_missing_label = int(merged[data.target_col].isna().sum())
    if n_missing_label:
        logger.warning("Dropping %d row(s) with a null '%s'.",
                       n_missing_label, data.target_col)
        merged = merged.loc[merged[data.target_col].notna()].reset_index(drop=True)

    return merged


def resolve_feature_cols(df: pd.DataFrame, data: DataConfig) -> List[str]:
    """
    Feature columns, with a dtype check.

    Gradient-boosting libraries reject datetime and plain object columns. The
    failure would otherwise surface deep inside fit() as a dtype error naming
    no column, so catch it here and say exactly which ones to handle.
    """
    drop = set(data.all_drop_cols())
    features = [c for c in df.columns if c not in drop]
    if not features:
        raise ValueError(f"No feature columns left after dropping {sorted(drop)}.")

    missing_cats = [c for c in data.cat_cols if c not in df.columns]
    if missing_cats:
        logger.warning("cat_cols lists %s, absent from the table — ignoring.",
                       missing_cats)

    report = data.feature_dtype_report(df)
    if report["datetime"] or report["object"]:
        raise ValueError(
            f"These columns in '{data.feature_table}' cannot be consumed by "
            f"the model as-is:\n"
            f"  datetime : {report['datetime']}\n"
            f"  text     : {report['object']}\n"
            f"Either the feature table is STALE — a feature-store merge cannot "
            f"drop columns, so rebuilding after a config change leaves the old "
            f"ones behind; drop the table and re-run the features stage — or "
            f"these columns genuinely need handling: add them to drop_cols, "
            f"numeric_cols, or one_hot in feature_config.py."
        )

    logger.info("Using %d features, %d of them categorical.",
                len(features), len([c for c in data.cat_cols if c in df.columns]))
    return features


# ──────────────────────────────────────────────────────────────────────────
# Rolling time splits
# ──────────────────────────────────────────────────────────────────────────
def generate_time_splits(dates: pd.Series, split: SplitConfig) -> List[Dict[str, Any]]:
    """Rolling train/validation windows ending progressively closer to max date."""
    max_date = pd.to_datetime(dates.max())
    min_date = pd.to_datetime(dates.min())

    weights = np.linspace(split.weight_low, split.weight_high, split.n_splits)
    weights = weights / weights.sum()

    splits = []
    for i in range(split.n_splits):
        offset = (split.n_splits - 1 - i) * split.step_weeks
        test_end = max_date - pd.Timedelta(weeks=offset) + pd.Timedelta(days=1)
        test_start = test_end - pd.Timedelta(weeks=split.val_weeks)
        splits.append({
            "name": f"val_{test_start.date()}_{test_end.date()}",
            "train_start": min_date,
            "train_end": test_start,
            "test_start": test_start,
            "test_end": test_end,
            "weight": float(weights[i]),
        })
    return splits


def pick_split_anchor(dates: pd.Series, split: SplitConfig) -> Tuple[pd.Timestamp, List[int]]:
    """
    Most recent anchor where every validation window holds enough rows.

    A sparse tail would otherwise give 3-5 row validation sets and metrics
    that mean nothing, so walk backwards until the windows are populated.
    """
    series = pd.to_datetime(pd.Series(dates)).sort_values()
    for anchor in series.drop_duplicates().iloc[::-1]:
        counts = []
        for i in range(split.n_splits):
            test_end = (
                anchor
                - pd.Timedelta(weeks=(split.n_splits - 1 - i) * split.step_weeks)
                + pd.Timedelta(days=1)
            )
            test_start = test_end - pd.Timedelta(weeks=split.val_weeks)
            counts.append(int(((series >= test_start) & (series < test_end)).sum()))
        if min(counts) >= split.min_test_rows:
            return anchor, counts
    raise ValueError(
        f"No anchor date yields >= {split.min_test_rows} rows in every validation "
        f"window (n_splits={split.n_splits}, val_weeks={split.val_weeks}, "
        f"step_weeks={split.step_weeks}). Widen val_weeks or lower min_test_rows."
    )


def build_split(split_cfg: Dict[str, Any], df: pd.DataFrame,
                feature_cols: List[str], target_col: str, date_col: str):
    train_mask = (df[date_col] >= split_cfg["train_start"]) & (df[date_col] < split_cfg["train_end"])
    test_mask = (df[date_col] >= split_cfg["test_start"]) & (df[date_col] < split_cfg["test_end"])

    X_train = df.loc[train_mask, feature_cols].reset_index(drop=True)
    y_train = df.loc[train_mask, target_col].reset_index(drop=True)
    X_test = df.loc[test_mask, feature_cols].reset_index(drop=True)
    y_test = df.loc[test_mask, target_col].reset_index(drop=True)

    if len(y_train) == 0 or len(y_test) == 0:
        raise ValueError(
            f"Split '{split_cfg['name']}' has an empty train or test set "
            f"(n_train={len(y_train)}, n_test={len(y_test)}). Data spans "
            f"[{df[date_col].min()}, {df[date_col].max()}] — the configured "
            f"window falls outside it, or there is a gap."
        )
    return X_train, y_train, X_test, y_test


def get_model_data(model_name: str, X_train: pd.DataFrame, X_test: pd.DataFrame,
                   cat_cols: Sequence[str]):
    """Categoricals go in natively; each library wants a different form."""
    X_train, X_test = X_train.copy(), X_test.copy()
    if not cat_cols:
        return X_train, X_test

    if model_name == "catboost":
        for col in cat_cols:
            X_train[col] = X_train[col].astype(str)
            X_test[col] = X_test[col].astype(str)
        return X_train, X_test

    for col in cat_cols:
        categories = pd.Index(
            pd.concat([X_train[col], X_test[col]]).astype(str).unique()
        )
        X_train[col] = pd.Categorical(X_train[col].astype(str), categories=categories)
        X_test[col] = pd.Categorical(X_test[col].astype(str), categories=categories)
    return X_train, X_test


# ──────────────────────────────────────────────────────────────────────────
# Params and models
# ──────────────────────────────────────────────────────────────────────────
def get_trial_params(trial, space: Dict[str, Any]) -> Dict[str, Any]:
    params: Dict[str, Any] = {}
    for name, value in space.items():
        if not isinstance(value, tuple):
            params[name] = value                      # fixed
            continue
        kind = value[0]
        if kind == "int":
            params[name] = trial.suggest_int(name, value[1], value[2])
        elif kind == "float":
            log = value[3] if len(value) > 3 else False
            params[name] = trial.suggest_float(name, value[1], value[2], log=log)
        elif kind == "categorical":
            params[name] = trial.suggest_categorical(name, value[1])
        else:
            raise ValueError(f"Unknown search-space type '{kind}' for '{name}'.")
    return params


def merge_fixed_params(space: Dict[str, Any], tuned: Dict[str, Any]) -> Dict[str, Any]:
    """study.best_params holds tuned values only — add the fixed ones back."""
    merged = dict(tuned)
    for name, value in space.items():
        if not isinstance(value, tuple):
            merged[name] = value
    return merged


def build_model(model_name: str, params: Dict[str, Any], cat_cols: Sequence[str],
                task: str = "regression"):
    params = dict(params)
    if model_name == "catboost" and cat_cols:
        params["cat_features"] = list(cat_cols)
    estimator = _load_estimator(model_name, task)(**params)
    if model_name == "logistic_regression":
        # No native NaN support (first line per item has no history), and
        # saga needs scaled inputs. The pipeline is logged and served whole.
        from sklearn.impute import SimpleImputer
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler
        return make_pipeline(SimpleImputer(strategy="median"),
                             StandardScaler(), estimator)
    return estimator


# ──────────────────────────────────────────────────────────────────────────
# Evaluation
# ──────────────────────────────────────────────────────────────────────────
def evaluate_split(params, model_name, entry, cat_cols, metric_names,
                   task: str = "regression"):
    model = build_model(model_name, params, cat_cols, task)
    model.fit(entry["X_train_model"], entry["y_train"])
    y_pred = model.predict(entry["X_test_model"])

    # Probabilities drive log_loss and roc_auc; not every estimator exposes them.
    y_proba = None
    if task == "classification" and hasattr(model, "predict_proba"):
        try:
            y_proba = model.predict_proba(entry["X_test_model"])
        except Exception as exc:
            logger.debug("predict_proba unavailable for %s: %s", model_name, exc)

    # Classifiers return class labels as arrays that may be 2-D (CatBoost).
    y_pred = np.asarray(y_pred).ravel()

    metrics = compute_metrics(entry["y_test"], y_pred, y_proba, metric_names, task)

    row = {
        "split_name": entry["cfg"]["name"],
        "train_start": str(entry["cfg"]["train_start"]),
        "train_end": str(entry["cfg"]["train_end"]),
        "test_start": str(entry["cfg"]["test_start"]),
        "test_end": str(entry["cfg"]["test_end"]),
        "weight": entry["cfg"]["weight"],
        "n_train": len(entry["y_train"]),
        "n_test": len(entry["y_test"]),
        **metrics,
    }
    return row, model, y_pred


def evaluate_across_splits(params, model_name, split_data, cat_cols, search: SearchConfig):
    rows, models, preds = [], [], []
    for entry in split_data:
        row, model, y_pred = evaluate_split(
            params, model_name, entry, cat_cols, search.metric_names, search.task
        )
        rows.append(row)
        models.append(model)
        preds.append(y_pred)

    weights = np.array([r["weight"] for r in rows], dtype=float)
    scores = np.array([r[search.primary_metric] for r in rows], dtype=float)
    weighted = float(np.average(scores, weights=weights))

    # Last split is the most recent and highest-weighted.
    return (rows, weighted, models[-1],
            split_data[-1]["X_test_model"], split_data[-1]["y_test"], preds[-1])


# ──────────────────────────────────────────────────────────────────────────
# Artifact logging
# ──────────────────────────────────────────────────────────────────────────
def log_feature_importance(model, model_name, feature_cols, artifact_name, top_n):
    import matplotlib.pyplot as plt

    if hasattr(model, "steps"):          # sklearn Pipeline: use the final estimator
        model = model.steps[-1][1]

    if model_name == "catboost":
        importances = model.get_feature_importance()
    elif hasattr(model, "feature_importances_"):
        importances = model.feature_importances_
    elif hasattr(model, "coef_"):
        # Linear models: mean absolute coefficient across classes.
        importances = np.abs(np.atleast_2d(model.coef_)).mean(axis=0)
    else:
        # e.g. HistGradientBoosting exposes no native importance.
        logger.info("No native feature importance for %s; skipped.", model_name)
        return None

    fi_df = (
        pd.DataFrame({"feature": feature_cols, "importance": importances})
        .sort_values("importance", ascending=False)
    )
    fi_path = f"{tempfile.gettempdir()}/{artifact_name}_feature_importance.csv"
    fi_df.to_csv(fi_path, index=False)
    mlflow.log_artifact(fi_path, artifact_path="feature_importance")

    top = fi_df.head(top_n)
    fig, ax = plt.subplots(figsize=(8, max(4, len(top) * 0.3)))
    ax.barh(top["feature"][::-1], top["importance"][::-1])
    ax.set_title(f"Feature Importance — {artifact_name}")
    ax.set_xlabel("Importance")
    mlflow.log_figure(fig, f"feature_importance/{artifact_name}.png")
    plt.close(fig)
    return fi_df


def log_predictions(y_true, y_pred, artifact_name, index_df=None):
    pred_df = pd.DataFrame({
        "y_true": np.asarray(y_true, dtype=float),
        "y_pred": np.asarray(y_pred, dtype=float),
    })
    pred_df["residual"] = pred_df["y_true"] - pred_df["y_pred"]
    if index_df is not None and len(index_df) == len(pred_df):
        pred_df = pd.concat([index_df.reset_index(drop=True), pred_df], axis=1)

    path = f"{tempfile.gettempdir()}/{artifact_name}_predictions.csv"
    pred_df.to_csv(path, index=False)
    mlflow.log_artifact(path, artifact_path="predictions")


# ──────────────────────────────────────────────────────────────────────────
# Optuna objective
# ──────────────────────────────────────────────────────────────────────────
def make_objective(cfg: TrainingConfig, model_name: str, split_data, feature_cols):
    import optuna

    search = cfg.search
    space = cfg.search_space[model_name]
    cat_cols = cfg.data.cat_cols

    def objective(trial):
        params = get_trial_params(trial, space)
        rows = []

        with mlflow.start_run(run_name=f"trial_{trial.number}", nested=True):
            mlflow.log_param("model_name", model_name)
            mlflow.log_params(params)
            mlflow.log_dict({"features": feature_cols}, "features.json")

            for step, entry in enumerate(split_data):
                row, _, _ = evaluate_split(
                    params, model_name, entry, cat_cols, search.metric_names,
                    search.task
                )
                rows.append(row)
                for metric_name in search.metric_names:
                    mlflow.log_metric(f"{metric_name}_{row['split_name']}", row[metric_name])

                trial.report(row[search.primary_metric], step=step)
                if trial.should_prune():
                    mlflow.set_tag("trial_status", "pruned")
                    raise optuna.TrialPruned()

            weights = np.array([r["weight"] for r in rows], dtype=float)
            scores = np.array([r[search.primary_metric] for r in rows], dtype=float)
            weighted = float(np.average(scores, weights=weights))
            mlflow.log_metric(f"weighted_mean_{search.primary_metric}", weighted)

            csv_path = (
                f"{tempfile.gettempdir()}/{model_name}_trial_{trial.number}_split_metrics.csv"
            )
            pd.DataFrame(rows).to_csv(csv_path, index=False)
            mlflow.log_artifact(csv_path, artifact_path="split_metrics")
            mlflow.set_tag("trial_status", "completed")

        return weighted

    return objective


# ──────────────────────────────────────────────────────────────────────────
# Train one model family
# ──────────────────────────────────────────────────────────────────────────
def train_model(cfg: TrainingConfig, model_name: str, df: pd.DataFrame,
                feature_cols: List[str], split_dates: pd.Series) -> Dict[str, Any]:
    import optuna

    data, split, search, mlf = cfg.data, cfg.split, cfg.search, cfg.mlflow

    with mlflow.start_run(run_name=model_name):
        mlflow.log_param("model_name", model_name)
        mlflow.set_tag("model_name", model_name)
        mlflow.set_tag("stage", "hyperparameter_search")
        mlflow.set_tag("config_name", cfg.name)
        mlflow.log_dict({"features": feature_cols}, "features.json")

        fl_path = f"{tempfile.gettempdir()}/{model_name}_feature_list.csv"
        pd.DataFrame({"feature": feature_cols}).to_csv(fl_path, index=False)
        mlflow.log_artifact(fl_path, artifact_path="metadata")

        time_splits = generate_time_splits(split_dates, split)
        split_data = []
        for split_cfg in time_splits:
            X_train, y_train, X_test, y_test = build_split(
                split_cfg, df, feature_cols, data.target_col, data.date_col
            )
            if len(y_test) < split.min_test_rows:
                raise ValueError(
                    f"Split '{split_cfg['name']}' has only {len(y_test)} test rows "
                    f"(minimum {split.min_test_rows}) — metrics would not be "
                    f"meaningful. Check the split anchor selection."
                )
            X_train_model, X_test_model = get_model_data(
                model_name, X_train, X_test, data.cat_cols
            )
            split_data.append({
                "cfg": split_cfg,
                "X_train_model": X_train_model, "y_train": y_train,
                "X_test_model": X_test_model, "y_test": y_test,
            })
            logger.info("[%s/%s] train n=%d, test n=%d",
                        model_name, split_cfg["name"], len(y_train), len(y_test))

        _disable_autolog()

        study = optuna.create_study(
            direction=search.direction(),          # derived, not hardcoded
            study_name=f"{model_name}_study",
            pruner=optuna.pruners.MedianPruner(
                n_startup_trials=search.pruner_startup_trials,
                n_warmup_steps=search.pruner_warmup_steps,
                interval_steps=search.pruner_interval_steps,
            ),
        )
        study.optimize(
            make_objective(cfg, model_name, split_data, feature_cols),
            n_trials=search.n_trials,
        )

        # ---- Refit the winning combination once, log it on the parent run ----
        best_params = merge_fixed_params(cfg.search_space[model_name], study.best_params)
        best_rows, best_weighted, best_model, best_X_test, best_y_test, best_y_pred = (
            evaluate_across_splits(best_params, model_name, split_data, data.cat_cols, search)
        )

        mlflow.log_params({f"best_{k}": v for k, v in study.best_params.items()})
        for row in best_rows:
            for metric_name in search.metric_names:
                mlflow.log_metric(f"best_{metric_name}_{row['split_name']}", row[metric_name])
        mlflow.log_metric(f"best_weighted_mean_{search.primary_metric}", best_weighted)

        best_csv = f"{tempfile.gettempdir()}/{model_name}_best_split_metrics.csv"
        pd.DataFrame(best_rows).to_csv(best_csv, index=False)
        mlflow.log_artifact(best_csv, artifact_path="split_metrics")

        if mlf.log_feature_importance:
            log_feature_importance(best_model, model_name, feature_cols,
                                   f"{model_name}_best", mlf.top_n_importance)

        final_cfg = time_splits[-1]
        if mlf.log_predictions:
            id_df = None
            if data.id_cols:
                id_df = df.loc[
                    (df[data.date_col] >= final_cfg["test_start"])
                    & (df[data.date_col] < final_cfg["test_end"]),
                    data.id_cols,
                ].reset_index(drop=True)
            log_predictions(best_y_test, best_y_pred, f"{model_name}_best", id_df)

        if mlf.log_datasets:
            final_entry = split_data[-1]
            train_ds = mlflow.data.from_pandas(
                pd.concat(
                    [final_entry["X_train_model"],
                     final_entry["y_train"].rename(data.target_col)], axis=1
                ),
                name=f"{model_name}_train_{final_cfg['name']}",
            )
            val_ds = mlflow.data.from_pandas(
                pd.concat(
                    [final_entry["X_test_model"],
                     final_entry["y_test"].rename(data.target_col)], axis=1
                ),
                name=f"{model_name}_val_{final_cfg['name']}",
            )
            mlflow.log_input(train_ds, context="training")
            mlflow.log_input(val_ds, context="validation")

            mlflow.log_dict({
                "n_train": int(len(split_data[-1]["y_train"])),
                "n_val": int(len(split_data[-1]["y_test"])),
                "train_start": str(final_cfg["train_start"]),
                "train_end": str(final_cfg["train_end"]),
                "test_start": str(final_cfg["test_start"]),
                "test_end": str(final_cfg["test_end"]),
                "n_features": len(feature_cols),
                "categorical_features": list(data.cat_cols),
                "target": data.target_col,
            }, "dataset_metadata.json")

        signature = infer_signature(best_X_test, best_model.predict(best_X_test))
        _log_model_compat(
            _model_log_fn(model_name), best_model, mlf.model_artifact_path, signature
        )

        mlflow.set_tag("best_trial_number", study.best_trial.number)
        mlflow.set_tag("n_trials", search.n_trials)
        mlflow.set_tag("primary_metric", search.primary_metric)
        mlflow.set_tag("stage", "best_model_refit")

        run_id = mlflow.active_run().info.run_id
        logger.info("[%s] best weighted mean %s: %.4f",
                    model_name, search.primary_metric, best_weighted)
        logger.info("[%s] best params: %s", model_name, study.best_params)

        return {
            "model_name": model_name,
            "run_id": run_id,
            "best_params": study.best_params,
            f"best_weighted_mean_{search.primary_metric}": best_weighted,
        }


# ──────────────────────────────────────────────────────────────────────────
# Orchestration
# ──────────────────────────────────────────────────────────────────────────
def run_training(spark, cfg: TrainingConfig, dry_run: bool = False,
                 fail_fast: bool = False) -> Dict[str, Any]:
    cfg.validate()
    logger.info("Config: %s | models: %s | metric: %s (%s)",
                cfg.name, cfg.search.models, cfg.search.primary_metric,
                cfg.search.direction())

    df = load_training_frame(spark, cfg.data)
    feature_cols = resolve_feature_cols(df, cfg.data)
    logger.info("Features (%d): %s", len(feature_cols), feature_cols)

    anchor, counts = pick_split_anchor(df[cfg.data.date_col], cfg.split)
    logger.info("Split anchor=%s (validation row counts %s)", anchor.date(), counts)

    # generate_time_splits anchors on the max of what it is given, so clip to
    # the chosen anchor rather than the sparse absolute max.
    split_dates = df.loc[df[cfg.data.date_col] <= anchor, cfg.data.date_col]

    if dry_run:
        for s in generate_time_splits(split_dates, cfg.split):
            logger.info("DRY RUN split %s: train<%s, test [%s, %s) weight=%.3f",
                        s["name"], s["train_end"].date(), s["test_start"].date(),
                        s["test_end"].date(), s["weight"])
        logger.info("DRY RUN — no training, no MLflow runs.")
        return {}

    mlflow.set_experiment(cfg.mlflow.experiment_path)

    results: Dict[str, Any] = {}
    for model_name in cfg.search.models:
        logger.info("=" * 70)
        logger.info("Training: %s", model_name)
        try:
            results[model_name] = train_model(cfg, model_name, df, feature_cols, split_dates)
        except Exception as exc:
            if fail_fast:
                raise
            logger.error("Training failed for '%s': %s", model_name, exc, exc_info=True)
            results[model_name] = {"error": str(exc)}

    logger.info("=" * 70)
    failed = [k for k, v in results.items() if "error" in v]
    if failed:
        logger.error("Finished with %d failure(s): %s", len(failed), failed)
    else:
        logger.info("All %d model(s) trained successfully.", len(results))
    return results


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=DEFAULT_CONFIG, choices=sorted(TRAINING_CONFIGS))
    parser.add_argument("--models", nargs="+", default=None,
                        help="Subset of configured models to train.")
    parser.add_argument("--n_trials", type=int, default=None)
    parser.add_argument("--primary_metric", default=None)
    parser.add_argument("--experiment_path", default=None)
    parser.add_argument("--n_splits", type=int, default=None)
    parser.add_argument("--val_weeks", type=int, default=None)
    parser.add_argument("--min_test_rows", type=int, default=None)
    parser.add_argument("--dry_run", action="store_true",
                        help="Resolve data and splits, then stop.")
    parser.add_argument("--fail_fast", action="store_true")
    args, _ = parser.parse_known_args()
    return args


def apply_overrides(cfg: TrainingConfig, args) -> TrainingConfig:
    if args.models:
        unknown = [m for m in args.models if m not in cfg.search_space]
        if unknown:
            raise ValueError(f"No search space for {unknown}.")
        cfg.search.models = args.models
    if args.n_trials is not None:
        cfg.search.n_trials = args.n_trials
    if args.primary_metric:
        cfg.search.primary_metric = args.primary_metric
        if args.primary_metric not in cfg.search.metric_names:
            cfg.search.metric_names.append(args.primary_metric)
    if args.experiment_path:
        cfg.mlflow.experiment_path = args.experiment_path
    if args.n_splits is not None:
        cfg.split.n_splits = args.n_splits
    if args.val_weeks is not None:
        cfg.split.val_weeks = args.val_weeks
    if args.min_test_rows is not None:
        cfg.split.min_test_rows = args.min_test_rows
    return cfg


def main() -> int:
    from pyspark.sql import SparkSession

    args = parse_args()
    spark = SparkSession.builder.getOrCreate()

    cfg = apply_overrides(get_training_config(args.config), args)
    results = run_training(spark, cfg, dry_run=args.dry_run, fail_fast=args.fail_fast)

    return 1 if any("error" in v for v in results.values()) else 0


if __name__ == "__main__":
    sys.exit(main())