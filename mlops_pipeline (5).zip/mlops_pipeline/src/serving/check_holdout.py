"""
check_holdout.py
----------------
Scores the withheld rows against the DEPLOYED endpoint and reports accuracy.

    python -m src.serving.check_holdout --use_case fulfillment_risk
    python -m src.serving.check_holdout --use_case fulfillment_risk --limit 100

This is a different question from the validation metric training reported.
Training measured a model object on held-back rows; this measures the running
endpoint — the registered version, the serving container, the request path —
on rows that were never written to the feature table at all.

The two disagreeing is informative: same model, same data, different number
means something in the deployment path differs from training, usually dtype
handling or a column mismatch.
"""
from __future__ import annotations

import argparse
import logging
import sys
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from src.settings.feature_settings import get_feature_set
from src.settings.mlops_settings import (
    DEFAULT_USE_CASE,
    USE_CASES,
    get_use_case,
    serving_config,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


def load_holdout(spark, feature_set: str, limit: Optional[int] = None) -> pd.DataFrame:
    """
    Load the validation features joined to their labels.

    The validation feature set writes features and labels to separate tables,
    exactly as training does, so they are joined back together here.
    """
    cfg = get_feature_set(feature_set)
    if cfg.feature_store is None or cfg.target_table is None:
        raise ValueError(
            f"Feature set '{feature_set}' needs both a feature_store and a "
            f"target_table to be scored."
        )
    table = cfg.feature_store.table_name
    if not spark.catalog.tableExists(table):
        raise ValueError(
            f"Holdout table '{table}' does not exist. Run the features stage "
            f"first — it writes the holdout alongside the training tables."
        )

    truth_table = cfg.target_table.table_name
    if not spark.catalog.tableExists(truth_table):
        raise ValueError(f"Label table '{truth_table}' does not exist.")

    keys = cfg.target_table.merge_keys
    sdf = (spark.read.table(table)
           .join(spark.read.table(truth_table)
                 .select(*keys, cfg.target_table.target_col),
                 on=keys, how="inner"))
    if limit:
        sdf = sdf.limit(limit)
    pdf = sdf.toPandas()
    logger.info("Loaded %d validation row(s) from '%s' joined to '%s'.",
                len(pdf), table, truth_table)
    if pdf.empty:
        raise ValueError(
            f"Join of '{table}' and '{truth_table}' on {keys} produced no "
            f"rows — check the keys match on both sides."
        )
    return pdf


def score_via_endpoint(endpoint_name: str, records: List[Dict[str, Any]],
                       batch_size: int = 100) -> List[Any]:
    """
    Send rows to the endpoint in batches.

    Batched because a single request carrying thousands of rows hits payload
    limits and gives no partial result when it fails.
    """
    from src.serving.endpoint_manager import query_endpoint

    predictions: List[Any] = []
    for start in range(0, len(records), batch_size):
        batch = records[start:start + batch_size]
        response = query_endpoint(endpoint_name, batch)
        preds = getattr(response, "predictions", response)
        predictions.extend(np.asarray(preds).ravel().tolist())
        logger.info("  scored %d / %d", min(start + batch_size, len(records)),
                    len(records))
    return predictions


def evaluate(y_true: np.ndarray, y_pred: np.ndarray,
             class_labels: Optional[List[str]] = None) -> Dict[str, Any]:
    from sklearn.metrics import (accuracy_score, balanced_accuracy_score,
                                 classification_report, confusion_matrix,
                                 f1_score)

    metrics = {
        "rows": int(len(y_true)),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "f1_macro": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
    }

    logger.info("\nHoldout performance (deployed endpoint):")
    for key in ("rows", "accuracy", "balanced_accuracy", "f1_macro"):
        value = metrics[key]
        logger.info("  %-20s %s", key,
                    f"{value:.4f}" if isinstance(value, float) else value)

    names = class_labels if class_labels else None
    present = sorted(set(np.unique(y_true)) | set(np.unique(y_pred)))
    if names:
        names = [names[i] for i in present if i < len(names)]

    logger.info("\n%s", classification_report(y_true, y_pred, labels=present,
                                              target_names=names,
                                              zero_division=0))
    logger.info("Confusion matrix (rows = actual, cols = predicted):\n%s",
                confusion_matrix(y_true, y_pred, labels=present))

    # Near-perfect scores on a classification task usually mean the label is
    # recoverable from the inputs rather than that the model is excellent.
    if metrics["accuracy"] > 0.98:
        logger.warning(
            "Accuracy above 98%%. Check that no column feeding the labelling "
            "rule reached the feature table — run check_label_leakage.py."
        )
    return metrics


def run_check(spark, use_case: str, feature_set: Optional[str] = None,
              limit: Optional[int] = None,
              batch_size: int = 100) -> Dict[str, Any]:
    uc = get_use_case(use_case)
    serving = serving_config(use_case)
    # Default to the validation twin of the use case.
    fs_name = feature_set or f"{use_case}_validation"
    fset = get_feature_set(fs_name)

    holdout = load_holdout(spark, fs_name, limit)
    if holdout.empty:
        raise ValueError("Holdout table is empty.")

    label_col = uc.shared.target_col
    if label_col not in holdout.columns:
        raise ValueError(
            f"Holdout has no label column '{label_col}'. Available: "
            f"{sorted(holdout.columns)}"
        )

    # Drop exactly what training dropped, plus the label and its text twin.
    drop = set(uc.shared.drop_cols) | {label_col}
    if fset.label:
        drop |= {fset.label.name, fset.label.encoded_name()}
    features = holdout.drop(columns=[c for c in drop if c in holdout.columns])

    logger.info("Scoring %d row(s) against '%s' with %d feature column(s).",
                len(features), serving.endpoint_name, features.shape[1])

    # Decimal, numpy scalars and timestamps are not JSON types; NaN must be
    # null rather than the string "nan".
    from src.monitoring.batch_inference import to_jsonable
    records = to_jsonable(features)
    predictions = score_via_endpoint(serving.endpoint_name, records, batch_size)

    if len(predictions) != len(holdout):
        raise ValueError(
            f"Endpoint returned {len(predictions)} prediction(s) for "
            f"{len(holdout)} row(s)."
        )

    y_true = holdout[label_col].to_numpy()
    y_pred = np.round(np.asarray(predictions, dtype=float)).astype(int)

    class_labels = fset.label.labels if fset.label else None
    metrics = evaluate(y_true, y_pred, class_labels)
    metrics["endpoint"] = serving.endpoint_name
    return metrics


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--use_case", default=DEFAULT_USE_CASE,
                        choices=sorted(USE_CASES))
    parser.add_argument("--feature_set", default=None,
                        help="Validation feature set; defaults to "
                             "<use_case>_validation.")
    parser.add_argument("--limit", type=int, default=None,
                        help="Score only the first N holdout rows.")
    parser.add_argument("--batch_size", type=int, default=100)
    args, _ = parser.parse_known_args()
    return args


def main() -> int:
    from pyspark.sql import SparkSession
    args = parse_args()
    spark = SparkSession.builder.getOrCreate()
    try:
        run_check(spark, args.use_case, args.feature_set, args.limit,
                  args.batch_size)
    except Exception as exc:
        logger.error("Holdout check failed: %s", exc, exc_info=True)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())