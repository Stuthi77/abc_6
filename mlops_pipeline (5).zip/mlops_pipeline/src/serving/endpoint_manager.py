"""
endpoint_manager.py
-------------------
Create or update a Databricks Model Serving endpoint from config. Idempotent:
creates the endpoint when absent, updates it when the resolved config differs,
and does nothing when it already matches.

Run as a script:
    python -m src.serving.endpoint_manager --endpoint delay_days
    python -m src.serving.endpoint_manager --endpoint delay_days --plan
    python -m src.serving.endpoint_manager --endpoint delay_days --no_wait

In a notebook:
    from src.config.serving_config import get_serving_config
    from src.serving.endpoint_manager import deploy_endpoint, endpoint_status

    cfg = get_serving_config("delay_days")
    deploy_endpoint(cfg)
    endpoint_status(cfg.endpoint_name)

Aliases are resolved to concrete versions at deploy time, because serving pins
a version. Moving the champion alias does NOT move the endpoint until this runs
again — which is the intended behaviour: promotion and rollout stay separate.
"""
from __future__ import annotations

import argparse
import logging
import sys
from datetime import timedelta
from typing import Any, Dict, List, Optional, Tuple

import mlflow
from mlflow.tracking import MlflowClient

from src.settings.mlops_settings import (
    DEFAULT_USE_CASE as DEFAULT_ENDPOINT,
    USE_CASES as SERVING_ENDPOINTS,
    AIGatewayConfig,
    ServedModelSpec,
    ServingConfig,
    serving_config as get_serving_config,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────
# SDK access
# ──────────────────────────────────────────────────────────────────────────
def _workspace_client():
    try:
        from databricks.sdk import WorkspaceClient
    except ImportError as exc:
        raise RuntimeError(
            "databricks-sdk is not installed. On a Databricks cluster run:\n"
            "    %pip install databricks-sdk --upgrade\n"
            "    dbutils.library.restartPython()"
        ) from exc
    return WorkspaceClient()


def _sdk_types():
    from databricks.sdk.service.serving import (
        AutoCaptureConfigInput,
        EndpointCoreConfigInput,
        EndpointTag,
        ServedEntityInput,
        TrafficConfig,
        Route,
    )
    return {
        "AutoCaptureConfigInput": AutoCaptureConfigInput,
        "EndpointCoreConfigInput": EndpointCoreConfigInput,
        "EndpointTag": EndpointTag,
        "ServedEntityInput": ServedEntityInput,
        "TrafficConfig": TrafficConfig,
        "Route": Route,
    }


def _gateway_types():
    """
    AI Gateway types. Added in later SDK releases, so import them separately —
    an older SDK should fail with a clear message rather than breaking the
    model-config path too.
    """
    try:
        from databricks.sdk.service.serving import (
            AiGatewayConfig,
            AiGatewayInferenceTableConfig,
            AiGatewayRateLimit,
            AiGatewayUsageTrackingConfig,
        )
    except ImportError as exc:
        raise RuntimeError(
            "This databricks-sdk version has no AI Gateway support. Upgrade:\n"
            "    %pip install databricks-sdk --upgrade\n"
            "    dbutils.library.restartPython()"
        ) from exc
    return {
        "AiGatewayConfig": AiGatewayConfig,
        "AiGatewayInferenceTableConfig": AiGatewayInferenceTableConfig,
        "AiGatewayRateLimit": AiGatewayRateLimit,
        "AiGatewayUsageTrackingConfig": AiGatewayUsageTrackingConfig,
    }


def build_ai_gateway(gateway: AIGatewayConfig):
    """SDK AiGatewayConfig, or None when nothing is enabled."""
    if not gateway.configured():
        return None

    t = _gateway_types()
    kwargs = {}

    if gateway.usage_tracking_enabled:
        kwargs["usage_tracking_config"] = t["AiGatewayUsageTrackingConfig"](enabled=True)

    if gateway.inference_table.enabled:
        it = gateway.inference_table
        kwargs["inference_table_config"] = t["AiGatewayInferenceTableConfig"](
            enabled=True,
            catalog_name=it.catalog_name,
            schema_name=it.schema_name,
            table_name_prefix=it.table_name_prefix,
        )

    if gateway.rate_limits:
        from databricks.sdk.service.serving import (
            AiGatewayRateLimitKey, AiGatewayRateLimitRenewalPeriod)
        kwargs["rate_limits"] = [
            t["AiGatewayRateLimit"](
                calls=l.calls,
                renewal_period=AiGatewayRateLimitRenewalPeriod(l.renewal_period),
                key=AiGatewayRateLimitKey(l.key))
            for l in gateway.rate_limits
        ]

    return t["AiGatewayConfig"](**kwargs)


def apply_ai_gateway(cfg: ServingConfig, client=None) -> bool:
    """
    Push the AI Gateway block to an existing endpoint.

    Separate from the model config, so usage monitoring, inference tables and
    rate limits can be changed without redeploying the model.
    """
    if not cfg.ai_gateway.configured():
        logger.info("No AI Gateway settings configured — leaving as-is.")
        return False

    client = client or _workspace_client()
    gateway = build_ai_gateway(cfg.ai_gateway)

    kwargs = {"name": cfg.endpoint_name}
    for attr, key in (("usage_tracking_config", "usage_tracking_config"),
                      ("inference_table_config", "inference_table_config"),
                      ("rate_limits", "rate_limits")):
        value = getattr(gateway, attr, None)
        if value is not None:
            kwargs[key] = value

    client.serving_endpoints.put_ai_gateway(**kwargs)

    g = cfg.ai_gateway
    logger.info(
        "AI Gateway applied to '%s' — usage_tracking=%s, inference_tables=%s, "
        "rate_limits=%s",
        cfg.endpoint_name,
        g.usage_tracking_enabled,
        (f"{g.inference_table.catalog_name}.{g.inference_table.schema_name}."
         f"{g.inference_table.table_name_prefix}_*")
        if g.inference_table.enabled else False,
        [f"{l.calls}/{l.renewal_period} per {l.key}" for l in g.rate_limits] or False,
    )
    return True


# ──────────────────────────────────────────────────────────────────────────
# Resolving what to serve
# ──────────────────────────────────────────────────────────────────────────
def resolve_version(spec: ServedModelSpec, client: Optional[MlflowClient] = None) -> str:
    """Concrete model version for a spec, resolving an alias when given."""
    if spec.version:
        return str(spec.version)

    client = client or MlflowClient()
    try:
        mv = client.get_model_version_by_alias(spec.model_name, spec.alias)
    except Exception as exc:
        raise ValueError(
            f"[{spec.name}] cannot resolve alias '{spec.alias}' on "
            f"'{spec.model_name}': {exc}\n"
            f"Register a model and set the alias before deploying."
        ) from exc

    logger.info("[%s] alias '%s' -> version %s", spec.name, spec.alias, mv.version)
    return str(mv.version)


def resolve_plan(cfg: ServingConfig) -> List[Tuple[ServedModelSpec, str]]:
    """Pair each served model with the version it will pin."""
    mlflow.set_registry_uri("databricks-uc")
    client = MlflowClient()
    return [(spec, resolve_version(spec, client)) for spec in cfg.served_models]


def describe_plan(cfg: ServingConfig, plan: List[Tuple[ServedModelSpec, str]]) -> str:
    lines = [f"Endpoint: {cfg.endpoint_name}"]
    for spec, version in plan:
        source = f"alias '{spec.alias}'" if spec.alias else "pinned version"
        lines.append(
            f"  {spec.name:<12} {spec.model_name} v{version} "
            f"({source}) — {spec.traffic_percentage}% traffic, "
            f"{spec.workload_size}/{spec.workload_type}, "
            f"scale_to_zero={spec.scale_to_zero_enabled}"
        )
    g = cfg.ai_gateway
    lines.append("  AI Gateway:")
    lines.append(f"    usage monitoring : {'on' if g.usage_tracking_enabled else 'not configured'}")
    if g.inference_table.enabled:
        it = g.inference_table
        lines.append(f"    inference tables : {it.catalog_name}.{it.schema_name}."
                     f"{it.table_name_prefix}_*")
    else:
        lines.append("    inference tables : not configured")
    if g.rate_limits:
        for l in g.rate_limits:
            lines.append(f"    rate limit       : {l.calls} calls/{l.renewal_period} per {l.key}")
    else:
        lines.append("    rate limits      : not configured")
    return "\n".join(lines)


# ──────────────────────────────────────────────────────────────────────────
# Building the SDK payload
# ──────────────────────────────────────────────────────────────────────────
def _served_entity_name(spec: ServedModelSpec, version: str) -> str:
    """
    Entity name inside the endpoint.

    Databricks derives a default from model and version; naming it explicitly
    keeps traffic routes stable and readable across redeploys.
    """
    return f"{spec.name}-v{version}"


def build_core_config(cfg: ServingConfig, plan: List[Tuple[ServedModelSpec, str]]):
    t = _sdk_types()
    from databricks.sdk.service.serving import ServingModelWorkloadType

    served_entities = []
    routes = []
    for spec, version in plan:
        entity_name = _served_entity_name(spec, version)
        served_entities.append(
            t["ServedEntityInput"](
                name=entity_name,
                entity_name=spec.model_name,
                entity_version=version,
                workload_size=spec.workload_size,
                workload_type=ServingModelWorkloadType(spec.workload_type),
                scale_to_zero_enabled=spec.scale_to_zero_enabled,
                environment_vars=spec.environment_vars or None,
            )
        )
        routes.append(
            t["Route"](served_model_name=entity_name,
                       traffic_percentage=spec.traffic_percentage)
        )

    # Payload capture is configured through AI Gateway, not auto_capture_config
    # — setting both makes Databricks reject the request.
    auto_capture = None

    return t["EndpointCoreConfigInput"](
        name=cfg.endpoint_name,
        served_entities=served_entities,
        traffic_config=t["TrafficConfig"](routes=routes),
        auto_capture_config=auto_capture,
    )


def _endpoint_tags(cfg: ServingConfig):
    if not cfg.tags:
        return None
    t = _sdk_types()
    return [t["EndpointTag"](key=k, value=str(v)) for k, v in cfg.tags.items()]


# ──────────────────────────────────────────────────────────────────────────
# State
# ──────────────────────────────────────────────────────────────────────────
def get_endpoint(name: str, client=None):
    """The endpoint, or None when it does not exist."""
    client = client or _workspace_client()
    try:
        return client.serving_endpoints.get(name)
    except Exception as exc:
        if "does not exist" in str(exc).lower() or "not found" in str(exc).lower():
            return None
        raise


def _live_entities(endpoint) -> Dict[str, str]:
    """{model_name: version} currently served, from the live config."""
    config = getattr(endpoint, "config", None) or getattr(endpoint, "pending_config", None)
    if config is None:
        return {}
    out = {}
    for entity in (getattr(config, "served_entities", None) or []):
        model = getattr(entity, "entity_name", None)
        version = getattr(entity, "entity_version", None)
        if model and version:
            out[f"{model}:{version}"] = getattr(entity, "name", "")
    return out


def _plan_matches_live(endpoint, plan) -> bool:
    live = set(_live_entities(endpoint))
    wanted = {f"{spec.model_name}:{version}" for spec, version in plan}
    return live == wanted and bool(wanted)


def endpoint_status(name: str) -> Dict[str, Any]:
    """Readable state of an endpoint."""
    client = _workspace_client()
    endpoint = get_endpoint(name, client)
    if endpoint is None:
        logger.info("Endpoint '%s' does not exist.", name)
        return {"exists": False}

    state = getattr(endpoint, "state", None)
    status = {
        "exists": True,
        "name": endpoint.name,
        "ready": str(getattr(state, "ready", "UNKNOWN")),
        "config_update": str(getattr(state, "config_update", "UNKNOWN")),
        "served": _live_entities(endpoint),
    }
    logger.info("Endpoint '%s': ready=%s, config_update=%s",
                status["name"], status["ready"], status["config_update"])
    for key in status["served"]:
        logger.info("  serving %s", key)
    return status


# ──────────────────────────────────────────────────────────────────────────
# Deploy
# ──────────────────────────────────────────────────────────────────────────
def deploy_endpoint(cfg: ServingConfig, wait: bool = True,
                    plan_only: bool = False) -> Dict[str, Any]:
    """
    Create or update the endpoint so it serves what the config describes.

    Returns a dict with the action taken: created | updated | unchanged | planned.
    """
    cfg.validate()
    plan = resolve_plan(cfg)
    logger.info("\n%s", describe_plan(cfg, plan))

    if plan_only:
        return {"action": "planned",
                "endpoint": cfg.endpoint_name,
                "versions": {s.name: v for s, v in plan}}

    client = _workspace_client()
    core = build_core_config(cfg, plan)
    timeout = timedelta(minutes=cfg.wait_timeout_minutes)
    existing = get_endpoint(cfg.endpoint_name, client)

    if existing is None:
        logger.info("Creating endpoint '%s' (this usually takes 10-20 minutes).",
                    cfg.endpoint_name)
        kwargs = {"name": cfg.endpoint_name, "config": core}
        tags = _endpoint_tags(cfg)
        if tags:
            kwargs["tags"] = tags
        gateway = build_ai_gateway(cfg.ai_gateway)
        if gateway is not None:
            kwargs["ai_gateway"] = gateway
        if cfg.route_optimized:
            kwargs["route_optimized"] = True

        if wait:
            client.serving_endpoints.create_and_wait(timeout=timeout, **kwargs)
        else:
            client.serving_endpoints.create(**kwargs)
        action = "created"

    elif _plan_matches_live(existing, plan) and not cfg.force_update:
        logger.info(
            "Endpoint '%s' already serves exactly this configuration. Applying "
            "AI Gateway settings; set force_update=True to redeploy the model.",
            cfg.endpoint_name,
        )
        if cfg.ai_gateway.configured():
            apply_ai_gateway(cfg, client)
        return {"action": "unchanged", "endpoint": cfg.endpoint_name,
                "versions": {s.name: v for s, v in plan}}

    else:
        logger.info("Updating endpoint '%s'.", cfg.endpoint_name)
        update_kwargs = {
            "name": cfg.endpoint_name,
            "served_entities": core.served_entities,
            "traffic_config": core.traffic_config,
        }
        if core.auto_capture_config is not None:
            update_kwargs["auto_capture_config"] = core.auto_capture_config

        if wait:
            client.serving_endpoints.update_config_and_wait(timeout=timeout,
                                                            **update_kwargs)
        else:
            client.serving_endpoints.update_config(**update_kwargs)
        action = "updated"

    # Applied separately as well as inline: on an UPDATE the model config call
    # does not carry the Gateway block, and this is also how Gateway-only edits
    # reach an endpoint that is already live.
    if cfg.ai_gateway.configured():
        try:
            apply_ai_gateway(cfg, client)
        except Exception as exc:
            logger.error(
                "Endpoint %s but the AI Gateway block failed to apply: %s",
                action, exc,
            )

    result = {"action": action, "endpoint": cfg.endpoint_name,
              "versions": {s.name: v for s, v in plan}}
    if wait:
        result["status"] = endpoint_status(cfg.endpoint_name)
    else:
        logger.info("Submitted without waiting — poll with endpoint_status('%s').",
                    cfg.endpoint_name)
    return result


# ──────────────────────────────────────────────────────────────────────────
# Smoke test
# ──────────────────────────────────────────────────────────────────────────
def query_endpoint(endpoint_name: str, records: List[Dict[str, Any]]):
    """
    Send rows to the endpoint. Each record must carry exactly the columns the
    model signature declares.
    """
    client = _workspace_client()
    response = client.serving_endpoints.query(
        name=endpoint_name, dataframe_records=records
    )
    logger.info("Endpoint returned %s", getattr(response, "predictions", response))
    return response


def smoke_test_from_table(spark, cfg: ServingConfig, feature_table: str,
                          exclude: Optional[List[str]] = None, n: int = 3):
    """Score a few real rows, dropping the columns the model was not trained on."""
    pdf = spark.read.table(feature_table).limit(n).toPandas()
    for col in (exclude or []):
        if col in pdf.columns:
            pdf = pdf.drop(columns=[col])
    records = pdf.astype(object).where(pdf.notna(), None).to_dict(orient="records")
    return query_endpoint(cfg.endpoint_name, records)


# ──────────────────────────────────────────────────────────────────────────
# Entrypoint
# ──────────────────────────────────────────────────────────────────────────
def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--endpoint", default=DEFAULT_ENDPOINT,
                        choices=sorted(SERVING_ENDPOINTS))
    parser.add_argument("--plan", action="store_true",
                        help="Resolve aliases and print what would deploy, then stop.")
    parser.add_argument("--no_wait", action="store_true",
                        help="Submit without waiting for the endpoint to be ready.")
    parser.add_argument("--force", action="store_true",
                        help="Redeploy even when the live config already matches.")
    parser.add_argument("--status", action="store_true",
                        help="Print current state and exit.")
    parser.add_argument("--gateway_only", action="store_true",
                        help="Apply only the AI Gateway block (usage monitoring, "
                             "inference tables, rate limits) to a live endpoint. "
                             "Does not touch the served model.")
    args, _ = parser.parse_known_args()
    return args


def main() -> int:
    args = parse_args()
    cfg = get_serving_config(args.endpoint)

    if args.status:
        endpoint_status(cfg.endpoint_name)
        return 0

    if args.gateway_only:
        try:
            apply_ai_gateway(cfg)
            return 0
        except Exception as exc:
            logger.error("Could not apply AI Gateway settings: %s", exc, exc_info=True)
            return 1

    if args.force:
        cfg.force_update = True

    try:
        result = deploy_endpoint(cfg, wait=not args.no_wait, plan_only=args.plan)
    except Exception as exc:
        logger.error("Deployment failed: %s", exc, exc_info=True)
        return 1

    logger.info("Result: %s", result)
    return 0


if __name__ == "__main__":
    sys.exit(main())
