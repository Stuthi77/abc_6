"""
monitoring_settings.py
----------------------
The code behind src/config/monitoring_config.py: the monitoring dataclasses,
their validation, the SQL helpers for slice groups, from_use_case(), and the
MONITORING_CONFIGS registry built from the plain dictionaries in the config
file (batch inference, Lakehouse monitoring, drift, rollback, alerting).

    python -m src.monitoring.batch_inference  --monitor weekly_orders
    python -m src.monitoring.lakehouse_monitor --monitor weekly_orders
    python -m src.monitoring.check_drift       --monitor weekly_orders
    python -m src.monitoring.check_rollback    --monitor weekly_orders
    python -m src.monitoring.rollback          --monitor weekly_orders --approve
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

# Monitoring scores the model that mlops_config registers, over the table it
# was trained on. Deriving from SharedConfig keeps the feature table, the
# model name and the excluded columns identical across train/score/monitor —
# a mismatch in any of them breaks predict() at scoring time.
from src.settings.mlops_settings import SharedConfig, get_use_case
from src.settings.feature_settings import get_feature_set

from src.config import monitoring_config as _cfg
from src.config.monitoring_config import DEFAULT_MONITORING   # input, re-exported
from src.settings.builder import build, build_fields

VALID_PROBLEM_TYPES = ("regression", "classification")


# ──────────────────────────────────────────────────────────────────────────
# SQL builders for grouping columns. Kept here so the group definitions live
# in ONE place (the use-case config below) and every consumer — scoring,
# baseline, slicing_exprs, dashboards — derives from the same values.
# ──────────────────────────────────────────────────────────────────────────
def prefix_case_expr(source_col: str, groups: Sequence[str],
                     default: Optional[str] = None) -> str:
    """CASE WHEN <col> LIKE '<g>%' THEN '<g>' ... ELSE '<default>' END"""
    whens = " ".join(f"WHEN {source_col} LIKE '{g}%' THEN '{g}'" for g in groups)
    tail = f" ELSE '{default}'" if default is not None else ""
    return f"CASE {whens}{tail} END"


def hash_bucket_expr(key_col: str, shares: Dict[str, int]) -> str:
    """Deterministic assignment by hash(key) % 100 using cumulative shares."""
    total, whens = 0, []
    items = list(shares.items())
    for group, share in items[:-1]:
        total += share
        whens.append(f"WHEN abs(hash({key_col})) % 100 < {total} THEN '{group}'")
    return f"CASE {' '.join(whens)} ELSE '{items[-1][0]}' END"


def binary_slices(column: str, groups: Sequence[str]) -> List[str]:
    """The group column itself plus one binary slice per group.

    The monitor only computes fairness metrics (statistical_parity, ...) for
    BINARY slices, so each protected group needs its own `col = 'g'` expr.
    """
    return [column] + [f"{column} = '{g}'" for g in groups]


@dataclass
class SliceEnrichmentConfig:
    """
    Adds a grouping column (e.g. warehouse_group) to every scored and baseline
    row so the monitor's slicing_exprs can reference it.

    Value = source_expr evaluated on source_table, joined on join_keys;
    rows without a lookup match fall back to fallback_expr on the scored row.
    """

    column: str
    source_table: Optional[str] = None
    join_keys: List[str] = field(default_factory=list)
    source_expr: Optional[str] = None
    fallback_expr: Optional[str] = None

    def validate(self) -> None:
        if not self.column:
            raise ValueError("enrichment.column is required.")
        if self.source_table and (not self.join_keys or not self.source_expr):
            raise ValueError("enrichment with source_table needs join_keys and source_expr.")
        if not (self.source_table or self.fallback_expr):
            raise ValueError("enrichment needs source_table or fallback_expr.")


@dataclass
class DashboardConfig:
    """
    Post-processing of the dashboard the Lakehouse monitor generates.

    The generated dashboard hardcodes "No slice", mixes the '*' all-versions
    rows with per-version rows, has no default Model Id and a type-mismatched
    Top K filter. sync_dashboards() repairs all of that from these settings.
    """

    sync_on_monitor: bool = True          # run the sync after stage_monitor
    sync_all_dashboards: bool = True      # every dashboard in the monitor's assets dir
    no_slice_label: str = "No slice"
    model_all_token: str = "*"            # the monitor's all-versions model_id
    model_param: str = "Model Id"
    slice_key_param: str = "Slice Key"
    slice_value_param: str = "Slice Value"
    top_k_param: str = "top_k"
    # None -> first binary expression in monitor.slicing_exprs
    default_protected_group: Optional[str] = None


@dataclass
class VisualizationConfig:
    """Notebook charts rendered by stage_visualize."""

    class_labels: Dict[str, str] = field(default_factory=dict)  # class -> display label
    top_n_drift_features: int = 8
    quantile_panels: int = 6
    quantile_labels: List[str] = field(default_factory=lambda: [
        "0%", "5%", "25%", "50%", "75%", "95%", "100%"])
    ks_alert_statistic: float = 0.3
    # Drift charts plot one series per window: un-sliced rows, the monitor's
    # all-versions model_id (dashboard.model_all_token) and this drift type.
    drift_chart_type: str = "CONSECUTIVE"
    fairness_band: Tuple[float, float] = (0.8, 1.25)
    palette: List[str] = field(default_factory=lambda: [
        "#2ecc71", "#f1c40f", "#e67e22", "#e74c3c",
        "#3498db", "#9b59b6", "#1abc9c", "#e91e63"])


@dataclass
class BatchInferenceConfig:
    """Scoring the Champion over new periods and recording the results."""

    feature_table: str
    inference_table: str
    actual_target_table: Optional[str] = None

    # Grain of one prediction row; used to upsert rather than duplicate.
    merge_keys: List[str] = field(default_factory=list)

    time_column: str = "week"
    prediction_col: str = "prediction_final"
    label_col: str = "target_qty"
    model_version_col: str = "model_version"
    model_name_col: str = "model_name"
    timestamp_col: str = "prediction_timestamp"

    # Columns dropped before predict — identifiers, the label, bookkeeping.
    exclude_from_features: List[str] = field(default_factory=list)

    # Cap the periods scored in one run so a cold start cannot score years.
    max_periods_per_run: int = 52

    # How predictions are produced.
    #   "local"    — mlflow.pyfunc.load_model on this cluster. Fast, no network,
    #                but it exercises the MODEL, not the deployment. A dtype
    #                coercion or library difference inside the serving
    #                container is invisible to it.
    #   "endpoint" — HTTP to the serving endpoint. Slower and subject to the
    #                rate limits you configured, but the predictions are the
    #                ones production actually returns, so monitoring describes
    #                the deployed system rather than an artifact.
    scoring_mode: str = "local"

    # endpoint mode: which endpoint. None uses the use case's own.
    endpoint_name: Optional[str] = None

    # Rows per HTTP request. Too large and the payload is rejected; too small
    # and you burn through the per-minute rate limit.
    endpoint_batch_size: int = 100

    # Write prediction and label as STRING. For classification the monitor
    # then profiles them as categorical (frequent_items, chi-squared), which
    # the dashboard's prediction-drift panels need. Both must share a type.
    categorical_output: bool = False

    # Extra model versions to score alongside the deployed/Champion one, so
    # the monitor can compare versions. Aliases ("challenger") or version
    # numbers. Always scored locally — the endpoint serves one version only.
    compare_model_refs: List[str] = field(default_factory=list)

    # Grouping column added to scored + baseline rows (for slicing_exprs).
    enrichment: Optional[SliceEnrichmentConfig] = None

    # Days to shift time_column forward in the inference table, relative to
    # the feature table. A new inference/time-series monitor only analyses
    # the 30 days before its creation, so historical validation rows fall
    # outside it and every dashboard dataset stays empty. 0 = no shift.
    # Testing/demo only — never shift real production predictions.
    date_shift_days: int = 0

    def upsert_keys(self) -> List[str]:
        """One prediction per row PER model version."""
        return list(dict.fromkeys([*self.merge_keys, self.model_version_col]))

    def scoring_is_remote(self) -> bool:
        return self.scoring_mode == "endpoint"

    def validate(self) -> None:
        if not self.merge_keys:
            raise ValueError("merge_keys cannot be empty — upserts need a grain.")
        for name in ("feature_table", "inference_table"):
            value = getattr(self, name)
            if value.count(".") != 2:
                raise ValueError(f"{name} must be catalog.schema.table, got '{value}'.")
        if self.max_periods_per_run < 1:
            raise ValueError("max_periods_per_run must be >= 1")
        if self.scoring_mode not in ("local", "endpoint"):
            raise ValueError(
                f"scoring_mode must be 'local' or 'endpoint', "
                f"got '{self.scoring_mode}'."
            )
        if self.endpoint_batch_size < 1:
            raise ValueError("endpoint_batch_size must be >= 1")
        if self.date_shift_days < 0:
            raise ValueError("date_shift_days must be >= 0")
        if self.enrichment is not None:
            self.enrichment.validate()


@dataclass
class LakehouseMonitorConfig:
    """Databricks quality monitor over the inference table."""

    enabled: bool = True
    output_schema: str = ""            # catalog.schema for the metric tables
    assets_dir: str = ""               # workspace dir for the dashboard
    baseline_table: Optional[str] = None
    problem_type: str = "regression"
    granularities: List[str] = field(default_factory=lambda: ["4 weeks"])

    # Columns the monitor reads. label_col MUST be the real label, not the
    # prediction — pointing it at the prediction makes every error metric zero
    # and the monitor useless.
    prediction_col: str = "prediction_final"
    label_col: str = "target_qty"
    model_id_col: str = "model_version"
    timestamp_col: str = "prediction_timestamp"

    # SQL expressions the monitor slices by. Each expression becomes a
    # slice_key in the profile table, enabling per-group fairness metrics
    # (statistical_parity, equal_opportunity, predictive_equality,
    # predictive_parity).  Without at least one slice the fairness columns
    # stay NULL.
    slicing_exprs: List[str] = field(default_factory=list)

    refresh_poll_seconds: int = 30
    refresh_timeout_minutes: int = 60

    def validate(self) -> None:
        if not self.enabled:
            return
        if self.problem_type not in VALID_PROBLEM_TYPES:
            raise ValueError(
                f"problem_type must be one of {VALID_PROBLEM_TYPES}, "
                f"got '{self.problem_type}'."
            )
        if not self.output_schema or self.output_schema.count(".") != 1:
            raise ValueError(
                f"output_schema must be catalog.schema, got '{self.output_schema}'."
            )
        if not self.assets_dir:
            raise ValueError("assets_dir is required when the monitor is enabled.")
        if self.label_col == self.prediction_col:
            raise ValueError(
                f"label_col and prediction_col are both '{self.label_col}'. The "
                f"monitor would compare predictions against themselves and "
                f"report zero error. Point label_col at the actual outcome."
            )


@dataclass
class DriftConfig:
    """Reading the monitor's drift metrics table."""

    drift_table: str = ""              # <output_schema>.<inference_table>_drift_metrics
    ks_pvalue_threshold: float = 0.05
    chi_pvalue_threshold: float = 0.05

    # How many drifted columns before it counts as drift.
    min_drifted_columns: int = 5

    # Never treated as drift: identifiers, outputs, bookkeeping.
    exclude_columns: List[str] = field(default_factory=list)

    # Monitor refreshes are asynchronous; wait before reading fresh metrics.
    wait_seconds_before_read: int = 0

    def validate(self) -> None:
        for name in ("ks_pvalue_threshold", "chi_pvalue_threshold"):
            value = getattr(self, name)
            if not 0 < value < 1:
                raise ValueError(f"{name} must be between 0 and 1, got {value}.")
        if self.min_drifted_columns < 1:
            raise ValueError("min_drifted_columns must be >= 1")


@dataclass
class RollbackThresholds:
    """When live performance counts as degraded."""

    # Fractional worsening against the Champion's training metric: 0.20 == 20%.
    metric_pct_increase: float = 0.20

    # Which way is bad. For an error metric (MAE) a RISE is degradation; for a
    # score (f1, accuracy) a FALL is. Set "lower_is_better" for classification
    # scores, otherwise a model getting worse looks like it is improving.
    direction: str = "higher_is_worse"      # higher_is_worse | lower_is_better

    # Consecutive breaching windows required — one bad window is usually noise.
    consecutive_windows: int = 3

    # Quiet period after a rollback, so a fresh Champion is not judged on
    # windows produced by its predecessor.
    settling_hours: int = 24

    # Monitor metric to read, and the training metric to compare it against.
    monitor_metric: str = "mean_absolute_error"
    training_metric: str = "best_weighted_mean_mae"

    def validate(self) -> None:
        if self.metric_pct_increase <= 0:
            raise ValueError("metric_pct_increase must be > 0")
        if self.consecutive_windows < 1:
            raise ValueError("consecutive_windows must be >= 1")
        if self.settling_hours < 0:
            raise ValueError("settling_hours must be >= 0")
        if self.direction not in ("higher_is_worse", "lower_is_better"):
            raise ValueError(
                f"direction must be 'higher_is_worse' or 'lower_is_better', "
                f"got '{self.direction}'."
            )


@dataclass
class AlertConfig:
    """Where alerts go. Email is optional — logging always happens."""

    enabled: bool = False
    recipients: List[str] = field(default_factory=list)
    subject_prefix: str = "[MLOps]"

    # Databricks SQL / webhook target, when used instead of SMTP.
    webhook_url: Optional[str] = None

    # Pipeline to trigger on approval, surfaced in the alert body.
    approval_pipeline_url: Optional[str] = None

    def validate(self) -> None:
        if self.enabled and not (self.recipients or self.webhook_url):
            raise ValueError(
                "Alerts are enabled but neither recipients nor webhook_url is set."
            )


@dataclass
class MonitoringConfig:
    name: str
    catalog: str
    schema: str
    model_name: str                    # UC name without catalog.schema

    batch: BatchInferenceConfig
    monitor: LakehouseMonitorConfig = field(default_factory=LakehouseMonitorConfig)
    drift: DriftConfig = field(default_factory=DriftConfig)
    rollback: RollbackThresholds = field(default_factory=RollbackThresholds)
    alerts: AlertConfig = field(default_factory=AlertConfig)

    champion_alias: str = "champion"
    challenger_alias: str = "challenger"

    # Records rollbacks so the settling window can be enforced.
    control_table: str = ""

    dashboard: DashboardConfig = field(default_factory=DashboardConfig)
    viz: VisualizationConfig = field(default_factory=VisualizationConfig)

    @property
    def full_model_name(self) -> str:
        return f"{self.catalog}.{self.schema}.{self.model_name}"

    @property
    def champion_uri(self) -> str:
        return f"models:/{self.full_model_name}@{self.champion_alias}"

    def validate(self) -> None:
        self.batch.validate()
        self.monitor.validate()
        self.drift.validate()
        self.rollback.validate()
        self.alerts.validate()
        if self.champion_alias == self.challenger_alias:
            raise ValueError("champion_alias and challenger_alias must differ.")
        if not self.control_table or self.control_table.count(".") != 2:
            raise ValueError(
                f"control_table must be catalog.schema.table, got "
                f"'{self.control_table}'."
            )


def from_use_case(
    use_case: str,
    *,
    inference_schema: str,
    monitor_schema: str,
    scoring_feature_table: Optional[str] = None,
    scoring_target_table: Optional[str] = None,
    assets_dir: str,
    time_column: str,
    # Which column the monitor buckets windows by.
    #   event  — the business date (order_date). Windows then mean "orders
    #            placed in this period", which is what drift over time means.
    #   scored — prediction_timestamp. A batch run stamps every row with the
    #            same instant, so a whole backfill collapses into ONE window
    #            and no drift can be measured between windows.
    monitor_time_basis: str = "event",
    granularities: Optional[List[str]] = None,
    scoring_mode: str = "local",
    endpoint_batch_size: int = 100,
    prediction_col: str = "prediction_final",
    monitor_metric: Optional[str] = None,
    training_metric: Optional[str] = None,
    drift_exclude_extra: Optional[List[str]] = None,
    slicing_exprs: Optional[List[str]] = None,
    enrichment: Optional[SliceEnrichmentConfig] = None,
    compare_model_refs: Optional[List[str]] = None,
    categorical_output: Optional[bool] = None,
    date_shift_days: int = 0,
    **overrides,
) -> MonitoringConfig:
    """
    Build a MonitoringConfig from a use case in mlops_config.

    Everything that must agree with training and registration is taken from
    SharedConfig rather than retyped:
        feature_table, catalog, schema, model_name, label column,
        merge keys (the join keys), and the excluded-column list.

    Only the monitoring-specific values are passed in: where predictions and
    metric tables live, and the thresholds.
    """
    if monitor_time_basis not in ("event", "scored"):
        raise ValueError(
            f"monitor_time_basis must be 'event' or 'scored', "
            f"got '{monitor_time_basis}'."
        )

    uc = get_use_case(use_case)
    s: SharedConfig = uc.shared

    inference_table = f"{inference_schema}.{s.name}_predictions"

    classification = uc.training.search.task == "classification"

    # Default to the metric training actually logs on the parent refit run.
    if training_metric is None:
        training_metric = f"best_weighted_mean_{uc.training.search.primary_metric}"

    # The monitor computes different metrics per problem type. For a classifier
    # the error measure is 1 - accuracy, so degradation is still "higher is
    # worse" and the same percentage-increase rule applies.
    if monitor_metric is None:
        monitor_metric = ("f1_score" if classification else "mean_absolute_error")

    # Never drift signals: the grain, the model outputs, the bookkeeping.
    # The enrichment column is a slicing dimension, not a model input.
    drift_exclude = list(dict.fromkeys(
        [":table", *s.join_keys, *s.drop_cols,
         "model_name", "model_version", "prediction_timestamp",
         prediction_col, s.target_col, time_column]
        + ([enrichment.column] if enrichment else [])
        + (drift_exclude_extra or [])
    ))

    cfg = MonitoringConfig(
        name=s.name,
        catalog=s.catalog,
        schema=s.schema,
        model_name=s.model_name,
        batch=BatchInferenceConfig(
            # Monitoring scores the VALIDATION rows, not the ones the model was
            # fitted on. Scoring the training set would measure memorisation
            # and show no drift by construction.
            feature_table=scoring_feature_table or s.feature_table,
            inference_table=inference_table,
            actual_target_table=scoring_target_table or s.target_table,
            merge_keys=list(s.join_keys),
            time_column=time_column,
            prediction_col=prediction_col,
            label_col=s.target_col,
            # Same columns training dropped — otherwise the scoring frame will
            # not match the model signature.
            exclude_from_features=list(s.drop_cols),
            scoring_mode=scoring_mode,
            endpoint_batch_size=endpoint_batch_size,
            # Classification -> categorical by default (prediction drift panels).
            categorical_output=(classification if categorical_output is None
                                else categorical_output),
            compare_model_refs=list(compare_model_refs or []),
            enrichment=enrichment,
            date_shift_days=date_shift_days,
        ),
        monitor=LakehouseMonitorConfig(
            enabled=True,
            output_schema=monitor_schema,
            assets_dir=assets_dir,
            baseline_table=f"{s.catalog}.{s.schema}.{s.model_name}_baseline",
            problem_type="classification" if classification else "regression",
            granularities=list(granularities or ["4 weeks"]),
            prediction_col=prediction_col,
            label_col=s.target_col,          # the real outcome, never the prediction
            timestamp_col=(time_column if monitor_time_basis == "event"
                           else "prediction_timestamp"),
            slicing_exprs=list(slicing_exprs or []),
        ),
        drift=DriftConfig(
            drift_table=f"{inference_table}_drift_metrics",
            exclude_columns=drift_exclude,
        ),
        rollback=RollbackThresholds(
            monitor_metric=monitor_metric,
            training_metric=training_metric,
            # A classification score falling is degradation; an error metric
            # rising is.
            direction=("lower_is_better" if classification else "higher_is_worse"),
        ),
        control_table=f"{monitor_schema}.mlops_pipeline_control",
        **overrides,
    )
    cfg.validate()
    return cfg


# ══════════════════════════════════════════════════════════════════════════
# Monitored use cases — built from the dictionaries in src/config/monitoring_config.py
# ══════════════════════════════════════════════════════════════════════════
def _slice_groups(spec: Dict) -> Tuple[List[str], SliceEnrichmentConfig]:
    """
    Group column + one binary slice per group (the monitor computes fairness
    only for binary slices) + the enrichment that adds the column at scoring.

    spec keys: column, source_column, hash_key, shares, lookup_feature_set,
    lookup_use_case. `shares` order defines the CASE default (last group).
    """
    shares = dict(spec["shares"])
    groups = list(shares)
    slicing_exprs = binary_slices(spec["column"], groups)
    enrichment = SliceEnrichmentConfig(
        column=spec["column"],
        # Lookup from the training source table (has the raw value).
        source_table=get_feature_set(spec["lookup_feature_set"]).source_table,
        join_keys=list(get_use_case(spec["lookup_use_case"]).shared.join_keys),
        source_expr=prefix_case_expr(spec["source_column"], groups, default=groups[-1]),
        # Rows with no lookup match: assign deterministically by hash.
        fallback_expr=hash_bucket_expr(spec["hash_key"], shares),
    )
    return slicing_exprs, enrichment


def build_monitoring_config(spec: Dict) -> MonitoringConfig:
    """
    One MONITORING_CONFIGS entry -> MonitoringConfig.

      "use_case" set   -> from_use_case(use_case, **rest)   (DERIVED)
      "use_case" None  -> MonitoringConfig(**rest)           (STANDALONE)
      "slice_groups"   -> expanded into slicing_exprs + enrichment
    """
    spec = dict(spec)
    use_case = spec.pop("use_case", None)
    groups = spec.pop("slice_groups", None)
    if groups:
        spec["slicing_exprs"], spec["enrichment"] = _slice_groups(groups)
    if use_case is None:
        return build(MonitoringConfig, spec)
    if isinstance(spec.get("enrichment"), dict):
        spec["enrichment"] = build(SliceEnrichmentConfig, spec["enrichment"])
    return from_use_case(use_case, **build_fields(MonitoringConfig, spec))


MONITORING_CONFIGS: Dict[str, MonitoringConfig] = {
    name: build_monitoring_config(spec) for name, spec in _cfg.MONITORING_CONFIGS.items()
}


def get_monitoring_config(name: Optional[str] = None) -> MonitoringConfig:
    key = name or DEFAULT_MONITORING
    try:
        cfg = MONITORING_CONFIGS[key]
    except KeyError:
        raise ValueError(
            f"Unknown monitoring config '{key}'. "
            f"Configured: {sorted(MONITORING_CONFIGS)}"
        ) from None
    cfg.validate()
    return cfg