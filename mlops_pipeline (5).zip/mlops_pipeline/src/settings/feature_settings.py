"""
feature_settings.py
-------------------
The code behind src/config/feature_config.py: the feature-spec dataclasses,
their validation, and the FEATURE_SETS registry built from the plain
dictionaries in the config file.

The original notebook hardcoded every aggregation, lag window and column name.
They are now data in src/config/feature_config.py, so a new grain or a new lag
is a config edit.

    python -m src.feature_engineering.build_features --feature_set weekly_orders
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

# The feature set WRITES the tables that mlops_config READS. Importing the
# shared config means those table names are stated once, in mlops_config, and
# derived here — rather than typed twice and silently drifting apart.
from src.settings.mlops_settings import SharedConfig, get_use_case

from src.config import feature_config as _cfg
from src.config.feature_config import DEFAULT_FEATURE_SET   # input, re-exported
from src.settings.builder import build

# Aggregations allowed in AggregationSpec.func. "share_of" is special: it
# computes the fraction of rows where `column` equals `equals`.
VALID_AGGS = ("sum", "mean", "min", "max", "std", "count", "nunique", "share_of")

VALID_ROLLING_STATS = ("mean", "std", "min", "max", "sum", "ewm")


@dataclass
class AggregationSpec:
    """One output column produced by grouping the source rows."""

    name: str                      # output column name
    column: str                    # source column
    func: str                      # one of VALID_AGGS
    equals: Optional[Any] = None   # only for func="share_of"

    def validate(self) -> None:
        if self.func not in VALID_AGGS:
            raise ValueError(
                f"[{self.name}] func must be one of {VALID_AGGS}, got '{self.func}'."
            )
        if self.func == "share_of" and self.equals is None:
            raise ValueError(f"[{self.name}] func='share_of' requires `equals`.")


@dataclass
class LagSpec:
    """Lagged values of one column within each series."""

    column: str
    periods: List[int]
    prefix: Optional[str] = None   # defaults to "<column>_lag"

    def output_names(self) -> List[str]:
        prefix = self.prefix or f"{self.column}_lag"
        return [f"{prefix}_{p}" for p in self.periods]

    def validate(self) -> None:
        if not self.periods:
            raise ValueError(f"[{self.column}] lag periods cannot be empty.")
        if any(p < 1 for p in self.periods):
            raise ValueError(f"[{self.column}] lag periods must be >= 1.")


@dataclass
class RollingSpec:
    """
    Rolling statistics of one column within each series.

    Always computed on the value SHIFTED by one period, so a row never sees its
    own target. Dropping that shift is the classic way to leak the label into
    the features.
    """

    column: str
    windows: List[int]
    stats: List[str] = field(default_factory=lambda: ["mean"])
    prefix: Optional[str] = None

    def output_names(self) -> List[str]:
        prefix = self.prefix or self.column
        return [f"{prefix}_rolling_{stat}_{w}"
                for stat in self.stats for w in self.windows]

    def validate(self) -> None:
        bad = [s for s in self.stats if s not in VALID_ROLLING_STATS]
        if bad:
            raise ValueError(
                f"[{self.column}] unknown rolling stats {bad}; "
                f"valid: {VALID_ROLLING_STATS}"
            )
        if any(w < 1 for w in self.windows):
            raise ValueError(f"[{self.column}] rolling windows must be >= 1.")


@dataclass
class PointInTimeSpec:
    """
    A statistic over a series' PRIOR rows only.

    Unlike RollingSpec, which works on a resampled grid, this operates row by
    row in time order and is used when the grain is already one row per event.

    Every statistic is computed on values SHIFTED by one row, so the current
    row's own outcome is never inside its own feature. That is precisely the
    bug in the existing supplier_delay_features table, where a vendor with one
    historical order has vendor_avg_delay equal to that order's own delay.
    """

    name: str                      # output column
    column: str                    # source column, usually the outcome
    stat: str                      # mean | std | sum | count | min | max | rate
    window: Optional[int] = None   # rows; None = expanding (all prior rows)

    # stat="rate": fraction of prior rows where column > threshold.
    threshold: Optional[float] = None

    # Value for rows with no history (the first order from a vendor).
    fill_value: float = 0.0

    def validate(self) -> None:
        valid = ("mean", "std", "sum", "count", "min", "max", "rate")
        if self.stat not in valid:
            raise ValueError(f"[{self.name}] stat must be one of {valid}.")
        if self.stat == "rate" and self.threshold is None:
            raise ValueError(f"[{self.name}] stat='rate' requires a threshold.")
        if self.window is not None and self.window < 1:
            raise ValueError(f"[{self.name}] window must be >= 1 or None.")


@dataclass
class LabelSpec:
    """
    Derives a categorical label by binning a continuous column.

    Used for classification: a delay in days becomes a risk class.
    `bins` are upper bounds, `labels` the class names; len(labels) == len(bins)+1
    because the last class is everything above the final bound.
    """

    name: str                      # output column, e.g. "risk_level"
    source_column: str             # source column
    bins: List[float]              # ascending upper bounds; EMPTY = already categorical
    labels: List[str]              # class names
    encode: bool = True            # also emit <name>_encoded as 0..n-1

    @property
    def is_binned(self) -> bool:
        """
        True when the label is derived by cutting a continuous column.

        With bins empty, source_column is already categorical and `labels`
        simply fixes the class ORDER, so the integer encoding stays stable
        between training and scoring. Without a fixed order, pandas would
        assign codes alphabetically and a model trained on one encoding would
        be scored against another.
        """
        return bool(self.bins)

    def validate(self) -> None:
        if len(set(self.labels)) != len(self.labels):
            raise ValueError(f"[{self.name}] duplicate class labels.")
        if not self.labels:
            raise ValueError(f"[{self.name}] labels cannot be empty.")

        if self.is_binned:
            if len(self.labels) != len(self.bins) + 1:
                raise ValueError(
                    f"[{self.name}] binned labels need len(labels) == "
                    f"len(bins)+1; got {len(self.labels)} and {len(self.bins)}."
                )
            if list(self.bins) != sorted(self.bins):
                raise ValueError(f"[{self.name}] bins must be ascending.")

    def encoded_name(self) -> str:
        return f"{self.name}_encoded"


@dataclass
class OneHotSpec:
    """
    Expand a low-cardinality categorical into 0/1 flag columns.

    Needed because a model trained on pandas Categorical columns cannot be
    served over HTTP: JSON has no category dtype, so the serving container
    receives plain strings and LightGBM rejects them with "train and valid
    dataset categorical_feature do not match". Integer flags survive JSON
    unchanged, so the same frame works locally and through an endpoint.

    `categories` is explicit and fixed: a category absent from one batch would
    otherwise silently change the column set between training and scoring.
    """

    column: str
    categories: List[str]
    prefix: Optional[str] = None
    drop_original: bool = True
    # Rows whose value is not in `categories` get all-zero flags.
    other_flag: bool = True

    def output_names(self) -> List[str]:
        prefix = self.prefix or self.column
        names = [f"{prefix}_{c}" for c in self.categories]
        if self.other_flag:
            names.append(f"{prefix}_other")
        return names

    def validate(self) -> None:
        if not self.categories:
            raise ValueError(f"[{self.column}] categories cannot be empty.")
        if len(set(self.categories)) != len(self.categories):
            raise ValueError(f"[{self.column}] duplicate categories.")


@dataclass
class CalendarSpec:
    """Calendar parts derived from the time column."""

    year: bool = True
    month: bool = True
    quarter: bool = True
    week_of_year: bool = True
    week_of_month: bool = True
    day_of_week: bool = False
    boundary_flags: bool = True        # month/quarter/year start and end
    days_from_start: bool = True


@dataclass
class FeatureStoreSpec:
    """Where the features land."""

    # Unity Catalog feature table. Written through the Feature Store client
    # when use_feature_store, otherwise as a plain Delta table.
    table_name: str
    primary_keys: List[str]
    description: str = ""
    use_feature_store: bool = True
    timestamp_keys: List[str] = field(default_factory=list)

    def validate(self) -> None:
        if self.table_name.count(".") != 2:
            raise ValueError(
                f"table_name must be catalog.schema.table, got '{self.table_name}'."
            )
        if "=" in self.table_name or self.table_name.endswith("."):
            raise ValueError(
                f"table_name looks malformed: '{self.table_name}'."
            )
        if not self.primary_keys:
            raise ValueError("primary_keys cannot be empty.")


@dataclass
class TargetTableSpec:
    """Where the label lands — kept out of the feature table on purpose."""

    table_name: str
    target_col: str
    merge_keys: List[str]

    def validate(self) -> None:
        if self.table_name.count(".") != 2:
            raise ValueError(
                f"table_name must be catalog.schema.table, got '{self.table_name}'."
            )
        if not self.merge_keys:
            raise ValueError("merge_keys cannot be empty.")


@dataclass
class HoldoutSpec:
    """
    Rows withheld from training and kept for checking the deployed model.

    Split by time, not at random: the holdout is the most recent rows, which
    is the only split that tells you how the model behaves on orders it could
    not have seen. A random split leaks future periods into training and
    flatters the score.
    """

    train_rows: int                       # rows used for training
    table_name: str                       # where the holdout lands
    strategy: str = "latest"              # latest | oldest

    # The holdout keeps its label — it is scored against the endpoint later.
    keep_label: bool = True

    def validate(self) -> None:
        if self.train_rows < 1:
            raise ValueError("train_rows must be >= 1")
        if self.strategy not in ("latest", "oldest"):
            raise ValueError(
                f"strategy must be 'latest' or 'oldest', got '{self.strategy}'."
            )
        if self.table_name.count(".") != 2:
            raise ValueError(
                f"table_name must be catalog.schema.table, got '{self.table_name}'."
            )


@dataclass
class FeatureSetConfig:
    name: str

    source_table: str

    # The raw timestamp column READ from source_table.
    time_column: str

    # Pandas offset alias controlling the resample bucket:
    #   "W-MON" weeks starting Monday | "MS" month start | "D" daily
    freq: str

    # Name the bucketed period gets in the output. This column is CREATED by
    # the build; it does not exist in the source table.
    out_time_column: str = "week"

    # Extra tables loaded ONLY to compute history, then dropped from the
    # output. A validation set built in isolation gives every row an empty
    # item history, because the earlier orders for that item live in the
    # training table — the score would then be wrong for a reason unrelated to
    # the model. Listing the training table here gives validation rows the
    # history they would genuinely have in production.
    history_tables: List[str] = field(default_factory=list)

    # Grouping that defines one row of output.
    group_cols: List[str] = field(default_factory=list)
    # Subset of group_cols identifying one time series for lags/rollings.
    series_cols: List[str] = field(default_factory=list)

    # "aggregate" — resample and group many source rows into one output row.
    # "row_level" — keep one output row per source row; no resampling. Use this
    #               when the source is already at the grain you model on, such
    #               as one row per purchase order.
    mode: str = "aggregate"

    # row_level only: source columns carried through unchanged.
    passthrough_cols: List[str] = field(default_factory=list)

    # row_level only: history features computed from prior rows of the series.
    point_in_time: List[PointInTimeSpec] = field(default_factory=list)

    # Categoricals expanded to 0/1 flags so the frame is servable over JSON.
    one_hot: List[OneHotSpec] = field(default_factory=list)

    # Columns that are numbers but arrive as text or Decimal. Coerced HERE
    # rather than at training time, so the feature table itself is clean —
    # otherwise the endpoint would receive strings and the model would reject
    # them, even though local training had quietly cast them.
    numeric_cols: List[str] = field(default_factory=list)

    # Derived categorical label (classification).
    label: Optional[LabelSpec] = None

    aggregations: List[AggregationSpec] = field(default_factory=list)
    lags: List[LagSpec] = field(default_factory=list)
    rollings: List[RollingSpec] = field(default_factory=list)
    calendar: CalendarSpec = field(default_factory=CalendarSpec)

    # Columns to express as a share of another column, after aggregation:
    # {"consumer_pct": ("consumer_orders", "total_orders")}. The numerators are
    # dropped once the ratio exists.
    ratios: Dict[str, Tuple[str, str]] = field(default_factory=dict)
    drop_ratio_numerators: bool = True

    # Only rows strictly before this are used (hold out recent data).
    max_source_date: Optional[str] = None

    # Rows with any NaN are dropped — lags and rollings make the first rows of
    # every series incomplete.
    dropna: bool = True

    feature_store: Optional[FeatureStoreSpec] = None
    target_table: Optional[TargetTableSpec] = None

    # Rows reserved for post-deployment checks rather than training.
    holdout: Optional[HoldoutSpec] = None

    def validate(self) -> None:
        if self.mode not in ("aggregate", "row_level"):
            raise ValueError(
                f"[{self.name}] mode must be 'aggregate' or 'row_level'."
            )

        if self.label:
            self.label.validate()
        if self.holdout:
            self.holdout.validate()
        for spec in self.point_in_time:
            spec.validate()
        for spec in self.one_hot:
            spec.validate()

        if self.mode == "row_level":
            if not self.passthrough_cols:
                raise ValueError(
                    f"[{self.name}] row_level mode needs passthrough_cols — "
                    f"the source columns to keep as features."
                )
            if self.aggregations:
                raise ValueError(
                    f"[{self.name}] row_level mode does not aggregate; move "
                    f"those columns to passthrough_cols."
                )
            if not self.series_cols:
                raise ValueError(
                    f"[{self.name}] row_level mode needs series_cols to order "
                    f"and group the point-in-time history."
                )
            return

        if not self.group_cols:
            raise ValueError(f"[{self.name}] group_cols cannot be empty.")
        unknown = [c for c in self.series_cols if c not in self.group_cols]
        if unknown:
            raise ValueError(
                f"[{self.name}] series_cols {unknown} are not in group_cols "
                f"{self.group_cols} — a series must be a subset of the grain."
            )
        if not self.aggregations:
            raise ValueError(f"[{self.name}] no aggregations configured.")

        names = [a.name for a in self.aggregations]
        if len(names) != len(set(names)):
            raise ValueError(f"[{self.name}] duplicate aggregation names: {names}")
        for agg in self.aggregations:
            agg.validate()
        for lag in self.lags:
            lag.validate()
            if lag.column not in names:
                raise ValueError(
                    f"[{self.name}] lag column '{lag.column}' is not produced by "
                    f"any aggregation. Available: {names}"
                )
        for rolling in self.rollings:
            rolling.validate()
            if rolling.column not in names:
                raise ValueError(
                    f"[{self.name}] rolling column '{rolling.column}' is not "
                    f"produced by any aggregation. Available: {names}"
                )
        for out, (num, den) in self.ratios.items():
            missing = [c for c in (num, den) if c not in names]
            if missing:
                raise ValueError(f"[{self.name}] ratio '{out}' references {missing}.")

        if self.feature_store:
            self.feature_store.validate()
            missing = [k for k in self.feature_store.primary_keys
                       if k not in self.group_cols + [self.out_time_column]]
            if missing:
                raise ValueError(
                    f"[{self.name}] feature store primary_keys {missing} are not "
                    f"part of the output grain."
                )
        if self.target_table:
            self.target_table.validate()
            if self.label and self.target_table.target_col in (
                    self.label.name, self.label.encoded_name()):
                pass          # the label is derived, not aggregated
            elif self.target_table.target_col not in names:
                raise ValueError(
                    f"[{self.name}] target_col '{self.target_table.target_col}' "
                    f"is not produced by any aggregation."
                )


def outputs_from_use_case(use_case: str) -> Tuple[FeatureStoreSpec, TargetTableSpec]:
    """
    Build the output specs from a use case in mlops_config.

    The feature table this job writes IS the feature table training reads, and
    the target table it writes IS the one registration joins for actuals. Take
    both from SharedConfig so there is exactly one place to change them.
    """
    shared: SharedConfig = get_use_case(use_case).shared

    if not shared.target_table:
        raise ValueError(
            f"Use case '{use_case}' has no target_table — its label already "
            f"lives in the feature table, so there is nothing separate to write."
        )

    feature_store = FeatureStoreSpec(
        table_name=shared.feature_table,
        primary_keys=list(shared.join_keys),
        description=f"Features for {shared.name}",
        use_feature_store=False,       # plain Delta unless you want FS lineage
    )
    target_table = TargetTableSpec(
        table_name=shared.target_table,
        target_col=shared.source_label_col,
        merge_keys=list(shared.join_keys),
    )
    return feature_store, target_table


# ══════════════════════════════════════════════════════════════════════════
# Feature sets — built from the dictionaries in src/config/feature_config.py
# ══════════════════════════════════════════════════════════════════════════
# Each entry of feature_config.FEATURE_SETS is a dict shaped like
# FeatureSetConfig; nested dicts/lists become the nested specs
# (AggregationSpec, LagSpec, RollingSpec, PointInTimeSpec, OneHotSpec, ...).
FEATURE_SETS: Dict[str, FeatureSetConfig] = {
    name: build(FeatureSetConfig, spec) for name, spec in _cfg.FEATURE_SETS.items()
}


def get_feature_set(name: Optional[str] = None) -> FeatureSetConfig:
    key = name or DEFAULT_FEATURE_SET
    try:
        cfg = FEATURE_SETS[key]
    except KeyError:
        raise ValueError(
            f"Unknown feature set '{key}'. Configured: {sorted(FEATURE_SETS)}"
        ) from None
    cfg.validate()
    return cfg