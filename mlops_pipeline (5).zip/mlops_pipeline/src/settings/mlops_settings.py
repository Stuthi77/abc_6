"""
mlops_settings.py
-----------------
The code behind src/config/mlops_config.py: dataclasses, validation, and the
derived views. The INPUTS (use cases, search spaces, defaults) live in
src/config/mlops_config.py as plain dictionaries; this module turns them into
the typed objects training, registration and serving read.

Why one file: the same fact used to live in three places — the experiment path,
the feature table, and the dropped-column list — and every time they drifted
apart the pipeline failed somewhere downstream. A UseCase states each fact once
and the three stages derive their own view of it.

    USE_CASES["delay_days"]
        .shared        tables, columns, experiment, model name   <- stated once
        .training      splits, search space
        .registration  metric, thresholds, baseline window, aliases
        .serving       endpoint, workload, AI Gateway

Derived views (do not edit — they are built from the above):
    training_config("delay_days")       -> TrainingConfig
    registration_pipeline("delay_days") -> PipelineConfig
    serving_config("delay_days")        -> ServingConfig
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

from src.config import mlops_config as _cfg
from src.config.mlops_config import (           # inputs, re-exported
    CLASSIFICATION_SEARCH_SPACE, DEFAULT_SEARCH_SPACE, DEFAULT_USE_CASE,
)
from src.settings.builder import build


METRIC_DIRECTIONS: Dict[str, str] = {
    # Regression — lower is better, except r2.
    "rmse": "minimize",
    "mae": "minimize",
    "mape": "minimize",
    "wmape": "minimize",
    "smape": "minimize",
    "r2": "maximize",

    # Classification — higher is better, except log_loss.
    "accuracy": "maximize",
    "balanced_accuracy": "maximize",
    "f1_macro": "maximize",
    "f1_weighted": "maximize",
    "precision_macro": "maximize",
    "recall_macro": "maximize",
    "roc_auc_ovr": "maximize",
    "log_loss": "minimize",
}

# Metrics that only make sense for one task, used to validate a SearchConfig.
REGRESSION_METRICS = {"rmse", "mae", "mape", "wmape", "smape", "r2"}
CLASSIFICATION_METRICS = {
    "accuracy", "balanced_accuracy", "f1_macro", "f1_weighted",
    "precision_macro", "recall_macro", "roc_auc_ovr", "log_loss",
}


@dataclass
class DataConfig:
    """Where the training data comes from and what the columns mean."""

    feature_table: str

    # Where the label comes from.
    #   target_table set   -> join it on join_keys and rename source_label_col
    #   target_table None  -> target_col already exists in feature_table
    target_table: Optional[str] = None
    join_keys: List[str] = field(default_factory=list)
    source_label_col: Optional[str] = None
    target_col: str = "total_cost"

    # How to obtain the event date.
    #   "column" -> date_column is a real DATE/TIMESTAMP column
    #   "parts"  -> compose from date_parts = (year_col, month_col, day_col)
    date_from: str = "column"
    date_column: Optional[str] = None
    date_parts: Optional[Tuple[str, str, str]] = None

    # Name the resolved date gets in the pandas frame. This is CREATED by the
    # code, not read from the table, and is excluded from the feature matrix.
    date_col: str = "event_date"

    # Rows before this are sentinels (1900-01-01 placeholders) and are dropped.
    min_valid_date: str = "2000-01-01"

    # Columns excluded from the feature matrix (identifiers, target, date).
    drop_cols: List[str] = field(default_factory=list)

    # Categorical features — passed natively to each model, no one-hot.
    cat_cols: List[str] = field(default_factory=list)

    # Columns force-cast to numeric after the join.
    numeric_cols: List[str] = field(default_factory=list)

    # Identifier columns attached to the logged prediction CSV.
    id_cols: List[str] = field(default_factory=list)

    def validate(self) -> None:
        if self.target_table:
            if not self.join_keys:
                raise ValueError("join_keys are required when target_table is set.")
            if not self.source_label_col:
                raise ValueError("source_label_col is required when target_table is set.")

        if self.date_from == "column":
            if not self.date_column:
                raise ValueError("date_from='column' requires date_column.")
        elif self.date_from == "parts":
            if not self.date_parts or len(self.date_parts) != 3:
                raise ValueError(
                    "date_from='parts' requires date_parts=(year_col, month_col, day_col)."
                )
        else:
            raise ValueError(
                f"date_from must be 'column' or 'parts', got '{self.date_from}'."
            )

    def date_source_columns(self) -> List[str]:
        """Raw table columns feeding the event date."""
        return [self.date_column] if self.date_from == "column" else list(self.date_parts)

    def all_drop_cols(self) -> List[str]:
        """Everything kept out of the feature matrix."""
        return list(dict.fromkeys(
            list(self.drop_cols) + [self.target_col, self.date_col]
        ))

    def feature_dtype_report(self, df) -> Dict[str, List[str]]:
        """Columns a gradient-boosting model cannot consume as-is."""
        drop = set(self.all_drop_cols())
        cats = set(self.cat_cols)
        dt, obj = [], []
        for col, dtype in df.dtypes.items():
            if col in drop or col in cats:
                continue
            name = str(dtype)
            if name.startswith(("datetime", "timedelta")):
                dt.append(col)
            # pandas < 3 reports text as "object"; pandas >= 3 as "str".
            elif name in ("object", "str") or name.startswith("string"):
                obj.append(col)
        return {"datetime": dt, "object": obj}


@dataclass
class SplitConfig:
    """Rolling time-based train/validation windows."""

    n_splits: int = 2
    val_weeks: int = 8
    step_weeks: int = 4

    # A window with fewer rows than this produces meaningless metrics.
    min_test_rows: int = 50

    # Weight range across splits; the most recent window gets the highest.
    weight_low: float = 0.3
    weight_high: float = 1.0

    def validate(self) -> None:
        if self.n_splits < 1:
            raise ValueError("n_splits must be >= 1")
        if self.val_weeks < 1 or self.step_weeks < 1:
            raise ValueError("val_weeks and step_weeks must be >= 1")


@dataclass
class SearchConfig:
    """Optuna search settings."""

    # "regression" or "classification". Decides which estimator class each
    # model name maps to, which metrics are computed, and the monitor's
    # problem_type downstream.
    task: str = "regression"

    models: List[str] = field(
        default_factory=lambda: ["xgboost", "lightgbm", "catboost", "random_forest"]
    )
    n_trials: int = 20
    primary_metric: str = "rmse"
    metric_names: List[str] = field(
        default_factory=lambda: ["rmse", "mae", "mape", "wmape", "smape", "r2"]
    )

    # MedianPruner settings.
    pruner_startup_trials: int = 5
    pruner_warmup_steps: int = 0
    pruner_interval_steps: int = 1

    def direction(self) -> str:
        """Optimisation direction, derived from the metric — never hardcoded."""
        try:
            return METRIC_DIRECTIONS[self.primary_metric]
        except KeyError:
            raise ValueError(
                f"No direction known for primary_metric '{self.primary_metric}'. "
                f"Add it to METRIC_DIRECTIONS. Known: {sorted(METRIC_DIRECTIONS)}"
            ) from None

    def validate(self) -> None:
        if self.task not in ("regression", "classification"):
            raise ValueError(
                f"task must be 'regression' or 'classification', got '{self.task}'."
            )
        if self.primary_metric not in self.metric_names:
            raise ValueError(
                f"primary_metric '{self.primary_metric}' must be in metric_names "
                f"{self.metric_names}"
            )
        # Catch a regression metric on a classification task and vice versa —
        # it would otherwise fail deep inside the first trial.
        allowed = (CLASSIFICATION_METRICS if self.task == "classification"
                   else REGRESSION_METRICS)
        wrong = [m for m in self.metric_names if m not in allowed]
        if wrong:
            raise ValueError(
                f"Metrics {wrong} are not valid for task='{self.task}'. "
                f"Valid: {sorted(allowed)}"
            )
        self.direction()
        if self.n_trials < 1:
            raise ValueError("n_trials must be >= 1")


@dataclass
class MLflowConfig:
    experiment_path: str
    model_artifact_path: str = "model"
    log_feature_importance: bool = True
    log_predictions: bool = True
    log_datasets: bool = True
    top_n_importance: int = 30


# Search spaces (DEFAULT_SEARCH_SPACE, CLASSIFICATION_SEARCH_SPACE) are inputs:
# they live in src/config/mlops_config.py and are imported above.


@dataclass
class TrainingConfig:
    name: str
    data: DataConfig
    mlflow: MLflowConfig
    split: SplitConfig = field(default_factory=SplitConfig)
    search: SearchConfig = field(default_factory=SearchConfig)
    search_space: Dict[str, Dict[str, Any]] = field(
        default_factory=lambda: {k: dict(v) for k, v in DEFAULT_SEARCH_SPACE.items()}
    )

    def validate(self) -> None:
        self.data.validate()
        self.split.validate()
        self.search.validate()
        missing = [m for m in self.search.models if m not in self.search_space]
        if missing:
            raise ValueError(
                f"[{self.name}] no search space for {missing}. "
                f"Defined: {sorted(self.search_space)}"
            )


@dataclass
class TableConfig:
    """Where data lives and what the columns are called."""

    feature_table: str
    baseline_table: str
    actual_table: Optional[str] = None

    # ---- how to obtain an event DATE from the feature table ----
    #   "auto"          date_col is already DATE/TIMESTAMP, or STRING+date_format
    #   "parts"         compose from date_parts = (year_col, month_col, day_col)
    #   "yyyymmdd_int"  INT packed as 20240131
    #   "unix_days"     INT days since 1970-01-01
    #   "unix_seconds"  INT/BIGINT epoch seconds
    date_kind: str = "auto"

    # Used by every kind except "parts".
    date_col: Optional[str] = None

    # Used only when date_kind="parts": (year_col, month_col, day_col).
    date_parts: Optional[Sequence[str]] = None

    # Used only when date_kind="auto" and the column is a STRING.
    date_format: Optional[str] = None

    # Rows with a composed date before this are treated as missing and
    # excluded from the test window. Set to None to keep everything.
    min_valid_date: Optional[str] = None

    # ---- joining predictions to actuals ----
    join_keys: List[str] = field(default_factory=list)
    label_col: str = "target"

    # ---- scoring ----
    prediction_col: str = "prediction_raw"
    test_months: int = 3

    # How the baseline window is placed.
    #   "fixed"    -> always the last test_months before MAX(date)
    #   "anchored" -> walk the end date back until the window holds at least
    #                 min_baseline_rows, like training's split anchor. Use this
    #                 when the data thins out at the tail, which otherwise
    #                 yields a handful of rows and a useless reference
    #                 distribution.
    baseline_window_mode: str = "anchored"

    # Minimum rows for a usable reference distribution.
    min_baseline_rows: int = 200

    # Cap on how far back "anchored" will search from MAX(date).
    max_anchor_lookback_months: int = 24

    # Columns dropped before model.predict() — IDs, labels, leakage.
    exclude_from_features: List[str] = field(default_factory=list)

    def validate(self) -> None:
        valid_kinds = ("auto", "parts", "yyyymmdd_int", "unix_days", "unix_seconds")
        if self.date_kind not in valid_kinds:
            raise ValueError(f"date_kind must be one of {valid_kinds}, got '{self.date_kind}'")

        if self.date_kind == "parts":
            if not self.date_parts or len(self.date_parts) != 3:
                raise ValueError(
                    "date_kind='parts' requires date_parts=(year_col, month_col, day_col)"
                )
        elif not self.date_col:
            raise ValueError(f"date_kind='{self.date_kind}' requires date_col")

        if self.baseline_window_mode not in ("fixed", "anchored"):
            raise ValueError(
                f"baseline_window_mode must be 'fixed' or 'anchored', "
                f"got '{self.baseline_window_mode}'."
            )
        if self.min_baseline_rows < 1:
            raise ValueError("min_baseline_rows must be >= 1")
        if self.max_anchor_lookback_months < self.test_months:
            raise ValueError(
                f"max_anchor_lookback_months ({self.max_anchor_lookback_months}) "
                f"must be >= test_months ({self.test_months})."
            )

        if self.feature_table == self.baseline_table:
            raise ValueError(
                f"baseline_table must differ from feature_table — the baseline is "
                f"overwritten on every run and would destroy '{self.feature_table}'."
            )
        if self.actual_table and self.actual_table == self.baseline_table:
            raise ValueError("baseline_table must differ from actual_table.")

    def resolved_join_keys(self) -> List[str]:
        if not self.join_keys:
            raise ValueError("TableConfig.join_keys is empty — set the shared grain.")
        return self.join_keys


# ──────────────────────────────────────────────────────────────────────────
# One registrable model
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class ModelSpec:
    """
    source="experiment" -> best run in experiment_path by `metric`
    source="run"        -> a specific run_id
    source="file"       -> serialized file (.pkl .joblib .ubj .json .bst
                           .cb .cbm .txt); logged to a fresh run, then registered
    """

    model_name: str                       # UC name without catalog.schema

    # Give metric OR metric_pattern (pattern wins when the exact name is absent).
    #
    # metric_pattern exists because runs often log window-stamped metric keys
    # like "rmse_val_2025-01-10_2025-03-07" — the name changes every run, so no
    # fixed string can match. Anchor the pattern so near-misses don't match:
    # "^rmse_val_" does NOT match "wmape_val_...".
    metric: Optional[str] = None
    metric_pattern: Optional[str] = None

    # Which key to use when the pattern matches several. "latest" takes the
    # last after sorting, which is the most recent window for ISO date stamps.
    metric_select: str = "latest"         # "latest" | "first"

    metric_direction: str = "minimize"    # "minimize" | "maximize"
    improvement_threshold: float = 0.0    # 0.02 == must be 2% better to win

    # Runs pulled from the experiment before picking the best. Ranking happens
    # client-side because MLflow's server-side order_by does not exclude runs
    # that lack the metric.
    search_max_results: int = 200

    # Optional MLflow filter narrowing the candidate runs. Training logs
    # stage='best_model_refit' on the parent run that holds the model, so
    #     run_filter="tags.stage = 'best_model_refit'"
    # skips every nested hyperparameter trial outright.
    run_filter: Optional[str] = None

    # Ignore runs that are not FINISHED — failed and killed trials otherwise
    # compete on whatever partial metrics they managed to log.
    require_finished: bool = True

    # Artifact directory holding the model inside a run. Hyperparameter trials
    # usually log metrics only, so the best-scoring run often has NO model —
    # candidates without one are skipped during ranking.
    model_artifact_path: str = "model"

    # How many ranked candidates to probe for a model artifact before giving
    # up. Each probe is an API call, so this caps the cost.
    max_artifact_checks: int = 25

    source: str = "experiment"
    experiment_path: Optional[str] = None  # filled from PipelineConfig if blank
    run_id: Optional[str] = None

    # --- source="file" only ---
    model_path: Optional[str] = None
    model_format: Optional[str] = None     # override extension sniffing
    loader_kwargs: Dict[str, Any] = field(default_factory=dict)
    metrics: Dict[str, float] = field(default_factory=dict)
    params: Dict[str, Any] = field(default_factory=dict)
    tags: Dict[str, str] = field(default_factory=dict)

    create_baseline: bool = True

    def validate(self) -> None:
        if self.metric_direction not in ("minimize", "maximize"):
            raise ValueError(
                f"[{self.model_name}] metric_direction must be 'minimize' or 'maximize'"
            )
        if self.improvement_threshold < 0:
            raise ValueError(f"[{self.model_name}] improvement_threshold must be >= 0")
        if not self.metric and not self.metric_pattern:
            raise ValueError(
                f"[{self.model_name}] set metric (exact key) or metric_pattern "
                f"(regex, e.g. '^rmse_val_') — one is required."
            )
        if self.metric_select not in ("latest", "first"):
            raise ValueError(f"[{self.model_name}] metric_select must be 'latest' or 'first'")
        if self.source not in ("experiment", "run", "file"):
            raise ValueError(f"[{self.model_name}] source must be experiment|run|file")
        if self.source == "experiment" and not self.experiment_path:
            raise ValueError(f"[{self.model_name}] source='experiment' needs experiment_path")
        if self.source == "run" and not self.run_id:
            raise ValueError(f"[{self.model_name}] source='run' needs run_id")
        if self.source == "file":
            if not self.model_path:
                raise ValueError(f"[{self.model_name}] source='file' needs model_path")
            if not self.metric:
                raise ValueError(
                    f"[{self.model_name}] source='file' needs an exact metric name "
                    f"(metric_pattern cannot be matched against a dict you supply)."
                )
            if self.metric not in self.metrics:
                raise ValueError(
                    f"[{self.model_name}] source='file' needs metrics['{self.metric}'] "
                    f"to compare against the Champion. Got: {sorted(self.metrics)}"
                )


# ──────────────────────────────────────────────────────────────────────────
# One use case
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class RegistryConfig:
    """Unity Catalog alias names and version-tagging policy."""

    champion_alias: str = "champion"
    challenger_alias: str = "challenger"

    # Copy the run's metrics onto the model version as tags.
    copy_metrics_as_tags: bool = True
    # Cap it — a run with window-stamped metrics can carry dozens, and every
    # one becomes a UC tag. The comparison metric is always kept.
    max_metric_tags: int = 20

    # Tags added to every version this pipeline registers.
    extra_tags: Dict[str, str] = field(default_factory=dict)

    def validate(self) -> None:
        if not self.champion_alias or not self.challenger_alias:
            raise ValueError("champion_alias and challenger_alias cannot be empty.")
        if self.champion_alias == self.challenger_alias:
            raise ValueError(
                f"champion_alias and challenger_alias must differ "
                f"(both '{self.champion_alias}')."
            )
        if self.max_metric_tags < 1:
            raise ValueError("max_metric_tags must be >= 1")


@dataclass
class PipelineConfig:
    name: str
    catalog: str
    schema: str
    experiment_path: str
    tables: TableConfig
    models: Dict[str, ModelSpec]
    registry: RegistryConfig = field(default_factory=RegistryConfig)

    def validate(self) -> None:
        self.tables.validate()
        self.registry.validate()
        for key, spec in self.models.items():
            if spec.source == "experiment" and not spec.experiment_path:
                spec.experiment_path = self.experiment_path   # inherit
            spec.validate()
        if not self.models:
            raise ValueError(f"Pipeline '{self.name}' has no models configured.")


VALID_WORKLOAD_SIZES = ("Small", "Medium", "Large")
VALID_WORKLOAD_TYPES = ("CPU", "GPU_SMALL", "GPU_MEDIUM", "GPU_LARGE", "MULTIGPU_MEDIUM")


@dataclass
class ServedModelSpec:
    """One model behind an endpoint."""

    # Short name for this entity within the endpoint; also the traffic route key.
    name: str

    # Full Unity Catalog name: catalog.schema.model
    model_name: str

    # Pin EITHER a version OR an alias. An alias is resolved to the version it
    # points at when the endpoint is deployed — serving pins a concrete version,
    # so moving the alias later does NOT move the endpoint until you redeploy.
    version: Optional[str] = None
    alias: Optional[str] = None

    traffic_percentage: int = 100

    workload_size: str = "Small"
    workload_type: str = "CPU"
    # Small endpoints cost nothing while idle but add cold-start latency.
    scale_to_zero_enabled: bool = True

    environment_vars: Dict[str, str] = field(default_factory=dict)

    def validate(self) -> None:
        if bool(self.version) == bool(self.alias):
            raise ValueError(
                f"[{self.name}] set exactly one of version or alias "
                f"(got version={self.version!r}, alias={self.alias!r})."
            )
        if self.model_name.count(".") != 2:
            raise ValueError(
                f"[{self.name}] model_name must be catalog.schema.model, "
                f"got '{self.model_name}'."
            )
        if self.workload_size not in VALID_WORKLOAD_SIZES:
            raise ValueError(
                f"[{self.name}] workload_size must be one of "
                f"{VALID_WORKLOAD_SIZES}, got '{self.workload_size}'."
            )
        if self.workload_type not in VALID_WORKLOAD_TYPES:
            raise ValueError(
                f"[{self.name}] workload_type must be one of "
                f"{VALID_WORKLOAD_TYPES}, got '{self.workload_type}'."
            )
        if not 0 <= self.traffic_percentage <= 100:
            raise ValueError(
                f"[{self.name}] traffic_percentage must be 0-100, "
                f"got {self.traffic_percentage}."
            )


@dataclass
class InferenceTableConfig:
    """Capture of request/response payloads into Delta."""

    enabled: bool = False
    catalog_name: Optional[str] = None
    schema_name: Optional[str] = None
    table_name_prefix: Optional[str] = None

    def validate(self) -> None:
        if not self.enabled:
            return
        missing = [f for f in ("catalog_name", "schema_name", "table_name_prefix")
                   if not getattr(self, f)]
        if missing:
            raise ValueError(
                f"Inference tables are enabled but {missing} not set."
            )


# Rate-limit windows and scopes Databricks accepts.
VALID_RENEWAL_PERIODS = ("minute",)
VALID_RATE_LIMIT_KEYS = ("user", "endpoint")


@dataclass
class RateLimitSpec:
    """A cap on calls, per user or across the whole endpoint."""

    calls: int
    renewal_period: str = "minute"
    key: str = "endpoint"

    def validate(self) -> None:
        if self.calls < 1:
            raise ValueError(f"Rate limit calls must be >= 1, got {self.calls}.")
        if self.renewal_period not in VALID_RENEWAL_PERIODS:
            raise ValueError(
                f"renewal_period must be one of {VALID_RENEWAL_PERIODS}, "
                f"got '{self.renewal_period}'."
            )
        if self.key not in VALID_RATE_LIMIT_KEYS:
            raise ValueError(
                f"Rate limit key must be one of {VALID_RATE_LIMIT_KEYS}, "
                f"got '{self.key}'."
            )


@dataclass
class AIGatewayConfig:
    """
    The AI Gateway block — what the endpoint page shows as Usage monitoring,
    Inference tables and telemetry, and Rate limits.

    This is set through a separate API call from the model config, so it can be
    changed on a live endpoint without redeploying the model.
    """

    # Usage monitoring: per-request counts and latency into a system table.
    usage_tracking_enabled: bool = False

    # Inference tables: full request/response payloads into Delta. This is the
    # Gateway version and supersedes the older auto_capture_config.
    inference_table: InferenceTableConfig = field(default_factory=InferenceTableConfig)

    rate_limits: List[RateLimitSpec] = field(default_factory=list)

    def configured(self) -> bool:
        return bool(
            self.usage_tracking_enabled
            or self.inference_table.enabled
            or self.rate_limits
        )

    def validate(self) -> None:
        self.inference_table.validate()
        for limit in self.rate_limits:
            limit.validate()

        keys = [(l.key, l.renewal_period) for l in self.rate_limits]
        if len(keys) != len(set(keys)):
            raise ValueError(
                f"Duplicate rate limits for the same key/period: {keys}. "
                f"Databricks accepts one limit per (key, renewal_period)."
            )


@dataclass
class ServingConfig:
    endpoint_name: str
    served_models: List[ServedModelSpec]

    # Usage monitoring, inference tables and rate limits.
    ai_gateway: AIGatewayConfig = field(default_factory=AIGatewayConfig)

    tags: Dict[str, str] = field(default_factory=dict)

    # Lower latency for small payloads; not available on every workspace.
    route_optimized: bool = False

    # Endpoint creation/update can take 10-20 minutes on a cold image.
    wait_timeout_minutes: int = 30

    # Redeploy even when the resolved config matches what is already live.
    force_update: bool = False

    def validate(self) -> None:
        if not self.served_models:
            raise ValueError(f"[{self.endpoint_name}] no served_models configured.")

        names = [m.name for m in self.served_models]
        if len(names) != len(set(names)):
            raise ValueError(f"[{self.endpoint_name}] duplicate served model names: {names}")

        for model in self.served_models:
            model.validate()

        total = sum(m.traffic_percentage for m in self.served_models)
        if total != 100:
            raise ValueError(
                f"[{self.endpoint_name}] traffic_percentage must total 100 "
                f"across served models, got {total} "
                f"({ {m.name: m.traffic_percentage for m in self.served_models} })."
            )

        self.ai_gateway.validate()

        if self.wait_timeout_minutes < 1:
            raise ValueError("wait_timeout_minutes must be >= 1")


# ══════════════════════════════════════════════════════════════════════════
# THE SINGLE SOURCE OF TRUTH
# ══════════════════════════════════════════════════════════════════════════
@dataclass
class SharedConfig:
    """
    Facts every stage needs. Stated ONCE here, derived everywhere else.

    These are the values that used to be duplicated across three config files
    and silently drift apart — the experiment path, the feature table, and
    above all drop_cols, which has to match between training and scoring or the
    model signature will not match the frame it is given.
    """

    name: str
    catalog: str
    schema: str

    experiment_path: str
    model_name: str                       # UC name, without catalog.schema

    feature_table: str
    target_table: Optional[str]
    join_keys: List[str]
    source_label_col: Optional[str]
    target_col: str

    date_column: str                      # real DATE/TIMESTAMP column
    min_valid_date: str = "2000-01-01"

    # Excluded from the feature matrix at BOTH training and scoring time.
    drop_cols: List[str] = field(default_factory=list)
    cat_cols: List[str] = field(default_factory=list)
    numeric_cols: List[str] = field(default_factory=list)
    id_cols: List[str] = field(default_factory=list)

    @property
    def full_model_name(self) -> str:
        return f"{self.catalog}.{self.schema}.{self.model_name}"

    def validate(self) -> None:
        if self.target_table and not self.source_label_col:
            raise ValueError(f"[{self.name}] target_table set but source_label_col missing.")
        if self.target_table and not self.join_keys:
            raise ValueError(f"[{self.name}] target_table set but join_keys missing.")


@dataclass
class TrainingStage:
    split: SplitConfig = field(default_factory=SplitConfig)
    search: SearchConfig = field(default_factory=SearchConfig)

    # Left as None, the space matching search.task is used — regression spaces
    # for a regressor, classification spaces for a classifier. Set it only to
    # override the defaults.
    search_space: Optional[Dict[str, Dict[str, Any]]] = None

    def resolved_search_space(self) -> Dict[str, Dict[str, Any]]:
        if self.search_space is not None:
            return self.search_space
        base = (CLASSIFICATION_SEARCH_SPACE if self.search.task == "classification"
                else DEFAULT_SEARCH_SPACE)
        return {k: dict(v) for k, v in base.items()}
    log_feature_importance: bool = True
    log_predictions: bool = True
    log_datasets: bool = True


@dataclass
class RegistrationStage:
    # Fixed metric key the parent refit run logs. Left blank, it is derived
    # from the training primary metric.
    metric: Optional[str] = None
    metric_direction: str = "minimize"
    improvement_threshold: float = 0.0
    run_filter: str = "tags.stage = 'best_model_refit'"
    model_artifact_path: str = "model"

    baseline_table: Optional[str] = None      # defaults to <model_name>_baseline
    test_months: int = 6
    baseline_window_mode: str = "anchored"
    min_baseline_rows: int = 200
    max_anchor_lookback_months: int = 24

    registry: RegistryConfig = field(default_factory=RegistryConfig)


@dataclass
class ServingStage:
    endpoint_name: Optional[str] = None       # defaults to <name>-endpoint
    serve_alias: str = "champion"
    workload_size: str = "Small"
    workload_type: str = "CPU"
    scale_to_zero_enabled: bool = True
    ai_gateway: AIGatewayConfig = field(default_factory=AIGatewayConfig)
    tags: Dict[str, str] = field(default_factory=dict)
    wait_timeout_minutes: int = 30


@dataclass
class UseCase:
    shared: SharedConfig
    training: TrainingStage = field(default_factory=TrainingStage)
    registration: RegistrationStage = field(default_factory=RegistrationStage)
    serving: ServingStage = field(default_factory=ServingStage)

    def validate(self) -> None:
        self.shared.validate()


# ══════════════════════════════════════════════════════════════════════════
# USE CASES — built from the dictionaries in src/config/mlops_config.py
# ══════════════════════════════════════════════════════════════════════════
# Each entry of mlops_config.USE_CASES is a dict shaped like UseCase:
#   {"shared": {...SharedConfig}, "training": {...TrainingStage},
#    "registration": {...RegistrationStage}, "serving": {...ServingStage}}
USE_CASES: Dict[str, UseCase] = {
    name: build(UseCase, spec) for name, spec in _cfg.USE_CASES.items()
}


def resolve_use_case(ref: Any = None) -> UseCase:
    """Accept a UseCase (already overridden by widgets) or a name."""
    if isinstance(ref, UseCase):
        return ref
    return get_use_case(ref)


def get_use_case(name: Optional[str] = None) -> UseCase:
    key = name or DEFAULT_USE_CASE
    try:
        uc = USE_CASES[key]
    except KeyError:
        raise ValueError(f"Unknown use case '{key}'. Configured: {sorted(USE_CASES)}") from None
    uc.validate()
    return uc


# ══════════════════════════════════════════════════════════════════════════
# DERIVED VIEWS — built from the above, never edited directly
# ══════════════════════════════════════════════════════════════════════════
def training_config(name: Any = None) -> TrainingConfig:
    uc = resolve_use_case(name)
    s, t = uc.shared, uc.training

    cfg = TrainingConfig(
        name=s.name,
        data=DataConfig(
            feature_table=s.feature_table,
            target_table=s.target_table,
            join_keys=list(s.join_keys),
            source_label_col=s.source_label_col,
            target_col=s.target_col,
            date_from="column",
            date_column=s.date_column,
            date_col="event_date",
            min_valid_date=s.min_valid_date,
            drop_cols=list(s.drop_cols),
            cat_cols=list(s.cat_cols),
            numeric_cols=list(s.numeric_cols),
            id_cols=list(s.id_cols),
        ),
        mlflow=MLflowConfig(
            experiment_path=s.experiment_path,
            model_artifact_path=uc.registration.model_artifact_path,
            log_feature_importance=t.log_feature_importance,
            log_predictions=t.log_predictions,
            log_datasets=t.log_datasets,
        ),
        split=t.split,
        search=t.search,
        search_space=t.resolved_search_space(),
    )
    cfg.validate()
    return cfg


def registration_metric_key(uc: UseCase) -> str:
    """
    The fixed metric the parent refit run logs.

    Training writes best_weighted_mean_<primary_metric>; deriving it here keeps
    registration pointed at the right key when the training metric changes.
    """
    if uc.registration.metric:
        return uc.registration.metric
    return f"best_weighted_mean_{uc.training.search.primary_metric}"


def registration_pipeline(name: Any = None) -> PipelineConfig:
    uc = resolve_use_case(name)
    s, r = uc.shared, uc.registration

    pipeline = PipelineConfig(
        name=s.name,
        catalog=s.catalog,
        schema=s.schema,
        experiment_path=s.experiment_path,
        tables=TableConfig(
            feature_table=s.feature_table,
            actual_table=s.target_table,
            baseline_table=r.baseline_table or f"{s.catalog}.{s.schema}.{s.model_name}_baseline",
            date_kind="auto",
            date_col=s.date_column,
            date_format=None,
            min_valid_date=s.min_valid_date,
            join_keys=list(s.join_keys),
            label_col=s.target_col,
            prediction_col="prediction_raw",
            test_months=r.test_months,
            baseline_window_mode=r.baseline_window_mode,
            min_baseline_rows=r.min_baseline_rows,
            max_anchor_lookback_months=r.max_anchor_lookback_months,
            # Derived from shared.drop_cols, not restated. This single line is
            # what makes the training/scoring column contract impossible to
            # break by editing one file and forgetting the other.
            exclude_from_features=list(s.drop_cols),
        ),
        models={
            f"{s.name}_best_run": ModelSpec(
                model_name=s.model_name,
                metric=registration_metric_key(uc),
                metric_pattern=None,
                metric_direction=r.metric_direction,
                improvement_threshold=r.improvement_threshold,
                source="experiment",
                experiment_path=s.experiment_path,
                run_filter=r.run_filter,
                require_finished=True,
                model_artifact_path=r.model_artifact_path,
            ),
        },
        registry=r.registry,
    )
    pipeline.validate()
    return pipeline


def serving_config(name: Any = None) -> ServingConfig:
    uc = resolve_use_case(name)
    s, v = uc.shared, uc.serving

    cfg = ServingConfig(
        endpoint_name=v.endpoint_name or f"{s.name.replace('_', '-')}-endpoint",
        served_models=[
            ServedModelSpec(
                name=v.serve_alias,
                model_name=s.full_model_name,
                alias=v.serve_alias,
                traffic_percentage=100,
                workload_size=v.workload_size,
                workload_type=v.workload_type,
                scale_to_zero_enabled=v.scale_to_zero_enabled,
            ),
        ],
        ai_gateway=v.ai_gateway,
        tags=v.tags,
        wait_timeout_minutes=v.wait_timeout_minutes,
    )
    cfg.validate()
    return cfg