"""
job_settings.py
---------------
The code behind src/config/job_config.py: one dataclass per job, validation
against the other registries, and get_job_settings().
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List

from src.config import job_config as _cfg
from src.settings.builder import build

MLOPS_STAGES = ("train", "review", "register", "status", "serve")
MONITORING_STAGES = ("score", "shift_dates", "baseline", "monitor", "drift",
                     "degradation", "sync_dashboard", "visualize",
                     "diagnose_monitor", "rollback")


def _check_stages(job: str, stages: List[str], allowed) -> None:
    if not stages:
        raise ValueError(f"[{job}] 'stages' is empty — nothing to run.")
    unknown = [s for s in stages if s not in allowed]
    if unknown:
        raise ValueError(f"[{job}] unknown stage(s) {unknown}. Allowed: {list(allowed)}")


@dataclass
class FeatureEngineeringJob:
    feature_sets: List[str] = field(default_factory=list)
    dry_run_first: bool = True

    def validate(self) -> None:
        from src.settings.feature_settings import FEATURE_SETS
        if not self.feature_sets:
            raise ValueError("[feature_engineering] 'feature_sets' is empty.")
        unknown = [f for f in self.feature_sets if f not in FEATURE_SETS]
        if unknown:
            raise ValueError(f"[feature_engineering] unknown feature set(s) {unknown}. "
                             f"Configured: {sorted(FEATURE_SETS)}")


@dataclass
class MLOpsProcessJob:
    use_case: str
    stages: List[str] = field(default_factory=lambda: list(MLOPS_STAGES))
    approve_register: bool = False
    approve_serve: bool = False
    skip_baseline: bool = False
    wait_for_endpoint: bool = True

    def validate(self) -> None:
        from src.settings.mlops_settings import USE_CASES
        if self.use_case not in USE_CASES:
            raise ValueError(f"[mlops_process] unknown use case '{self.use_case}'. "
                             f"Configured: {sorted(USE_CASES)}")
        _check_stages("mlops_process", self.stages, MLOPS_STAGES)


@dataclass
class MonitoringJob:
    monitor: str
    stages: List[str] = field(default_factory=lambda: list(MONITORING_STAGES))
    approve_baseline: bool = False
    approve_rollback: bool = False
    recreate_monitor: bool = False
    wait_for_refresh: bool = True
    skip_score_when_replayed: bool = True

    def validate(self) -> None:
        from src.settings.monitoring_settings import MONITORING_CONFIGS
        if self.monitor not in MONITORING_CONFIGS:
            raise ValueError(f"[monitoring] unknown monitor '{self.monitor}'. "
                             f"Configured: {sorted(MONITORING_CONFIGS)}")
        _check_stages("monitoring", self.stages, MONITORING_STAGES)


_JOB_TYPES: Dict[str, type] = {
    "feature_engineering": FeatureEngineeringJob,
    "mlops_process": MLOpsProcessJob,
    "monitoring": MonitoringJob,
}


def get_job_settings(name: str) -> Any:
    """Build and validate the settings of one job from job_config.JOBS."""
    if name not in _JOB_TYPES:
        raise ValueError(f"Unknown job '{name}'. Known: {sorted(_JOB_TYPES)}")
    if name not in _cfg.JOBS:
        raise ValueError(f"Job '{name}' has no entry in job_config.JOBS.")
    settings = build(_JOB_TYPES[name], _cfg.JOBS[name])
    settings.validate()
    return settings
