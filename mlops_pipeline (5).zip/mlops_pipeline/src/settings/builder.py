"""
builder.py
----------
Turns the plain dictionaries in src/config/*.py into the typed dataclasses the
pipeline uses.

The config files hold only inputs (dicts, lists, strings, numbers). Each key
of a dict is a field name of the matching dataclass; nested dicts become
nested dataclasses, guided by the dataclass type hints. A misspelt key fails
here, with the list of valid field names, instead of deep inside a stage.
"""
from __future__ import annotations

import copy
import dataclasses
import typing
from typing import Any, Dict, Type, TypeVar

T = TypeVar("T")


def _convert(hint: Any, value: Any) -> Any:
    """Convert one value to the type described by a type hint."""
    if value is None:
        return None

    if dataclasses.is_dataclass(hint) and isinstance(hint, type):
        if isinstance(value, hint):
            return value
        if isinstance(value, dict):
            return build(hint, value)
        return value

    origin = typing.get_origin(hint)
    args = typing.get_args(hint)

    if origin is typing.Union:                       # Optional[X] / Union[...]
        for arg in args:
            if arg is type(None):
                continue
            if dataclasses.is_dataclass(arg) and isinstance(value, dict):
                return build(arg, value)
        non_none = [a for a in args if a is not type(None)]
        return _convert(non_none[0], value) if len(non_none) == 1 else value

    if origin in (list, typing.List) or str(origin) == "<class 'collections.abc.Sequence'>":
        item = args[0] if args else Any
        converted = [_convert(item, v) for v in value]
        return converted if isinstance(value, list) else type(value)(converted)

    if origin in (dict, typing.Dict) and len(args) == 2:
        return {k: _convert(args[1], v) for k, v in value.items()}

    return value


def build(cls: Type[T], data: Dict[str, Any]) -> T:
    """Build dataclass `cls` from a dict whose keys are its field names."""
    if not isinstance(data, dict):
        raise TypeError(f"{cls.__name__} expects a dict, got {type(data).__name__}.")
    hints = typing.get_type_hints(cls)
    names = {f.name for f in dataclasses.fields(cls) if f.init}
    unknown = sorted(set(data) - names)
    if unknown:
        raise TypeError(
            f"{cls.__name__}: unknown key(s) {unknown}. Valid keys: {sorted(names)}"
        )
    kwargs = {k: _convert(hints.get(k, Any), copy.deepcopy(v)) for k, v in data.items()}
    return cls(**kwargs)


def build_fields(cls: type, data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convert only the keys of `data` that are dataclass-typed fields of `cls`;
    leave every other key as is. Used when a dict is passed to a builder
    function (e.g. from_use_case) rather than straight to a constructor.
    """
    hints = typing.get_type_hints(cls)
    out = {}
    for k, v in data.items():
        out[k] = _convert(hints[k], copy.deepcopy(v)) if k in hints else copy.deepcopy(v)
    return out
