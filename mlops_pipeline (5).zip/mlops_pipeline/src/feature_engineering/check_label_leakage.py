"""
check_label_leakage.py
----------------------
Shows how much of fulfillment_risk_level is recoverable from the columns the
CASE statement that defines it reads.

    python -m src.feature_engineering.check_label_leakage

The label is defined as:

    Available >= BackorderQty              -> Low
    On order > 0 OR In Transit > 0         -> Medium
    Next Expected Receipt <= today + 14    -> Medium
    otherwise                              -> High

so any model given those columns is reproducing a rule you already have. This
script reconstructs the label from them and reports the agreement. Near 100%
means the "model" is a lookup, and the useful task is a different one — see
PREDICTIVE_FRAMING at the bottom.
"""
from __future__ import annotations

import argparse
import logging
import sys

from pyspark.sql import functions as F

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(message)s")
logger = logging.getLogger(__name__)

RAW_TABLE = "dev_platform.mlops.fulfillment_risk_level"

# Columns the CASE statement reads. Anything here hands the model the rule.
LABEL_SOURCE_COLS = [
    "available_qty",
    "backorder_qty",
    "on_order_qty",
    "in_transit_qty",
    "next_expected_receipt",
]

# Derived columns that encode the same comparison in one number.
DERIVED_FROM_LABEL_SOURCES = [
    "supply_gap_qty",          # backorder_qty - available_qty: sign IS the Low rule
    "days_until_fulfillment",  # built from next_expected_receipt
]


def check(spark, table: str = RAW_TABLE) -> dict:
    df = spark.read.table(table)
    total = df.count()
    logger.info("Rows: %d", total)

    label_col = "fulfillment_risk_level"
    if label_col not in df.columns:
        raise ValueError(f"'{table}' has no column '{label_col}'. "
                         f"Available: {sorted(df.columns)}")

    logger.info("\nLabel distribution:")
    for row in df.groupBy(label_col).count().orderBy(F.desc("count")).collect():
        logger.info("  %-32s %6d  (%5.1f%%)",
                    row[label_col], row["count"], 100 * row["count"] / total)

    present = [c for c in LABEL_SOURCE_COLS if c in df.columns]
    missing = [c for c in LABEL_SOURCE_COLS if c not in df.columns]
    if missing:
        logger.warning("Not in the table (cannot test these): %s", missing)
    if not present:
        logger.info("None of the label-source columns are present — nothing to test.")
        return {"reconstructable": None}

    # Rebuild the label from the same columns the CASE statement used.
    rebuilt = df.withColumn(
        "_rebuilt",
        F.when(F.col("available_qty") >= F.col("backorder_qty"),
               F.lit("Low - Stock Available"))
         .when((F.col("on_order_qty") > 0) | (F.col("in_transit_qty") > 0),
               F.lit("Medium - Supply In Pipeline"))
         .when(F.col("next_expected_receipt").isNotNull()
               & (F.col("next_expected_receipt") <= F.date_add(F.current_date(), 14)),
               F.lit("Medium - Receipt Expected"))
         .otherwise(F.lit("High - No Supply Visibility"))
    )

    agree = rebuilt.filter(F.col("_rebuilt") == F.col(label_col)).count()
    pct = 100 * agree / total if total else 0

    logger.info("\nLabel reconstructed from %s", present)
    logger.info("  agreement: %d / %d  (%.1f%%)", agree, total, pct)

    if pct > 95:
        logger.warning(
            "\n%s\nThe label is a deterministic function of these columns.\n"
            "A classifier given them learns the CASE statement, scores ~1.0, "
            "and tells you nothing you did not already encode.\n"
            "Exclude them — see PREDICTIVE_FRAMING in this file.\n%s",
            "=" * 70, "=" * 70,
        )
    elif pct > 80:
        logger.warning(
            "Largely reconstructable (%.1f%%). Most of the model's apparent "
            "skill would come from the rule, not from learning.", pct,
        )
    else:
        logger.info("Only %.1f%% reconstructable — the label carries signal "
                    "beyond these columns.", pct)

    present_derived = [c for c in DERIVED_FROM_LABEL_SOURCES if c in df.columns]
    if present_derived:
        logger.warning(
            "Also exclude %s — they are arithmetic on the same columns.",
            present_derived,
        )

    return {"rows": total, "agreement_pct": pct, "tested_columns": present}


PREDICTIVE_FRAMING = """
If the CASE columns are excluded, what is left to learn?

The honest question is not "what risk class does this row fall into" — that is
already computed. It is one of:

  1. WILL the order ship late?        Needs the actual ship date, i.e. the
                                      outcome, which this table does not carry.
  2. Will the expected receipt SLIP?  Needs receipt history: promised vs actual.
  3. Which orders become High NEXT?   Needs the same order observed over time.

All three need an outcome column this snapshot does not have. Until one is
available, the model below predicts the risk class from order and item
characteristics only (customer, warehouse, item, price, quantity, lead time)
with the rule columns removed. That is a real learning task — "which kinds of
orders tend to end up unsupplied" — and its accuracy will be well under 100%,
which is the point.
"""


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--table", default=RAW_TABLE)
    args, _ = parser.parse_known_args()
    return args


def main() -> int:
    from pyspark.sql import SparkSession
    args = parse_args()
    spark = SparkSession.builder.getOrCreate()
    try:
        check(spark, args.table)
        print(PREDICTIVE_FRAMING)
    except Exception as exc:
        logger.error("Check failed: %s", exc, exc_info=True)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
