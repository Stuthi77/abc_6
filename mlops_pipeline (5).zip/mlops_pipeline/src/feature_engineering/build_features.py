"""
build_features.py
-----------------
Builds a feature set from config: resample, aggregate, derive ratios, calendar
parts, lags and rolling statistics, then write the features and the label to
separate tables.

    python -m src.feature_engineering.build_features --feature_set weekly_orders
    python -m src.feature_engineering.build_features --dry_run

Why features and label go to different tables: the label is only known after
the fact, and keeping it out of the feature table is what stops it being fed
back in as a feature at scoring time.
"""
from __future__ import annotations

import argparse
import logging
import sys
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from src.settings.feature_settings import (
    DEFAULT_FEATURE_SET,
    FEATURE_SETS,
    AggregationSpec,
    FeatureSetConfig,
    LabelSpec,
    OneHotSpec,
    PointInTimeSpec,
    get_feature_set,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────
# Load
# ──────────────────────────────────────────────────────────────────────────
def load_source(spark, cfg: FeatureSetConfig) -> pd.DataFrame:
    sdf = spark.read.table(cfg.source_table)

    needed = {cfg.time_column, *cfg.group_cols,
              *{a.column for a in cfg.aggregations}}
    missing = [c for c in needed if c not in sdf.columns]
    if missing:
        raise ValueError(
            f"'{cfg.source_table}' is missing column(s) {sorted(missing)}.\n"
            f"Available: {sorted(sdf.columns)}"
        )

    df = sdf.toPandas()
    df[cfg.time_column] = pd.to_datetime(df[cfg.time_column], errors="coerce")

    bad = int(df[cfg.time_column].isna().sum())
    if bad:
        logger.warning("Dropping %d row(s) with an unparseable %s.",
                       bad, cfg.time_column)
        df = df.loc[df[cfg.time_column].notna()]

    if cfg.max_source_date:
        before = len(df)
        df = df.loc[df[cfg.time_column] < pd.Timestamp(cfg.max_source_date)]
        logger.info("Held out %d row(s) on or after %s.",
                    before - len(df), cfg.max_source_date)

    if df.empty:
        raise ValueError(f"No rows left from '{cfg.source_table}' after filtering.")
    logger.info("Loaded %d source row(s).", len(df))
    return df


# ──────────────────────────────────────────────────────────────────────────
# Aggregate
# ──────────────────────────────────────────────────────────────────────────
def _agg_callable(spec: AggregationSpec):
    if spec.func == "share_of":
        target = spec.equals
        return lambda s: (s == target).sum()
    return spec.func


def aggregate(df: pd.DataFrame, cfg: FeatureSetConfig) -> pd.DataFrame:
    grouper = [pd.Grouper(key=cfg.time_column, freq=cfg.freq), *cfg.group_cols]
    named = {spec.name: (spec.column, _agg_callable(spec))
             for spec in cfg.aggregations}

    out = df.groupby(grouper).agg(**named).reset_index()
    out = out.rename(columns={cfg.time_column: cfg.out_time_column})
    logger.info("Aggregated to %d row(s) at grain %s.",
                len(out), [cfg.out_time_column] + cfg.group_cols)
    return out


def add_ratios(df: pd.DataFrame, cfg: FeatureSetConfig) -> pd.DataFrame:
    if not cfg.ratios:
        return df
    out = df.copy()
    numerators = set()
    for name, (num, den) in cfg.ratios.items():
        # Guard the division: a zero denominator would give inf, which breaks
        # the models downstream rather than the feature job.
        out[name] = np.where(out[den] != 0, out[num] / out[den].replace(0, np.nan), 0.0)
        numerators.add(num)
    if cfg.drop_ratio_numerators:
        drop = [c for c in numerators if c in out.columns]
        out = out.drop(columns=drop)
        logger.info("Added %d ratio(s); dropped numerators %s.",
                    len(cfg.ratios), sorted(drop))
    return out


# ──────────────────────────────────────────────────────────────────────────
# Calendar
# ──────────────────────────────────────────────────────────────────────────
def add_calendar(df: pd.DataFrame, cfg: FeatureSetConfig) -> pd.DataFrame:
    col, cal = cfg.out_time_column, cfg.calendar
    out = df.copy()
    ts = out[col]

    if cal.year:
        out["year"] = ts.dt.year
    if cal.month:
        out["month"] = ts.dt.month
    if cal.quarter:
        out["quarter"] = ts.dt.quarter
    if cal.week_of_year:
        out["week_of_year"] = ts.dt.isocalendar().week.astype(int)
    if cal.week_of_month:
        out["week_of_month"] = (ts.dt.day - 1) // 7 + 1
    if cal.day_of_week:
        out["day_of_week"] = ts.dt.dayofweek
    if cal.boundary_flags:
        out["month_start"] = ts.dt.is_month_start.astype(int)
        out["month_end"] = ts.dt.is_month_end.astype(int)
        out["quarter_start"] = ts.dt.is_quarter_start.astype(int)
        out["quarter_end"] = ts.dt.is_quarter_end.astype(int)
        out["year_start"] = ts.dt.is_year_start.astype(int)
        out["year_end"] = ts.dt.is_year_end.astype(int)
    if cal.days_from_start:
        out["days_from_start"] = (ts - ts.min()).dt.days
    return out


# ──────────────────────────────────────────────────────────────────────────
# Lags and rollings
# ──────────────────────────────────────────────────────────────────────────
def add_lags_and_rollings(df: pd.DataFrame, cfg: FeatureSetConfig) -> pd.DataFrame:
    if not (cfg.lags or cfg.rollings):
        return df

    series = cfg.series_cols or cfg.group_cols

    # Sorting first is not optional. groupby().shift() operates on row ORDER,
    # not on the time column, so unsorted input silently produces lags that
    # point at the wrong period — with no error, and metrics that look fine.
    out = df.sort_values(series + [cfg.out_time_column]).copy()
    grouped = out.groupby(series, sort=False)

    for spec in cfg.lags:
        prefix = spec.prefix or f"{spec.column}_lag"
        for period in spec.periods:
            out[f"{prefix}_{period}"] = grouped[spec.column].shift(period)

    for spec in cfg.rollings:
        prefix = spec.prefix or spec.column
        for stat in spec.stats:
            for window in spec.windows:
                name = f"{prefix}_rolling_{stat}_{window}"
                if stat == "ewm":
                    out[name] = grouped[spec.column].transform(
                        lambda s, w=window: s.shift(1).ewm(span=w).mean()
                    )
                else:
                    out[name] = grouped[spec.column].transform(
                        lambda s, w=window, st=stat:
                            getattr(s.shift(1).rolling(w), st)()
                    )

    n_lag = sum(len(s.periods) for s in cfg.lags)
    n_roll = sum(len(s.stats) * len(s.windows) for s in cfg.rollings)
    logger.info("Added %d lag and %d rolling feature(s), keyed by %s.",
                n_lag, n_roll, series)
    return out


# ──────────────────────────────────────────────────────────────────────────
# Point-in-time history (row_level mode)
# ──────────────────────────────────────────────────────────────────────────
def add_point_in_time(df: pd.DataFrame, cfg: FeatureSetConfig) -> pd.DataFrame:
    """
    History features computed from each series' PRIOR rows only.

    The shift(1) before every statistic is the whole point. Without it a
    vendor's "average prior delay" includes the current order's own delay —
    which is the label — and the model learns to read the answer.
    """
    if not cfg.point_in_time:
        return df

    series = cfg.series_cols
    # Order within each series matters: "prior" is defined by this sort.
    out = df.sort_values(series + [cfg.time_column]).copy()
    grouped = out.groupby(series, sort=False)

    for spec in cfg.point_in_time:
        if spec.column not in out.columns:
            raise ValueError(
                f"Point-in-time '{spec.name}' needs column '{spec.column}', "
                f"absent from the source. Available: {sorted(out.columns)}"
            )

        if spec.stat == "rate":
            # Fraction of prior rows exceeding the threshold.
            flag = (out[spec.column] > spec.threshold).astype(float)
            out["__flag"] = flag
            g = out.groupby(series, sort=False)["__flag"]
            if spec.window is None:
                values = g.transform(lambda x: x.shift(1).expanding().mean())
            else:
                values = g.transform(
                    lambda x, w=spec.window: x.shift(1).rolling(w, min_periods=1).mean())
            out = out.drop(columns=["__flag"])
        else:
            g = grouped[spec.column]
            if spec.window is None:
                values = g.transform(
                    lambda x, st=spec.stat: getattr(x.shift(1).expanding(), st)())
            else:
                values = g.transform(
                    lambda x, w=spec.window, st=spec.stat:
                        getattr(x.shift(1).rolling(w, min_periods=1), st)())

        # A series' first row has no history — that is a real state, not a gap.
        out[spec.name] = values.fillna(spec.fill_value)

    logger.info("Added %d point-in-time feature(s), keyed by %s, from prior "
                "rows only.", len(cfg.point_in_time), series)
    return out


def add_one_hot(df: pd.DataFrame, cfg: FeatureSetConfig) -> pd.DataFrame:
    """
    Expand configured categoricals into integer flag columns.

    The category list is fixed in config rather than inferred from the data,
    so the column set is identical in training and scoring. Inferring it would
    produce a different frame whenever a batch happened to lack a category.
    """
    if not cfg.one_hot:
        return df

    out = df.copy()
    for spec in cfg.one_hot:
        if spec.column not in out.columns:
            raise ValueError(
                f"one_hot column '{spec.column}' not in the frame. "
                f"Available: {sorted(out.columns)}"
            )
        prefix = spec.prefix or spec.column
        values = out[spec.column].astype("object")

        for category in spec.categories:
            out[f"{prefix}_{category}"] = (values == category).astype("int32")

        if spec.other_flag:
            known = values.isin(spec.categories)
            out[f"{prefix}_other"] = (~known & values.notna()).astype("int32")
            unseen = sorted(set(values.dropna().unique()) - set(spec.categories))
            if unseen:
                logger.info("'%s': %d value(s) outside the configured "
                            "categories folded into _other: %s",
                            spec.column, len(unseen), unseen[:10])

        if spec.drop_original:
            out = out.drop(columns=[spec.column])

        logger.info("One-hot '%s' -> %d flag column(s).",
                    spec.column, len(spec.output_names()))
    return out


def add_label(df: pd.DataFrame, cfg: FeatureSetConfig) -> pd.DataFrame:
    """Bin a continuous column into classes."""
    spec: Optional[LabelSpec] = cfg.label
    if spec is None:
        return df

    if spec.source_column not in df.columns:
        raise ValueError(
            f"Label '{spec.name}' needs column '{spec.source_column}', absent "
            f"from the source. Available: {sorted(df.columns)}"
        )

    out = df.copy()

    if spec.is_binned:
        # Continuous -> classes.
        edges = [-np.inf, *spec.bins, np.inf]
        out[spec.name] = pd.cut(out[spec.source_column], bins=edges,
                                labels=spec.labels, right=True)
    else:
        # Already categorical. `labels` fixes the class order so the integer
        # encoding is identical every run — otherwise training and scoring
        # could disagree about which class is 0.
        values = out[spec.source_column].astype(str)
        unknown = sorted(set(values.dropna().unique()) - set(spec.labels))
        if unknown:
            raise ValueError(
                f"Label '{spec.name}': values {unknown} are not in the "
                f"configured labels {spec.labels}. Add them, or fix the source."
            )
        out[spec.name] = pd.Categorical(values, categories=spec.labels)

    if spec.encode:
        mapping = {label: i for i, label in enumerate(spec.labels)}
        out[spec.encoded_name()] = out[spec.name].map(mapping).astype("int32")

    counts = out[spec.name].value_counts().to_dict()
    total = len(out)
    logger.info("Label '%s' from %s:", spec.name, spec.source_column)
    for label in spec.labels:
        n = counts.get(label, 0)
        logger.info("  %-8s %6d  (%5.1f%%)", label, n, 100 * n / total if total else 0)

    # Class balance decides which metric is meaningful. Accuracy on a 95/5
    # split is worse than useless.
    smallest = min(counts.get(l, 0) for l in spec.labels)
    if smallest == 0:
        raise ValueError(
            f"Class(es) with zero rows: {[l for l in spec.labels if not counts.get(l)]}. "
            f"Adjust the bins — a class the model never sees cannot be learned."
        )
    if smallest / total < 0.05:
        logger.warning(
            "Smallest class is %.1f%% of rows. Prefer f1_macro or balanced "
            "accuracy over plain accuracy, and consider class weights.",
            100 * smallest / total,
        )
    return out


def _load_with_history(spark, cfg: FeatureSetConfig) -> Tuple[pd.DataFrame, str]:
    """
    Load the source plus any history tables, tagged so the extras can be
    dropped after the history features are computed.

    Returns (dataframe, marker_column).
    """
    marker = "__is_source"
    sdf = spark.read.table(cfg.source_table)
    frames = [sdf.toPandas().assign(**{marker: True})]

    for table in cfg.history_tables:
        if not spark.catalog.tableExists(table):
            raise ValueError(f"history_table '{table}' does not exist.")
        extra = spark.read.table(table).toPandas()
        # Align columns: history rows only need what the history features read.
        missing = [c for c in frames[0].columns if c not in extra.columns
                   and c != marker]
        for col in missing:
            extra[col] = np.nan
        frames.append(extra[[c for c in frames[0].columns if c != marker]]
                      .assign(**{marker: False}))
        logger.info("Loaded %d history row(s) from '%s' (not emitted).",
                    len(extra), table)

    return pd.concat(frames, ignore_index=True), marker


def build_row_level(spark, cfg: FeatureSetConfig) -> pd.DataFrame:
    """
    One output row per source row: no resampling, no aggregation.

    For sources already at the modelling grain — one purchase order, one claim,
    one transaction — where the work is deriving history and a label rather
    than collapsing many rows into one.
    """
    sdf = spark.read.table(cfg.source_table)

    needed = set(cfg.passthrough_cols) | {cfg.time_column}
    needed |= {s.column for s in cfg.point_in_time}
    if cfg.label:
        needed.add(cfg.label.source_column)

    missing = [c for c in needed if c not in sdf.columns]
    if missing:
        raise ValueError(
            f"'{cfg.source_table}' is missing {sorted(missing)}.\n"
            f"Available: {sorted(sdf.columns)}"
        )

    df, marker = _load_with_history(spark, cfg)
    df[cfg.time_column] = pd.to_datetime(df[cfg.time_column], errors="coerce")

    bad = int(df[cfg.time_column].isna().sum())
    if bad:
        logger.warning("Dropping %d row(s) with an unparseable %s.",
                       bad, cfg.time_column)
        df = df.loc[df[cfg.time_column].notna()]

    if cfg.max_source_date:
        before = len(df)
        df = df.loc[df[cfg.time_column] < pd.Timestamp(cfg.max_source_date)]
        logger.info("Held out %d row(s) on or after %s.",
                    before - len(df), cfg.max_source_date)

    logger.info("Loaded %d row(s) (%d from the source table).",
                len(df), int(df[marker].sum()))

    # Coerce before the history features run — a mean over strings would fail,
    # and a Decimal mean produces another Decimal.
    for col in cfg.numeric_cols:
        if col in df.columns:
            before = str(df[col].dtype)
            df[col] = pd.to_numeric(df[col], errors="coerce")
            n_bad = int(df[col].isna().sum())
            if before != str(df[col].dtype):
                logger.info("  cast '%s': %s -> %s%s", col, before,
                            df[col].dtype,
                            f" ({n_bad} unparseable -> NaN)" if n_bad else "")
        else:
            logger.warning("numeric_cols lists '%s', absent from the source.", col)

    # History is computed over source AND history rows together, in date
    # order, so a validation row sees the training rows that preceded it.
    df = add_point_in_time(df, cfg)

    # Now drop the history-only rows: they were context, not output.
    if cfg.history_tables:
        before = len(df)
        df = df.loc[df[marker]].reset_index(drop=True)
        logger.info("Dropped %d history-only row(s); %d source row(s) remain.",
                    before - len(df), len(df))
    df = df.drop(columns=[marker])

    df = add_label(df, cfg)
    df = add_one_hot(df, cfg)

    if cfg.out_time_column != cfg.time_column:
        df[cfg.out_time_column] = df[cfg.time_column]
    df = add_calendar(df, cfg)

    # Keep: passthrough + history + calendar + label. The raw outcome columns
    # are dropped — they are what the label was derived FROM, so keeping them
    # would hand the answer straight to the model.
    one_hot_outputs = [n for spec in cfg.one_hot for n in spec.output_names()]
    one_hot_dropped = {spec.column for spec in cfg.one_hot if spec.drop_original}

    keep = list(dict.fromkeys(
        [c for c in cfg.passthrough_cols if c not in one_hot_dropped]
        + one_hot_outputs
        + [s.name for s in cfg.point_in_time]
        + [c for c in df.columns if c in
           ("year", "month", "quarter", "week_of_year", "week_of_month",
            "day_of_week", "days_from_start")]
        + ([cfg.label.name, cfg.label.encoded_name()] if cfg.label else [])
    ))
    keep = [c for c in keep if c in df.columns]

    dropped_outcomes = [c for c in df.columns
                        if c not in keep and c not in (cfg.out_time_column,)]
    if dropped_outcomes:
        logger.info("Dropping source column(s) not configured as features: %s",
                    sorted(dropped_outcomes))

    out = df[keep].reset_index(drop=True)
    logger.info("Row-level features: %d row(s) x %d column(s).", *out.shape)
    return out


# ──────────────────────────────────────────────────────────────────────────
# Build
# ──────────────────────────────────────────────────────────────────────────
def build(spark, cfg: FeatureSetConfig) -> pd.DataFrame:
    if cfg.mode == "row_level":
        out = build_row_level(spark, cfg)
        if cfg.dropna:
            before = len(out)
            out = out.dropna().reset_index(drop=True)
            logger.info("Dropped %d row(s) with NaN; %d remain.",
                        before - len(out), len(out))
        return out

    df = load_source(spark, cfg)
    out = aggregate(df, cfg)
    out = add_ratios(out, cfg)
    out = add_calendar(out, cfg)
    out = add_lags_and_rollings(out, cfg)

    if cfg.dropna:
        before = len(out)
        out = out.dropna().reset_index(drop=True)
        logger.info(
            "Dropped %d incomplete row(s) (the first periods of each series "
            "have no lag history); %d remain.", before - len(out), len(out),
        )

    if out.empty:
        raise ValueError(
            "No rows left after dropping incomplete ones. The longest lag or "
            "rolling window is probably longer than the series themselves."
        )
    return out


# ──────────────────────────────────────────────────────────────────────────
# Write
# ──────────────────────────────────────────────────────────────────────────
def write_target(spark, features: pd.DataFrame, cfg: FeatureSetConfig) -> None:
    """Upsert the label into its own table, keyed by merge_keys."""
    spec = cfg.target_table
    if spec is None:
        logger.info("No target table configured — skipping.")
        return

    cols = list(dict.fromkeys(spec.merge_keys + [spec.target_col]))
    missing = [c for c in cols if c not in features.columns]
    if missing:
        raise ValueError(f"Target table needs {missing}, absent from the features.")

    sdf = spark.createDataFrame(features[cols])

    if not spark.catalog.tableExists(spec.table_name):
        sdf.write.mode("overwrite").saveAsTable(spec.table_name)
        logger.info("Created target table '%s' with %d row(s).",
                    spec.table_name, features.shape[0])
        return

    # MERGE so a re-run updates existing periods instead of duplicating them.
    tmp = f"_tmp_target_{abs(hash(spec.table_name)) % 10**8}"
    sdf.createOrReplaceTempView(tmp)
    on_clause = " AND ".join(f"t.`{k}` = s.`{k}`" for k in spec.merge_keys)
    spark.sql(f"""
        MERGE INTO {spec.table_name} AS t
        USING {tmp} AS s
        ON {on_clause}
        WHEN MATCHED THEN UPDATE SET *
        WHEN NOT MATCHED THEN INSERT *
    """)
    logger.info("Merged %d row(s) into target table '%s'.",
                features.shape[0], spec.table_name)


def split_holdout(features: pd.DataFrame,
                  cfg: FeatureSetConfig) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Split into (train, holdout) by time.

    The holdout is the most recent rows — the only split that shows how the
    model behaves on orders it could not have seen. A random split mixes later
    periods into training and overstates the score.
    """
    spec = cfg.holdout
    if spec is None:
        return features, pd.DataFrame()

    ordered = features.sort_values(cfg.out_time_column).reset_index(drop=True)
    total = len(ordered)

    if total <= spec.train_rows:
        logger.warning(
            "Only %d row(s), at or below train_rows=%d — no holdout produced.",
            total, spec.train_rows,
        )
        return ordered, pd.DataFrame()

    if spec.strategy == "latest":
        train, holdout = ordered.iloc[:spec.train_rows], ordered.iloc[spec.train_rows:]
    else:
        holdout, train = ordered.iloc[:total - spec.train_rows], ordered.iloc[total - spec.train_rows:]

    logger.info(
        "Holdout split: %d train (%s to %s) | %d holdout (%s to %s)",
        len(train), train[cfg.out_time_column].min(), train[cfg.out_time_column].max(),
        len(holdout), holdout[cfg.out_time_column].min(), holdout[cfg.out_time_column].max(),
    )

    # A holdout whose classes differ from training's is not a fair check.
    if cfg.label and cfg.label.name in holdout.columns:
        tr = set(train[cfg.label.name].dropna().unique())
        ho = set(holdout[cfg.label.name].dropna().unique())
        if ho - tr:
            logger.warning(
                "Holdout contains class(es) absent from training: %s. The "
                "model cannot predict a class it never saw.", sorted(ho - tr),
            )
    return train.reset_index(drop=True), holdout.reset_index(drop=True)


def write_holdout(spark, holdout: pd.DataFrame, cfg: FeatureSetConfig) -> None:
    """Write the check set, label included, for scoring the deployed model."""
    spec = cfg.holdout
    if spec is None or holdout.empty:
        return
    (spark.createDataFrame(holdout).write.format("delta").mode("overwrite")
        .option("overwriteSchema", "true").saveAsTable(spec.table_name))
    logger.info("Wrote %d holdout row(s) to '%s' (label kept for scoring).",
                len(holdout), spec.table_name)


def write_features(spark, features: pd.DataFrame, cfg: FeatureSetConfig) -> None:
    """Write features, with the label removed."""
    spec = cfg.feature_store
    if spec is None:
        logger.info("No feature table configured — skipping.")
        return

    out = features.copy()

    # Drop the label AND its un-encoded twin: risk_level_encoded is the target,
    # but leaving risk_level behind would be the same information in text form.
    label_cols = {cfg.target_table.target_col} if cfg.target_table else set()
    if cfg.label:
        label_cols |= {cfg.label.name, cfg.label.encoded_name()}
    present = [c for c in label_cols if c in out.columns]
    if present:
        out = out.drop(columns=present)
        logger.info("Removed label column(s) %s from the feature table.",
                    sorted(present))

    sdf = spark.createDataFrame(out)

    if not spec.use_feature_store:
        # overwriteSchema: a changed feature set replaces the table outright,
        # so removed columns actually disappear.
        sdf.write.mode("overwrite").option("overwriteSchema", "true") \
           .saveAsTable(spec.table_name)
        logger.info("Wrote %d row(s) to Delta table '%s'.", len(out), spec.table_name)
        return

    try:
        from databricks.feature_engineering import FeatureEngineeringClient
        fe = FeatureEngineeringClient()
        create, write = fe.create_table, fe.write_table
        get = fe.get_table
    except ImportError:
        try:
            from databricks.feature_store import FeatureStoreClient
            fs = FeatureStoreClient()
            create, write, get = fs.create_table, fs.write_table, fs.get_table
        except ImportError as exc:
            raise RuntimeError(
                "No feature store client available. Install one:\n"
                "    %pip install databricks-feature-engineering\n"
                "or set use_feature_store=False to write a plain Delta table."
            ) from exc

    # The Feature Store keeps metadata that can outlive a DROP TABLE, so the
    # authority on existence is the catalog, not the FS client.
    exists = spark.catalog.tableExists(spec.table_name)
    if exists:
        try:
            get(spec.table_name)
        except Exception as exc:
            logger.warning(
                "'%s' exists in the catalog but the feature store has no "
                "record of it (%s). Recreating.", spec.table_name, exc,
            )
            exists = False

    if exists:
        # A merge adds and updates rows; it NEVER removes columns. If the
        # feature set has dropped or renamed columns since the last build, the
        # stale ones survive in the table and the next training run fails on
        # them — looking exactly as though the rebuild never happened.
        try:
            existing_cols = set(spark.read.table(spec.table_name).columns)
        except Exception:
            existing_cols = set()

        removed = sorted(existing_cols - set(out.columns))
        if removed:
            raise RuntimeError(
                f"'{spec.table_name}' still has column(s) {removed} that this "
                f"feature set no longer produces.\n"
                f"A feature-store merge cannot drop columns, so the stale ones "
                f"would remain and break training.\n"
                f"Drop the table and rebuild:\n"
                f"    spark.sql(\"DROP TABLE IF EXISTS {spec.table_name}\")\n"
                f"Then run this stage again."
            )

        write(name=spec.table_name, df=sdf, mode="merge")
        logger.info("Merged %d row(s) into feature table '%s'.",
                    len(out), spec.table_name)
    else:
        create(name=spec.table_name,
               primary_keys=spec.primary_keys,
               timestamp_keys=spec.timestamp_keys or None,
               df=sdf,
               description=spec.description)
        logger.info("Created feature table '%s' with %d row(s), keys=%s.",
                    spec.table_name, len(out), spec.primary_keys)


def run_feature_engineering(spark, cfg: FeatureSetConfig,
                            dry_run: bool = False) -> pd.DataFrame:
    cfg.validate()
    logger.info("FEATURES | %s: %s -> %s",
                cfg.name, cfg.source_table,
                cfg.feature_store.table_name if cfg.feature_store else "(no table)")

    features = build(spark, cfg)
    logger.info("Built %d row(s) x %d column(s).", *features.shape)

    if dry_run:
        logger.info("DRY RUN — nothing written.\nColumns: %s",
                    sorted(features.columns))
        return features

    # Hold back the check set BEFORE anything is written, so no holdout row
    # can reach the training tables.
    train, holdout = split_holdout(features, cfg)

    # Label first: if the feature write fails, the label is still consistent.
    write_target(spark, train, cfg)
    write_features(spark, train, cfg)
    write_holdout(spark, holdout, cfg)
    return features


# ──────────────────────────────────────────────────────────────────────────
# Entrypoint
# ──────────────────────────────────────────────────────────────────────────
def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--feature_set", default=DEFAULT_FEATURE_SET,
                        choices=sorted(FEATURE_SETS))
    parser.add_argument("--dry_run", action="store_true",
                        help="Build and report, write nothing.")
    args, _ = parser.parse_known_args()
    return args


def main() -> int:
    from pyspark.sql import SparkSession

    args = parse_args()
    spark = SparkSession.builder.getOrCreate()
    try:
        run_feature_engineering(spark, get_feature_set(args.feature_set),
                                dry_run=args.dry_run)
    except Exception as exc:
        logger.error("Feature engineering failed: %s", exc, exc_info=True)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())