"""
create_raw_table.py
-------------------
Builds dev_platform.mlops.fulfillment_risk_level — the RAW table for the
fulfillment-risk use case.

It is assembled from the PO facts you already have, deliberately WITHOUT the
pre-computed vendor aggregates (vendor_avg_delay, rolling_90d_*, ...). Those
are recomputed point-in-time during feature engineering instead.

Why drop and recompute rather than reuse:

    row: vendor_total_orders = 1, vendor_avg_delay = 9.0, delivery_delay = 9.0

When a vendor has one historical order and this row IS that order, its
"historical average delay" is this row's own label. The feature contains the
answer. Across a whole table that inflates validation scores and collapses in
production, where the current order's outcome is not yet known.

    python -m src.feature_engineering.create_raw_table
    python -m src.feature_engineering.create_raw_table --dry_run
"""
from __future__ import annotations

import argparse
import logging
import sys

from pyspark.sql import functions as F

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

SOURCE_FEATURES = "dev_platform.mlops.supplier_delay_features"
SOURCE_TRUTH = "dev_platform.mlops.supplier_delay_ground_truth"
RAW_TABLE = "dev_platform.mlops.fulfillment_risk_level"

# Facts known when the PO is placed. Everything here is an attribute of the
# order itself, not a statistic derived from outcomes.
ORDER_FACTS = [
    "PONUMBER", "VENDORID", "DOCDATE", "POTYPE",
    "total_items", "FRTAMNT", "promised_lead_time_days",
    "distinct_locations", "distinct_ship_methods",
    "max_date_pushed", "avg_date_pushed",
    "max_negotiation_gap", "avg_negotiation_gap",
    "order_month", "order_quarter", "order_day_of_week",
    "is_month_end_order", "is_quarter_end_order",
    "is_revised", "is_international",
    "ship_fedex_flag", "ship_ups_flag", "ship_ltl_flag",
    "ship_local_flag", "ship_other_flag",
    "order_size_encoded",
    "payment_net30_flag", "payment_net60_flag", "payment_net90_flag",
    "payment_prepaid_flag", "payment_other_flag",
]

# Deliberately EXCLUDED — leakage risk, recomputed point-in-time later.
EXCLUDED_AGGREGATES = [
    "vendor_avg_delay", "vendor_delay_rate", "vendor_avg_lead_time",
    "vendor_total_orders", "vendor_delay_stddev",
    "rolling_90d_avg_delay", "rolling_90d_delay_rate", "rolling_90d_order_count",
    "cancellation_rate",
]

# The outcome. Kept in the raw table because feature engineering needs it to
# build both the vendor history and the label; it never reaches the model.
OUTCOME_COLS = ["delivery_delay_days", "actual_lead_time_days"]


def build_raw(spark, dry_run: bool = False):
    features = spark.read.table(SOURCE_FEATURES)
    truth = spark.read.table(SOURCE_TRUTH)

    available = set(features.columns)
    keep = [c for c in ORDER_FACTS if c in available]
    missing = [c for c in ORDER_FACTS if c not in available]
    if missing:
        logger.warning("Not in '%s', skipping: %s", SOURCE_FEATURES, missing)

    dropped = [c for c in EXCLUDED_AGGREGATES if c in available]
    logger.info("Dropping %d pre-computed aggregate(s) — recomputed "
                "point-in-time during feature engineering: %s",
                len(dropped), dropped)

    # Only the outcome columns from the truth side; VENDORID and DOCDATE exist
    # on both and would arrive twice.
    truth_cols = [c for c in OUTCOME_COLS if c in truth.columns]
    truth_slim = truth.select("PONUMBER", *truth_cols)

    raw = features.select(*keep).join(truth_slim, on="PONUMBER", how="inner")

    total = raw.count()
    if total == 0:
        raise ValueError(
            f"Join of '{SOURCE_FEATURES}' and '{SOURCE_TRUTH}' on PONUMBER "
            f"produced no rows. Check the key dtypes match on both sides."
        )

    # One row per PO is assumed downstream; a duplicate key would inflate the
    # vendor history and double-count orders.
    distinct = raw.select("PONUMBER").distinct().count()
    if distinct != total:
        logger.warning(
            "%d row(s) but only %d distinct PONUMBER — duplicates will "
            "distort the vendor history.", total, distinct,
        )

    raw = raw.withColumn("DOCDATE", F.col("DOCDATE").cast("timestamp"))

    logger.info("Raw table: %d row(s) x %d column(s).", total, len(raw.columns))
    logger.info("  order facts : %d", len(keep))
    logger.info("  outcomes    : %s", truth_cols)
    logger.info("  date range  : %s",
                raw.select(F.min("DOCDATE"), F.max("DOCDATE")).collect()[0])

    if dry_run:
        logger.info("DRY RUN — nothing written.\nColumns: %s", sorted(raw.columns))
        raw.show(5, truncate=False)
        return raw

    (raw.write.format("delta").mode("overwrite")
        .option("overwriteSchema", "true").saveAsTable(RAW_TABLE))
    logger.info("Wrote '%s'.", RAW_TABLE)
    return raw


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry_run", action="store_true")
    args, _ = parser.parse_known_args()
    return args


def main() -> int:
    from pyspark.sql import SparkSession
    args = parse_args()
    spark = SparkSession.builder.getOrCreate()
    try:
        build_raw(spark, dry_run=args.dry_run)
    except Exception as exc:
        logger.error("Raw table build failed: %s", exc, exc_info=True)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
