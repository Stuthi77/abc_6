"""
runner.py
---------
Runs one Lakeflow Job's stages, in the order given by src/config/job_config.py.
Each stage is the same stage_* call the notebook cells make, so a job run and a
notebook run do exactly the same work.

A stage that raises fails the job (later stages are not run). Gated stages that
are not approved log what they would do and the job continues.
"""
from __future__ import annotations

import json
import logging
import time
from typing import Any, Callable, Dict, List, Tuple

from src import pipeline as p
from src.settings.job_settings import (
    FeatureEngineeringJob, MLOpsProcessJob, MonitoringJob, get_job_settings,
)

logger = logging.getLogger("src.jobs.runner")


def _run(steps: List[Tuple[str, Callable[[], Any]]], job: str) -> Dict[str, Any]:
    summary: Dict[str, Any] = {"job": job, "stages": []}
    for name, fn in steps:
        logger.info("=" * 70)
        logger.info("[%s] STAGE %s", job, name)
        t0 = time.time()
        result = fn()
        took = round(time.time() - t0, 1)
        logger.info("[%s] STAGE %s done in %.1fs", job, name, took)
        summary["stages"].append({"stage": name, "seconds": took,
                                  "result": _brief(result)})
    logger.info("=" * 70)
    logger.info("[%s] SUMMARY\n%s", job, json.dumps(summary, indent=2, default=str))
    return summary


def _brief(result: Any, limit: int = 2000) -> Any:
    """Keep the run summary readable: stringify, then truncate."""
    if result is None or isinstance(result, (bool, int, float, str)):
        return result
    text = json.dumps(result, default=str) if isinstance(result, (dict, list)) else str(result)
    return text if len(text) <= limit else text[:limit] + " ..."


# ── 1. Feature engineering ───────────────────────────────────────────────────────
def run_feature_engineering_job(dry_run_only: bool = False) -> Dict[str, Any]:
    s: FeatureEngineeringJob = get_job_settings("feature_engineering")
    steps: List[Tuple[str, Callable[[], Any]]] = []
    for fs in s.feature_sets:
        if s.dry_run_first or dry_run_only:
            steps.append((f"features_dry_run:{fs}",
                          lambda fs=fs: p.stage_features(fs, dry_run=True)))
        if not dry_run_only:
            steps.append((f"features:{fs}", lambda fs=fs: p.stage_features(fs)))
    return _run(steps, "feature_engineering")


# ── 2. MLOps process ────────────────────────────────────────────────────────────
def _register(s: MLOpsProcessJob) -> Any:
    code = p.stage_register(s.use_case, approved=s.approve_register,
                            skip_baseline=s.skip_baseline)
    if code not in (None, 0):
        raise RuntimeError(f"register returned exit code {code}")
    return code


def run_mlops_process_job() -> Dict[str, Any]:
    s: MLOpsProcessJob = get_job_settings("mlops_process")
    uc = s.use_case
    available: Dict[str, Callable[[], Any]] = {
        "train": lambda: p.stage_train(uc),
        "review": lambda: p.stage_review(uc),
        "register": lambda: _register(s),
        "status": lambda: p.stage_status(uc),
        "serve": lambda: p.stage_serve(uc, approved=s.approve_serve,
                                       wait=s.wait_for_endpoint),
    }
    logger.info("mlops_process | use_case=%s | approve_register=%s | approve_serve=%s",
                uc, s.approve_register, s.approve_serve)
    return _run([(n, available[n]) for n in s.stages], "mlops_process")


# ── 3. Monitoring ──────────────────────────────────────────────────────────────
def _score(s: MonitoringJob) -> Any:
    if s.skip_score_when_replayed:
        from src.monitoring.date_shift import replay_applied
        from src.settings.monitoring_settings import get_monitoring_config
        if replay_applied(p._spark(), get_monitoring_config(s.monitor)):
            logger.warning("score SKIPPED: the inference table is already shifted by "
                           "date_shift_days; scoring now would re-add the original, "
                           "unshifted dates. Set date_shift_days=0 for live scoring.")
            return {"skipped": "replay already applied"}
    return p.stage_score(s.monitor)


def run_monitoring_job() -> Dict[str, Any]:
    s: MonitoringJob = get_job_settings("monitoring")
    m = s.monitor
    available: Dict[str, Callable[[], Any]] = {
        "score": lambda: _score(s),
        "shift_dates": lambda: p.stage_shift_dates(m),
        "baseline": lambda: p.stage_baseline(m, approved=s.approve_baseline),
        "monitor": lambda: p.stage_monitor(m, wait=s.wait_for_refresh,
                                           recreate=s.recreate_monitor),
        "drift": lambda: p.stage_drift(m),
        "degradation": lambda: p.stage_degradation(m),
        "sync_dashboard": lambda: p.stage_sync_dashboard(m),
        "visualize": lambda: p.stage_visualize(m),
        "diagnose_monitor": lambda: p.stage_diagnose_monitor(m),
        "rollback": lambda: p.stage_rollback(m, approved=s.approve_rollback),
    }
    logger.info("monitoring | monitor=%s | approve_baseline=%s | approve_rollback=%s "
                "| recreate_monitor=%s", m, s.approve_baseline, s.approve_rollback,
                s.recreate_monitor)
    return _run([(n, available[n]) for n in s.stages], "monitoring")
