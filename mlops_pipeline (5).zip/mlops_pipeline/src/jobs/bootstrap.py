"""
bootstrap.py
------------
Job equivalent of the notebook's `%pip install -r requirements.txt` cell.

A Python script task gets its libraries from the task's environment, installed
before the script starts. Installing them from inside the running script is
not safe: databricks-feature-engineering pulls a newer databricks-sdk that only
loads cleanly in a fresh process (the notebook needs restartPython() for the
same reason). So this module only checks, and fails fast with the fix.

Fix: in the job's task environment, add the dependency
    -r /Workspace/<path to>/mlops_pipeline/requirements.txt
"""
import importlib.util
import logging
import os

logger = logging.getLogger("src.jobs.bootstrap")

# Import names of the packages in requirements.txt.
REQUIRED_MODULES = ("optuna", "xgboost", "lightgbm", "catboost", "sklearn",
                    "matplotlib", "mlflow", "databricks.sdk",
                    "databricks.feature_engineering")


def _missing():
    out = []
    for name in REQUIRED_MODULES:
        try:
            if importlib.util.find_spec(name) is None:
                out.append(name)
        except ModuleNotFoundError:      # parent package missing
            out.append(name)
    return out


def ensure_requirements(root: str) -> None:
    """Fail before any stage runs if the task environment lacks requirements."""
    missing = _missing()
    if not missing:
        logger.info("All requirements available.")
        return
    req = os.path.join(root, "requirements.txt")
    raise ModuleNotFoundError(
        f"Missing {missing}. The job task environment does not install the "
        f"project requirements. In the job: Environment and Libraries -> edit "
        f"the task environment -> add dependency  -r {req}  -> save, re-run.")
