"""
pipeline.py
-----------
Runs the three stages, with a deliberate human gate between each.

    features ──▶ train ──[review]──▶ register ──[status]──▶ serve
                                                      │
                            score ──▶ monitor ──▶ drift / degradation
                                                      │
                                              ──[approve]──▶ rollback

Each stage is a separate command. Nothing advances on its own: training does
not register a model, and registering a Champion does not put it in front of
traffic. That is the point — a model that wins on MAE by 0.3 days is not
automatically one you want serving production requests.

    python -m src.pipeline train    --use_case delay_days
    python -m src.pipeline review   --use_case delay_days      # read-only
    python -m src.pipeline register --use_case delay_days --approve
    python -m src.pipeline status   --use_case delay_days      # read-only
    python -m src.pipeline serve    --use_case delay_days --approve

`--approve` is required for the two stages that change shared state (the model
registry and the serving endpoint). Without it they print what they would do
and stop.
"""
from __future__ import annotations

import argparse
import logging
import sys
from typing import Any, Dict, Optional

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

from src.settings.feature_settings import get_feature_set
from src.settings.monitoring_settings import get_monitoring_config
from src.settings.mlops_settings import (
    DEFAULT_USE_CASE,
    USE_CASES,
    get_use_case,
    resolve_use_case,
    registration_metric_key,
    registration_pipeline,
    serving_config,
    training_config,
)


def _spark():
    from pyspark.sql import SparkSession
    return SparkSession.builder.getOrCreate()


def _gate(stage: str, approved: bool, what: str) -> bool:
    """Block a state-changing stage unless explicitly approved."""
    if approved:
        return True
    logger.warning(
        "\n%s\nSTAGE '%s' NOT RUN — it would %s.\nRe-run with --approve once you "
        "have reviewed the step above.\n%s",
        "=" * 70, stage, what, "=" * 70,
    )
    return False


# ──────────────────────────────────────────────────────────────────────────
# Stage 1 — train
# ──────────────────────────────────────────────────────────────────────────
def stage_train(use_case: str, dry_run: bool = False,
                fail_fast: bool = True) -> Dict[str, Any]:
    from src.training.model_training import run_training

    cfg = training_config(use_case)
    logger.info("TRAIN | models=%s | metric=%s (%s) | trials=%d",
                cfg.search.models, cfg.search.primary_metric,
                cfg.search.direction(), cfg.search.n_trials)

    results = run_training(_spark(), cfg, dry_run=dry_run, fail_fast=fail_fast)

    if not dry_run:
        logger.info("\n%s\nNEXT: review the runs, then\n"
                    "    python -m src.pipeline review --use_case %s\n%s",
                    "=" * 70, use_case, "=" * 70)
    return results


# ──────────────────────────────────────────────────────────────────────────
# Gate 1 — review what training produced
# ──────────────────────────────────────────────────────────────────────────
def stage_review(use_case: str) -> Dict[str, Any]:
    """Read-only. What would be registered, and how it compares to the Champion."""
    import mlflow
    from mlflow.tracking import MlflowClient

    uc = resolve_use_case(use_case)
    pipeline = registration_pipeline(uc)
    metric_key = registration_metric_key(uc)

    mlflow.set_registry_uri("databricks-uc")
    client = MlflowClient()

    logger.info("REVIEW | experiment: %s", uc.shared.experiment_path)
    logger.info("         metric    : %s (%s)", metric_key,
                uc.registration.metric_direction)

    experiment = mlflow.get_experiment_by_name(uc.shared.experiment_path)
    if experiment is None:
        logger.error("Experiment not found — has training run?")
        return {"candidates": []}

    runs = client.search_runs(
        [experiment.experiment_id],
        filter_string=uc.registration.run_filter,
        order_by=["attributes.start_time DESC"],
        max_results=20,
    )
    candidates = []
    for run in runs:
        value = run.data.metrics.get(metric_key)
        if value is None:
            continue
        candidates.append({
            "run_id": run.info.run_id,
            "run_name": run.data.tags.get("mlflow.runName", "?"),
            "status": run.info.status,
            metric_key: round(value, 4),
        })

    if not candidates:
        logger.warning("No candidate runs with metric '%s'.", metric_key)
    for c in candidates:
        logger.info("  %-12s %-10s %s=%s  (%s)", c["run_name"], c["status"],
                    metric_key, c[metric_key], c["run_id"][:8] + "...")

    # Incumbent, if any
    model_name = uc.shared.full_model_name
    champion = None
    try:
        mv = client.get_model_version_by_alias(
            model_name, pipeline.registry.champion_alias)
        champ_run = client.get_run(mv.run_id)
        champion = {
            "version": mv.version,
            metric_key: round(champ_run.data.metrics.get(metric_key, float("nan")), 4),
        }
        logger.info("Current Champion: v%s  %s=%s",
                    champion["version"], metric_key, champion[metric_key])
    except Exception:
        logger.info("No Champion registered yet — the first registration "
                    "becomes one.")

    logger.info("\n%s\nIf that looks right:\n"
                "    python -m src.pipeline register --use_case %s --approve\n%s",
                "=" * 70, use_case, "=" * 70)
    return {"candidates": candidates, "champion": champion, "metric": metric_key}


# ──────────────────────────────────────────────────────────────────────────
# Stage 2 — register
# ──────────────────────────────────────────────────────────────────────────
def stage_register(use_case: str, approved: bool = False,
                   skip_baseline: bool = False) -> Optional[int]:
    from src.model_registration.model_registration import run_pipeline

    pipeline = registration_pipeline(use_case)
    if not _gate("register", approved,
                 f"register a model version to {pipeline.catalog}."
                 f"{pipeline.schema} and may move the Champion alias"):
        return None

    import mlflow
    mlflow.set_registry_uri("databricks-uc")
    exit_code = run_pipeline(_spark(), pipeline, skip_baseline=skip_baseline,
                             fail_fast=True)

    if exit_code == 0:
        logger.info("\n%s\nNEXT: check what is registered, then\n"
                    "    python -m src.pipeline status --use_case %s\n%s",
                    "=" * 70, use_case, "=" * 70)
    return exit_code


# ──────────────────────────────────────────────────────────────────────────
# Gate 2 — what is registered vs what is serving
# ──────────────────────────────────────────────────────────────────────────
def stage_status(use_case: str) -> Dict[str, Any]:
    """Read-only. Registry aliases and the endpoint's pinned version."""
    import mlflow
    from mlflow.tracking import MlflowClient
    from src.serving.endpoint_manager import get_endpoint, resolve_plan, describe_plan

    uc = resolve_use_case(use_case)
    pipeline = registration_pipeline(uc)
    serving = serving_config(use_case)
    model_name = uc.shared.full_model_name

    mlflow.set_registry_uri("databricks-uc")
    client = MlflowClient()

    logger.info("REGISTRY | %s", model_name)
    aliases = {}
    for alias in (pipeline.registry.champion_alias, pipeline.registry.challenger_alias):
        try:
            mv = client.get_model_version_by_alias(model_name, alias)
            aliases[alias] = mv.version
            logger.info("  %-12s version %s", alias, mv.version)
        except Exception:
            logger.info("  %-12s not set", alias)

    logger.info("SERVING  | %s", serving.endpoint_name)
    try:
        endpoint = get_endpoint(serving.endpoint_name)
    except Exception as exc:
        logger.warning("  could not read endpoint: %s", exc)
        endpoint = None

    served_version = None
    if endpoint is None:
        logger.info("  endpoint does not exist yet")
    else:
        config = getattr(endpoint, "config", None) or getattr(endpoint, "pending_config", None)
        for entity in (getattr(config, "served_entities", None) or []):
            served_version = getattr(entity, "entity_version", None)
            logger.info("  serving %s v%s",
                        getattr(entity, "entity_name", "?"), served_version)

    champion_version = aliases.get(pipeline.registry.champion_alias)
    if champion_version and served_version and str(champion_version) != str(served_version):
        logger.warning(
            "Endpoint is serving v%s but the Champion is v%s. Serving pins a "
            "version, so promotion does not roll out on its own.",
            served_version, champion_version,
        )
    elif champion_version and served_version:
        logger.info("Endpoint is serving the current Champion.")

    logger.info("\n%s\nTo roll the Champion out:\n"
                "    python -m src.pipeline serve --use_case %s --approve\n%s",
                "=" * 70, use_case, "=" * 70)
    return {"aliases": aliases, "served_version": served_version}


# ──────────────────────────────────────────────────────────────────────────
# Stage 3 — serve
# ──────────────────────────────────────────────────────────────────────────
def stage_serve(use_case: str, approved: bool = False, wait: bool = True,
                gateway_only: bool = False) -> Optional[Dict[str, Any]]:
    from src.serving.endpoint_manager import (
        apply_ai_gateway, deploy_endpoint, describe_plan, resolve_plan,
    )

    cfg = serving_config(use_case)

    if gateway_only:
        if not _gate("serve", approved,
                     f"change AI Gateway settings on '{cfg.endpoint_name}'"):
            return None
        apply_ai_gateway(cfg)
        return {"action": "gateway_updated", "endpoint": cfg.endpoint_name}

    plan = resolve_plan(cfg)
    logger.info("\n%s", describe_plan(cfg, plan))

    if not _gate("serve", approved,
                 f"create or update the serving endpoint '{cfg.endpoint_name}' "
                 f"and change what production traffic hits"):
        return None

    return deploy_endpoint(cfg, wait=wait)


# ──────────────────────────────────────────────────────────────────────────
# Stage 0 — features
# ──────────────────────────────────────────────────────────────────────────
def stage_raw(dry_run: bool = False):
    """Stage -1: build the raw table the feature set reads."""
    from src.feature_engineering.create_raw_table import build_raw
    return build_raw(_spark(), dry_run=dry_run)


def stage_check_leakage(table: Optional[str] = None):
    """Read-only: how much of the label is recoverable from its source columns."""
    from src.feature_engineering.check_label_leakage import check, RAW_TABLE
    return check(_spark(), table or RAW_TABLE)


def stage_holdout_check(use_case: str, feature_set: Optional[str] = None,
                        limit: Optional[int] = None):
    """Score the withheld rows against the deployed endpoint."""
    from src.serving.check_holdout import run_check
    return run_check(_spark(), use_case, feature_set, limit)


def stage_features(feature_set: str, dry_run: bool = False):
    from src.feature_engineering.build_features import run_feature_engineering
    cfg = get_feature_set(feature_set)
    return run_feature_engineering(_spark(), cfg, dry_run=dry_run)


# ──────────────────────────────────────────────────────────────────────────
# Stage 4 — score, monitor, and the two detectors
# ──────────────────────────────────────────────────────────────────────────
def stage_score(monitor: str, dry_run: bool = False):
    from src.monitoring.batch_inference import run_batch_inference
    return run_batch_inference(_spark(), get_monitoring_config(monitor),
                               dry_run=dry_run)


def stage_shift_dates(monitor: str):
    """Replay: shift the inference time column by batch.date_shift_days. Idempotent."""
    from src.monitoring.date_shift import shift_inference_dates
    return shift_inference_dates(_spark(), get_monitoring_config(monitor))


def stage_baseline(monitor: str, approved: bool = False, dry_run: bool = False):
    """Score the TRAINING features with the Champion -> monitor baseline table."""
    from src.monitoring.batch_inference import build_baseline
    cfg = get_monitoring_config(monitor)
    if not dry_run and not _gate("baseline", approved,
                                 f"overwrite the baseline table '{cfg.monitor.baseline_table}'"):
        return build_baseline(_spark(), cfg, dry_run=True)
    return build_baseline(_spark(), cfg, dry_run=dry_run)


def stage_monitor(monitor: str, refresh: bool = True, wait: bool = True,
                  recreate: bool = False):
    """Create / refresh / recreate the monitor, then sync its dashboard."""
    from src.monitoring.lakehouse_monitor import ensure_monitor
    cfg = get_monitoring_config(monitor)
    result = ensure_monitor(cfg, refresh=refresh, wait=wait, recreate=recreate)
    # Every create generates a fresh (unrepaired) dashboard.
    if cfg.dashboard.sync_on_monitor and wait and result.get("action") != "disabled":
        result["dashboard_sync"] = stage_sync_dashboard(monitor, verify=False)
    return result


def stage_sync_dashboard(monitor: str, verify: bool = True):
    """Repair the monitor-generated dashboard(s): slice / Model Id / Top K /
    fairness filters and dataset SQL. Idempotent."""
    from src.monitoring.lakehouse_monitor import sync_dashboards
    return sync_dashboards(get_monitoring_config(monitor), spark=_spark(),
                           verify=verify)


def stage_visualize(monitor: str):
    """Read-only: prediction, drift, quantile and fairness charts."""
    from src.monitoring.diagnose_monitor import render_monitoring_charts
    return render_monitoring_charts(_spark(), get_monitoring_config(monitor))


def stage_diagnose_monitor(monitor: str):
    """Read-only: check the inference table against the monitor's contract."""
    from src.monitoring.diagnose_monitor import diagnose
    return diagnose(_spark(), get_monitoring_config(monitor))


def stage_drift(monitor: str):
    from src.monitoring.check_drift import run_drift_check
    return run_drift_check(_spark(), get_monitoring_config(monitor))


def stage_degradation(monitor: str):
    from src.monitoring.check_rollback import run_rollback_check
    return run_rollback_check(_spark(), get_monitoring_config(monitor))


def stage_rollback(monitor: str, approved: bool = False):
    from src.monitoring.rollback import run_rollback
    return run_rollback(_spark(), get_monitoring_config(monitor),
                        approved=approved)


# ──────────────────────────────────────────────────────────────────────────
# Entrypoint
# ──────────────────────────────────────────────────────────────────────────
def parse_args():
    parser = argparse.ArgumentParser(description="MLOps pipeline stages")
    parser.add_argument(
        "stage",
        choices=["raw", "check_leakage", "features", "train", "review",
                 "register", "status", "serve", "holdout_check",
                 "score", "baseline", "monitor", "sync_dashboard",
                 "diagnose_monitor", "drift", "degradation", "visualize",
                 "rollback"])
    parser.add_argument("--use_case", default=DEFAULT_USE_CASE,
                        choices=sorted(USE_CASES))
    parser.add_argument("--approve", action="store_true",
                        help="Required for register and serve — they change "
                             "shared state.")
    parser.add_argument("--dry_run", action="store_true",
                        help="train: resolve data and splits, then stop.")
    parser.add_argument("--skip_baseline", action="store_true")
    parser.add_argument("--no_wait", action="store_true")
    parser.add_argument("--gateway_only", action="store_true",
                        help="serve: apply only the AI Gateway settings.")
    parser.add_argument("--feature_set", default=None,
                        help="features: which feature set (defaults to use_case).")
    parser.add_argument("--recreate", action="store_true",
                        help="monitor: delete and recreate against the "
                             "table's current schema.")
    parser.add_argument("--limit", type=int, default=None,
                        help="holdout_check: score only the first N rows.")
    parser.add_argument("--monitor_name", default=None,
                        help="score/monitor/drift/degradation/rollback: which "
                             "monitoring config (defaults to use_case).")
    args, _ = parser.parse_known_args()
    return args


def main() -> int:
    args = parse_args()

    monitor = args.monitor_name or args.use_case
    feature_set = args.feature_set or args.use_case

    if args.stage == "raw":
        stage_raw(dry_run=args.dry_run)
        return 0
    if args.stage == "check_leakage":
        stage_check_leakage()
        return 0
    if args.stage == "holdout_check":
        stage_holdout_check(args.use_case, args.feature_set, args.limit)
        return 0
    if args.stage == "features":
        stage_features(feature_set, dry_run=args.dry_run)
        return 0
    if args.stage == "score":
        stage_score(monitor, dry_run=args.dry_run)
        return 0
    if args.stage == "baseline":
        stage_baseline(monitor, approved=args.approve, dry_run=args.dry_run)
        return 0
    if args.stage == "monitor":
        stage_monitor(monitor, wait=not args.no_wait, recreate=args.recreate)
        return 0
    if args.stage == "sync_dashboard":
        stage_sync_dashboard(monitor)
        return 0
    if args.stage == "visualize":
        stage_visualize(monitor)
        return 0
    if args.stage == "diagnose_monitor":
        stage_diagnose_monitor(monitor)
        return 0
    if args.stage == "drift":
        stage_drift(monitor)
        return 0
    if args.stage == "degradation":
        stage_degradation(monitor)
        return 0
    if args.stage == "rollback":
        result = stage_rollback(monitor, approved=args.approve)
        return 0 if result.get("status") in ("rolled_back", "pending_approval") else 1

    if args.stage == "train":
        stage_train(args.use_case, dry_run=args.dry_run)
        return 0
    if args.stage == "review":
        stage_review(args.use_case)
        return 0
    if args.stage == "register":
        code = stage_register(args.use_case, approved=args.approve,
                              skip_baseline=args.skip_baseline)
        return 0 if code in (0, None) else code
    if args.stage == "status":
        stage_status(args.use_case)
        return 0
    if args.stage == "serve":
        stage_serve(args.use_case, approved=args.approve, wait=not args.no_wait,
                    gateway_only=args.gateway_only)
        return 0
    return 1


if __name__ == "__main__":
    sys.exit(main())