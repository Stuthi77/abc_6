"""
retry.py
--------
Retry decorator for MLflow / Databricks API calls.

Retries TRANSIENT failures only. The original retried everything, which turned
a permanent error — a model artifact that does not exist — into three identical
failures and a fifteen-second wait before the real message appeared.
"""
from __future__ import annotations

import functools
import logging
import time
from typing import Callable, Iterable, Optional, Tuple, Type

logger = logging.getLogger(__name__)

# Substrings that mark a failure as worth retrying: the call might succeed if
# repeated. Anything else is permanent and is re-raised immediately.
TRANSIENT_MARKERS: Tuple[str, ...] = (
    "timeout", "timed out",
    "temporarily unavailable", "service unavailable",
    "rate limit", "too many requests", "429",
    "500", "502", "503", "504",
    "connection reset", "connection aborted", "connection refused",
    "broken pipe", "remote end closed",
    "deadline exceeded", "unavailable",
)

# Never retried, however the message reads — repeating cannot help.
PERMANENT_MARKERS: Tuple[str, ...] = (
    "resource_does_not_exist", "does not exist", "not found",
    "unable to find a logged_model",
    "permission denied", "unauthorized", "forbidden",
    "invalid_parameter_value", "already exists",
)


def _is_transient(exc: BaseException) -> bool:
    message = str(exc).lower()
    if any(marker in message for marker in PERMANENT_MARKERS):
        return False
    return any(marker in message for marker in TRANSIENT_MARKERS)


def _retry(
    max_attempts: int = 3,
    initial_delay: float = 2.0,
    backoff: float = 2.0,
    retry_on: Optional[Iterable[Type[BaseException]]] = None,
) -> Callable:
    """
    Retry a flaky call with exponential backoff.

        @_retry()
        def _safe_get_run(client, run_id):
            return client.get_run(run_id)

    Args:
        max_attempts:  total tries, including the first.
        initial_delay: seconds before the second attempt.
        backoff:       multiplier applied to the delay each time.
        retry_on:      exception types to consider; None means any, subject to
                       the transient/permanent check.
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            delay = initial_delay
            last: Optional[BaseException] = None

            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except Exception as exc:
                    last = exc

                    if retry_on and not isinstance(exc, tuple(retry_on)):
                        raise

                    # Permanent failure: surface it now rather than after
                    # three identical attempts.
                    if not _is_transient(exc):
                        logger.debug(
                            "'%s' failed permanently (%s) — not retrying.",
                            func.__name__, type(exc).__name__,
                        )
                        raise

                    if attempt == max_attempts:
                        break

                    logger.warning(
                        "'%s' attempt %d/%d failed (%s); retrying in %.1fs.",
                        func.__name__, attempt, max_attempts, exc, delay,
                    )
                    time.sleep(delay)
                    delay *= backoff

            raise RuntimeError(
                f"MLflow call '{func.__name__}' failed after {max_attempts} "
                f"attempt(s). Last error: {last}"
            ) from last

        return wrapper
    return decorator
