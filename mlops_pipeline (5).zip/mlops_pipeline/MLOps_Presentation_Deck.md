<!-- ================================================================
     MLOps Framework — Presentation Deck
     Fulfillment Risk Classification · October 2026
     ================================================================
     Usage: Each "---" marks a slide break. Present with any Markdown
     slide tool (Marp, reveal-md, Slidev) or paste into Google Slides /
     PowerPoint as speaker notes + content.
     ================================================================ -->

---

# Fulfillment Risk — MLOps Framework

**Config-driven model lifecycle on Databricks**

Build → Govern → Deploy → Monitor → Act

*October 2026*

> Speaker note: This deck walks through the complete MLOps pipeline using
> the fulfillment-risk classification model as a live, running example.
> Every number comes from the actual run on 21 Oct 2026.

---

# Agenda

1. Business Problem
2. Design Principles
3. Architecture Overview
4. Data & Feature Engineering
5. Model Training & Selection
6. Governance Gates
7. Deployment
8. Batch Scoring
9. Monitoring — Drift, Degradation & Fairness
   - Dashboard tour, KPI scorecard, KPI glossary, how to read each chart
10. Rollback Safety Net
11. Live Demo Walkthrough
12. Next Steps

---

# 1. Business Problem

**Question:** For each open backorder line, how likely is it that
we fail to fulfil it?

**Why it matters:** Planners and customer-service teams need to
prioritise the highest-risk lines *before* they miss a promise date.

### The model predicts one of four risk classes

| Code | Risk Class                      | Display Label |
|------|---------------------------------|---------------|
| 0    | Low — Stock Available           | Low Risk      |
| 1    | Medium — Supply In Pipeline     | Med-Low       |
| 2    | Medium — Receipt Expected       | Med-High      |
| 3    | High — No Supply Visibility     | High Risk     |

> Speaker note: The label is derived from supply-chain rules
> (available qty, in-transit, next receipt). The model learns to
> predict the label *without* seeing those rule columns — so it
> generalises to situations the rule didn't anticipate.

---

# 2. Design Principles

| Principle | What it means |
|-----------|---------------|
| **Config-driven** | All tables, columns, thresholds and model settings live in 3 Python config files. The notebook only calls `stage_*()` functions — zero hardcoded values. |
| **State each fact once** | Table names, keys and the target column are defined in `SharedConfig`. Training, serving and monitoring all derive from it. |
| **Approval gates** | Register, Serve, Baseline, Rollback do nothing unless `approve = true`. |
| **Idempotent & safe to re-run** | Scoring only fills missing periods; dashboard sync is a no-op when nothing changed. |
| **Reusable** | Adding a second use case (`delay_days`) required *zero code changes* — only new config entries. |

> Speaker note: The separation between "what" (config) and "how" (code)
> means a data scientist can add a new use case without touching any
> pipeline code.

---

# 3. Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                        CONFIG  (3 files)                           │
│  feature_config.py    mlops_config.py    monitoring_config.py      │
└──────────┬──────────────────┬──────────────────┬────────────────────┘
           │                  │                  │
     ┌─────▼─────┐     ┌─────▼─────┐     ┌──────▼──────┐
     │ FEATURES  │     │  TRAIN    │     │  MONITOR    │
     │ source →  │     │ 3 algos   │     │ score →     │
     │ transform │     │ 20 trials │     │ profile →   │
     │ → feature │     │ time CV   │     │ drift →     │
     │   table   │     │ MLflow    │     │ degrade →   │
     └─────┬─────┘     └─────┬─────┘     │ dashboard   │
           │                 │           └──────┬──────┘
           │           ┌─────▼─────┐            │
           │           │  GATE 1   │            │
           │           │  Review   │            │
           │           └─────┬─────┘            │
           │           ┌─────▼─────┐            │
           │           │ REGISTER  │            │
           │           │ UC model  │            │
           │           │ Champion  │            │
           │           └─────┬─────┘            │
           │           ┌─────▼─────┐            │
           │           │  GATE 2   │            │
           │           │  Status   │            │
           │           └─────┬─────┘            │
           │           ┌─────▼─────┐     ┌──────▼──────┐
           │           │   SERVE   │     │   GATE 3    │
           │           │ endpoint  │     │  Rollback   │
           │           │ AI Gatew. │     │ (if needed) │
           └───────────┴───────────┘     └─────────────┘
```

> Speaker note: Left column = build. Middle = govern and deploy.
> Right = operate and watch. The three config files sit above everything.

---

# 4. Data & Feature Engineering

### Input

| Table | Rows | Date range | Purpose |
|-------|------|------------|---------|
| `fulfillment_risk_level` | 3,500 | Dec 2024 – Sep 16 2026 | Training |
| `fulfillment_risk_validation` | 917 | Sep 16 – Sep 21 2026 | Scoring / monitoring |

### Transformations (all config-driven, no code)

* **Passthrough:** order\_number, item\_number, backorder\_qty, extended\_price, on\_hand\_qty, lead times
* **Point-in-time history:** item prior avg/max backorder, customer prior lines (shifted — never sees its own row)
* **One-hot encoding:** warehouse → WH1 / WH2 / WH3 / other (fixed categories for endpoint compatibility)
* **Calendar:** year, month, quarter, week\_of\_year, day\_of\_week, days\_from\_start
* **Label:** `fulfillment_risk_level` → encoded 0–3

### Output

| Table | Rows | Features |
|-------|------|----------|
| `fulfillment_risk_features` + `_truth` | 3,500 | 24 |
| `fulfillment_risk_validation_features` + `_truth` | 917 | 24 |

### What is deliberately excluded (and why)

`available_qty`, `on_order_qty`, `in_transit_qty`, `supply_gap_qty`,
`days_until_fulfillment` — these **are the labelling rule**. Including
them gives \~100% accuracy and teaches the model nothing.

> Speaker note: Training and validation use identical transformations
> via `_fulfillment_feature_set()`. The validation set borrows item
> history from the training table so features match what production
> would see.

---

# 5. Model Training & Selection

### Setup

* **Algorithms:** XGBoost, LightGBM, CatBoost
* **Tuning:** 20 Optuna trials per algorithm
* **Validation:** Time-based cross-validation (past predicts future)
* **Metric:** Weighted-mean macro F1 (handles class imbalance)
* **Tracking:** Every trial logged to MLflow

### Results (actual run — 21 Oct 2026)

| Model | Macro F1 | Run ID |
|-------|----------|--------|
| **LightGBM** | **0.8356** | `28f475d9…` |
| CatBoost | 0.8328 | `bf8d5651…` |
| XGBoost | 0.8285 | `989b395a…` |

**Winner: LightGBM** — best F1 by a small but consistent margin.

> Speaker note: All three models are competitive. The config makes it
> easy to add a fourth (e.g. random forest) — just add the name to
> `search.models` and a search-space entry.

---

# 6. Governance Gates

### GATE 1 — Review (read-only)

Compares all candidates to the current Champion.

```
candidate  status    f1_macro
catboost   FINISHED  0.8328
lightgbm   FINISHED  0.8356   ← best
xgboost    FINISHED  0.8285
champion   (none)
```

No existing Champion → LightGBM recommended.

### GATE 2 — Status (read-only)

Confirms registry alias matches the served version.

```
REGISTRY | fulfillment_risk_model_1
  champion     version 1
  challenger   not set
SERVING  | fulfillment-risk-endpoint
  champion-v1  100% traffic
```

### GATE 3 — Rollback (needs approval)

Promotes Challenger to Champion. Reversible — the demoted Champion
becomes Challenger.

> Speaker note: Gates 1 and 2 are safe to run any time — they change
> nothing. Gate 3 requires `approve = true` and is only triggered when
> sustained degradation is confirmed.

---

# 7. Deployment

### Registration (requires approval)

* Best run → Unity Catalog model `prod_platform.mlops.fulfillment_risk_model_1`
* Version 1 tagged as **Champion**
* Baseline scored from 3,500 training rows for later comparison

### Serving endpoint

| Setting | Value |
|---------|-------|
| Endpoint | `fulfillment-risk-endpoint` |
| Status | **READY** |
| Traffic | 100% on Champion v1 |
| Compute | Small / CPU / scale-to-zero |
| AI Gateway | Usage monitoring ON |
| Inference table | `fulfillment_risk_serving_1_*` |
| Rate limit | 100 requests/min |

> Speaker note: The endpoint serves the *deployed* model, not a local
> copy. Monitoring scores through this endpoint, so it measures what
> customers actually receive.

---

# 8. Batch Scoring

### What happens

1. Read 917 validation rows across 6 daily periods (Sep 16–21)
2. Send to `fulfillment-risk-endpoint` in batches of 100
3. Join actual outcomes (risk\_level\_encoded)
4. Add `warehouse_group` (PHX / LVL / ELP) for fairness slicing
5. Write to `fulfillment_risk_predictions`

### Actual output

| Period | Rows | Actuals matched |
|--------|------|-----------------|
| Sep 16 | 157 | 157 / 157 |
| Sep 17 | 239 | 239 / 239 |
| Sep 18 | 321 | 321 / 321 |
| Sep 19 | 18 | 18 / 18 |
| Sep 20 | 4 | 4 / 4 |
| Sep 21 | 178 | 178 / 178 |
| **Total** | **917** | **100%** |

> Speaker note: Only unscored periods are processed, so a re-run costs
> nothing. The `compare_model_refs=["challenger"]` setting would
> additionally score a Challenger side-by-side once one is registered.

---

# 9a. Monitoring — Baseline & Monitor Setup

### Baseline

| Item | Value |
|------|-------|
| Source | 3,500 training rows scored by Champion v1 |
| Table | `fulfillment_risk_model_1_baseline` |
| Warehouse split | PHX 1,574 · LVL 1,145 · ELP 781 |
| Schema match | ✓ matches inference table |

### Lakehouse Monitor

| Setting | Value |
|---------|-------|
| Type | InferenceLog (classification) |
| Granularity | 1 day |
| Time column | `order_date` (business date, not scoring time) |
| Slices | `warehouse_group` + binary per group |
| Output | `_profile_metrics` and `_drift_metrics` tables |
| Dashboard | Auto-generated, auto-synced |

> Speaker note: We window on the business date, not prediction\_timestamp.
> A backfill stamps every row with the same instant, collapsing into one
> window. Business dates spread them across real periods.

---

# 9b. Monitoring — Drift Detection

### Latest window (ending Oct 17)

**19 of 24 columns drifted** (threshold: 5)

Top drifters (by KS p-value):

| Feature | Signal |
|---------|--------|
| `requested_lead_time_days` | p ≈ 10⁻¹¹ |
| `days_from_start` | Calendar shift |
| `day_of_week` | Calendar shift |
| `extended_price` | Distribution moved |
| `item_prior_avg_price` | Distribution moved |
| `safety_stock` | Distribution moved |

### Interpretation

* Calendar features (`month`, `day_of_week`, `days_from_start`) drift
  because the monitoring data spans different calendar days than training.
* Business features (`lead times`, `prices`, `stock`) show genuine
  distribution movement.
* **Drift ≠ degradation.** This is a signal to investigate, not to
  act automatically.

> Speaker note: The drift charts show KS statistics rising above the
> 0.3 alert line and Wasserstein distance climbing from 40 to 135.
> The prediction distribution itself (JS divergence) also increases,
> indicating the model's output mix is shifting.

---

# 9c. Monitoring — Degradation Check

### Rule

Rollback triggers when live F1 is **20% worse** than training F1 for
**3 consecutive windows**.

### Current status: ✅ HEALTHY

| Metric | Value |
|--------|-------|
| Live F1 macro (latest window, Oct 16) | **0.844** |
| Training F1 macro (CV) | 0.836 |
| Difference | +1.0% *better* |
| Live F1 weighted (same window) | 0.868 |
| Consecutive breaches | 0 of 3 |

**Despite 19-column drift, the model's accuracy has not degraded.**
This is exactly the situation the two-stage design is built for:
drift triggers investigation; only sustained error rise triggers action.

> Speaker note: Compare like with like — macro F1 live (0.844) vs
> macro F1 in training (0.836). Live performance is in line with
> training, not suspiciously better. Weighted F1 is higher (0.868)
> because the large Med-High class is predicted well.

---

# 9d. Monitoring — Fairness

The model is monitored for fairness across **three warehouse groups**:
PHX, LVL, ELP.

### Four fairness metrics, tracked daily

| Metric | What it measures | Acceptable band |
|--------|------------------|-----------------|
| Demographic Parity Ratio | Positive-prediction rate per group vs overall | 0.80 – 1.25 |
| Equal Opportunity Ratio | True positive rate per group vs overall | 0.80 – 1.25 |
| Predictive Equality Ratio | False positive rate per group vs overall | 0.80 – 1.25 |
| Predictive Parity Ratio | Positive predictive value per group vs overall | 0.80 – 1.25 |

### Key observations (Oct 11–16)

* **Demographic parity:** LVL spikes to 1.38 on Oct 14 (outside band),
  then returns. PHX dips to 0.80 on Oct 15.
* **Equal opportunity:** All groups stay within 0.90–1.10. The model
  catches true positives equitably.
* **Predictive equality:** PHX consistently low (0.55–0.70), meaning
  fewer false positives for PHX — the model is *more conservative*
  there. ELP rises to 2.0 on Oct 16.
* **Predictive parity:** All groups within 0.95–1.10 — when the model
  says "high risk", it is equally right across warehouses.

> Speaker note: The fairness ratios use binary slices
> (`warehouse_group = 'PHX'` true/false) because the monitor only
> computes fairness on binary columns. The configuration function
> `binary_slices()` generates these automatically.

---

# 9e. Monitoring — Dashboard & Charts

### Generated dashboard (auto-synced)

| Verification | Result |
|--------------|--------|
| Total datasets | 26 |
| Datasets with errors | **0** |
| Empty datasets | **0** |
| Slices detected | 10 (3 groups × binary + aggregate) |
| Protected group default | `warehouse_group = 'PHX'` |

### Notebook charts (cell 31: `stage_visualize`)

| Chart | What it shows |
|-------|---------------|
| **Prediction Distribution** | Stacked bar per day: class mix across 6 periods. Med-High (class 2) dominates. Volume peaks at 321 on Oct 13. |
| **Drift (4 panels)** | KS statistic, prediction JS divergence, per-feature p-values, Wasserstein distance — all trending upward. |
| **Quantile Shifts (6 panels)** | Median and IQR movement for the top-6 drifting features. `extended_price` and `item_prior_avg_price` show sharp spikes on Oct 16. |
| **Fairness Ratios (4 panels)** | Daily demographic parity, equal opportunity, predictive equality, predictive parity by warehouse group. |

> Speaker note: Screenshot these charts for the slide deck. The
> dashboard is also browsable live in the Databricks workspace.

---

# 9f. Dashboard Tour — How the Page Is Organised

The monitoring dashboard (`fulfillment_risk_predictions Monitoring`) is one
page, read top to bottom. Each section answers one question.

| # | Section | Question it answers | Widgets |
|---|---------|---------------------|---------|
| 1 | **Header & filters** | Which time range, model version and slice am I looking at? | Start / End Time, Model Id, Slice Key, Slice Value, Granularity / Slice counters |
| 2 | **Inferences** | How much traffic is the model getting? | `# Inferences`, Inference Load Over Time, Top predicted class |
| 3 | **Performance** | Is the model still right? | Accuracy, F1 (Macro), F1 (Weighted), Precision (Weighted), Recall (Weighted), Performance Over Time, Confusion Matrix |
| 4 | **Prediction Drift** | Is the model's output mix changing? | Prediction Drift Over Time, `% Nulls in Predictions` |
| 5 | **Numerical Feature Drift** | Have numeric inputs moved? | `# Features with Numerical Drift`, drift table (last window), Numerical Feature Quantile Drift |
| 6 | **Categorical Feature Drift** | Have categorical inputs moved? | `# Features with Categorical Drift`, drift table (last window), Categorical Feature Drift heatmap |
| 7 | **Profiling** | What do the inputs look like right now? | Numerical / Categorical Data Profile Over Time |
| 8 | **Feature Data Quality** | Are inputs arriving broken? | `# Features with high % NULLs / Zeros / NaNs`, Data Quality Over Time, issues table |
| 9 | **Fairness & Bias** | Is any warehouse treated differently? | Fairness Ratio Over Time, Fairness Difference Over Time, metric / protected group / positive class filters |

### Filters that change every chart

| Filter | What it does | Default after sync |
|--------|--------------|--------------------|
| Start / End Time | Restricts the windows shown | Full range |
| Model Id | One version, or `*` = all versions aggregated | Champion version |
| Slice Key / Slice Value | Whole population (`No slice`) or one warehouse group | No slice |
| Comparison | `CONSECUTIVE` (vs previous window) or `BASELINE` (vs training) | — |
| Slice by Protected Group | Which group the fairness charts compare | `warehouse_group = 'PHX'` |

> Speaker note: The pipeline's `stage_sync_dashboard` repairs these filters
> after every monitor run (the generated dashboard hardcodes "No slice" and
> has no Model Id default). That is why the dashboard opens ready to read.

---

# 9g. KPI Scorecard — Latest Window (Oct 16)

The counter tiles at the top of the Performance and Inferences sections.
Model v1, whole population (no slice), 1-day window.

| KPI | Value | Reading |
|-----|-------|---------|
| # Inferences | **178** | Normal daily volume (range 4–321) |
| Accuracy | **86.5%** | 154 of 178 lines classified correctly |
| F1 Score (Macro) | **0.844** | Average across classes — every class counts equally |
| F1 Score (Weighted) | **0.868** | Weighted by class size — dominated by Med-High |
| Precision (Weighted) | **0.883** | When the model names a class, it is right 88% of the time |
| Recall (Weighted) | **0.865** | Of the true classes, 86.5% are found |
| Top predicted class | **Med-High (class 2)** | 109 of 178 predictions (61%) |
| % Nulls in Predictions | **0%** | Every request got a prediction |

### Performance over time (Performance Over Time chart)

| Day | Inferences | Accuracy | F1 macro | F1 weighted |
|-----|-----------:|---------:|---------:|------------:|
| Oct 11 | 157 | 0.860 | 0.810 | 0.863 |
| Oct 12 | 239 | 0.858 | 0.792 | 0.861 |
| Oct 13 | 321 | 0.850 | 0.800 | 0.851 |
| Oct 14 | 18 | 0.944 | 0.940 | 0.945 |
| Oct 15 | 4 | 1.000 | 1.000 | 1.000 |
| Oct 16 | 178 | 0.865 | 0.844 | 0.868 |

**Takeaway:** on full-volume days the model is stable at 85–87% accuracy.
Oct 14–15 look perfect only because they have 18 and 4 rows — always read
performance next to `# Inferences`.

### Per-class F1 (Oct 16) — where the model is weakest

| Class | F1 | Comment |
|-------|---:|---------|
| Low Risk (0) | 0.81 | Good |
| Med-Low (1) | 0.67 | **Weakest** — few examples, often confused with neighbours |
| Med-High (2) | 0.90 | Strong — majority class |
| High Risk (3) | 1.00 | Only 1 case — not statistically meaningful |

> Speaker note: For the business, the key message is "86–87% of lines
> correctly classified, every day, with no failed predictions". For the
> technical audience, point at Med-Low: it is the class to improve.

---

# 9h. KPI Glossary — What Each Number Means

### Performance KPIs

| KPI | Definition | Why we track it | Pipeline threshold |
|-----|------------|-----------------|--------------------|
| **Accuracy** | Correct predictions ÷ all predictions | Simple headline number for stakeholders | — |
| **Precision** | Of lines predicted as class X, share that really are X | Avoids crying wolf — false alarms waste planner time | — |
| **Recall** | Of lines that really are class X, share the model found | Avoids missing real risk — a missed High Risk line is a missed promise | — |
| **F1** | Harmonic mean of precision and recall | One balanced number per class | — |
| **F1 Macro** | Average F1 over classes, each class equal | Protects small classes (Med-Low, High Risk) from being hidden | Training selection metric (0.836) |
| **F1 Weighted** | Average F1 weighted by class size | Reflects the overall experience across all lines | **Degradation check: rollback if 20% worse for 3 windows** |
| **Confusion matrix** | Grid of predicted vs actual class | Shows *which* classes get mixed up | — |

### Volume & output KPIs

| KPI | Definition | Why we track it |
|-----|------------|-----------------|
| **# Inferences** | Rows scored in the window | Context for every other number; a sudden drop means an upstream feed issue |
| **Top predicted class** | Most frequent prediction | A sudden flip (e.g. to High Risk) is an early warning |
| **% Nulls in Predictions** | Requests with no prediction | Should always be 0% — anything else means serving errors |

### Drift KPIs

| KPI | Definition | Rule of thumb |
|-----|------------|---------------|
| **KS statistic / p-value** | Kolmogorov–Smirnov test: max gap between two numeric distributions | p < 0.05 = drifted (pipeline threshold) |
| **Wasserstein distance** | "Earth-mover" cost to turn one distribution into the other, in feature units | Watch the trend; no fixed cut-off |
| **PSI** | Population Stability Index | < 0.1 stable, 0.1–0.2 moderate, ≥ 0.2 significant |
| **Chi-squared p-value** | Test for categorical distribution change | p < 0.05 = drifted (pipeline threshold) |
| **JS distance** | Jensen–Shannon distance between category mixes (used for predictions) | 0 = identical, 1 = completely different |
| **# Features with drift** | Count of columns failing the test in the last window | Pipeline alerts at **≥ 5 columns** |

### Data-quality KPIs

| KPI | Definition | Why |
|-----|------------|-----|
| **% NULLs** | Share of missing values per feature | Broken joins or feeds |
| **% Zeros** | Share of zero values | Defaulted values masquerading as data |
| **% NaNs** | Share of not-a-number values | Failed numeric casts |

### Fairness KPIs (per warehouse group vs the rest)

| KPI | Definition | Acceptable band |
|-----|------------|-----------------|
| **Demographic parity** | Positive-prediction rate | 0.80–1.25 (ratio) / near 0 (difference) |
| **Equal opportunity** | True-positive rate (recall) | 0.80–1.25 |
| **Predictive equality** | False-positive rate | 0.80–1.25 |
| **Predictive parity** | Precision | 0.80–1.25 |

The dashboard shows each as a **ratio** (group ÷ rest, 1.0 = parity) and
a **difference** (group − rest, 0 = parity).

---

# 9i. How to Read Each Chart

| Chart | What you see | Healthy looks like | Act when |
|-------|--------------|--------------------|----------|
| **Inference Load Over Time** (bar) | Rows per window | Steady with the business calendar | Sudden drop to 0, or spike far above normal |
| **Performance Over Time** (line) | Accuracy, precision, recall, F1 per window | Flat lines in a narrow band | Downward trend on high-volume days |
| **Confusion Matrix** (heatmap) | Predicted vs actual counts, last window | Heavy diagonal | Large off-diagonal cell, esp. High Risk predicted as Low |
| **Prediction Drift Over Time** (bar) | Change in prediction class mix (JS distance) | Low, stable bars | Bars rising window after window |
| **Numerical drift table** | Features failing KS in the last window, with statistic and p-value | Few rows | Business features (prices, lead times, stock) at the top |
| **Numerical Feature Quantile Drift** (line) | Min / 5% / 25% / median / 75% / 95% / max per window, selectable feature | Bands roughly level | Median or band jumps (e.g. `extended_price` spike on Oct 16) |
| **Categorical drift heatmap** | Drift score per feature × window | Pale cells | A row turning dark |
| **Data Profile Over Time** (tables) | Count, mean, std, min, max, distinct, frequent items | Stable summaries | Mean or distinct count jumps |
| **Data Quality Over Time** (line) | % NULLs / Zeros / NaNs per feature | Flat | Any sudden rise |
| **Fairness Ratio / Difference Over Time** (bar) | Each fairness metric for the selected group | Inside the 0.80–1.25 band | Outside the band on several consecutive days |

### Notebook charts (`stage_visualize`) vs dashboard

| Notebook chart | Dashboard equivalent | Extra value |
|----------------|----------------------|-------------|
| Prediction Distribution by Model Version | Inference Load + Top predicted class | Full class mix per day, side by side per version |
| Prediction & Feature Drift (4 panels) | Prediction Drift + Numerical drift | Mean/max KS, top-8 p-values and Wasserstein on one page |
| Numerical Feature Quantile Drift (6 panels) | Quantile Drift (one feature at a time) | Six top drifters at once |
| Fairness Ratio Over Time (4 panels) | Fairness Ratio (one metric at a time) | All four metrics and all groups at once |

### What the charts say today (Oct 11–16)

* **Volume:** 4–321 rows/day; Oct 14–15 are thin and should not be judged.
* **Performance:** 85–87% accuracy on full days; Med-Low is the weak class.
* **Drift:** mean KS rises above the 0.3 alert line from Oct 16;
  `requested_lead_time_days` is the strongest real drifter. Calendar
  features drift because of the replay date shift.
* **Fairness:** equal opportunity and predictive parity stay in band for all
  three warehouses. Demographic parity for LVL (1.38 on Oct 14) and
  predictive equality for PHX (low) and ELP (2.0 on Oct 16) go outside the
  band — mostly on thin days, so watch rather than act.

> Speaker note: Open the live dashboard here and click through the Slice
> filter (PHX → LVL → ELP) to show the same KPIs per warehouse.

---

# 10. Rollback Safety Net

### How it works

```
  Drift detected
       │
       ▼
  Check degradation
       │
  ┌────┴────┐
  │ Healthy │──── No action. Log and continue.
  │         │
  └─────────┘
  ┌─────────────┐
  │ 3 breaches  │──── Alert + offer rollback
  │ in a row    │
  └──────┬──────┘
         ▼
  Approval gate (approve = true)
         │
         ▼
  Swap champion ↔ challenger aliases
  (reversible — old champion becomes challenger)
         │
         ▼
  Settling period (24 h) — recent windows belong
  to the old model; don't judge the new one on them
```

### Current state

* **No Challenger registered** — rollback is designed but cannot trigger yet.
* **No degradation** — the gate would not fire even if a Challenger existed.

> Speaker note: Registering a Challenger is the next step. The config
> already has `compare_model_refs=["challenger"]` so scoring will
> evaluate both versions side by side once the alias is set.

---

# 11. Single Record Walkthrough

Follow order `810564`, item `001011` through every stage:

| Stage | What happens |
|-------|--------------|
| **Raw** | Order line: backorder qty 5, on-hand qty 8, extended price 217.95, requested lead time 21 days, order date Sep 16 |
| **Features** | + item history: 0 prior lines (first time this item appears, so history features are 0), warehouse flags `wh_other=1`, month=9, day_of_week=2 |
| **Endpoint** | JSON → `fulfillment-risk-endpoint` → returns class **2** |
| **Inference table** | `prediction_final=2`, `risk_level_encoded=2` (actual = "Medium - Receipt Expected" — **correct**), `model_version=1`, `warehouse_group=ELP` |
| **Monitor** | Order date replayed to Oct 11, so this row counts in the Oct 11 window's accuracy, F1, confusion matrix, ELP fairness metrics and per-feature drift |

> Speaker note: The same row flows through unchanged config paths.
> If we add a feature (e.g. supplier reliability score), only the
> config changes — the pipeline picks it up automatically.

---

# 12. Governance Summary

| Control | Implementation |
|---------|----------------|
| **Human approval** | 3 gates: Register, Serve, Rollback |
| **Lineage** | Every model version → MLflow run → parameters, metrics, training data |
| **Production truth** | Monitoring scores via the live endpoint, not a local model copy |
| **Fairness** | 3 warehouse groups × 4 metrics × daily windows |
| **Drift ≠ action** | Drift is a signal to look; only sustained error rise triggers rollback |
| **Reversibility** | Rollback swaps aliases; the demoted Champion becomes Challenger |
| **Auditability** | Config files are versioned; no magic numbers in the notebook |

---

# 13. Technology Stack

| Layer | Technology |
|-------|------------|
| Feature store | Delta tables (plain overwrite — no FS merge issues) |
| Training | XGBoost, LightGBM, CatBoost via Optuna + MLflow |
| Model registry | Unity Catalog (Champion / Challenger aliases) |
| Serving | Model Serving endpoint + AI Gateway |
| Monitoring | Lakehouse Monitor (profile + drift metrics) |
| Dashboard | Auto-generated by monitor, auto-synced by pipeline |
| Fairness | Binary slices per warehouse group (monitor-native) |
| Orchestration | Notebook cells calling `stage_*()` from `pipeline.py` |
| Config | 3 Python dataclass files with `validate()` |

---

# 14. Adding a New Use Case

The framework is **reusable**. Adding a second model requires
**zero code changes** — only config entries:

| Step | File | What to add |
|------|------|-------------|
| 1 | `feature_config.py` | A `FeatureSetConfig` (source table, transformations, output) |
| 2 | `mlops_config.py` | A `UseCase` (shared facts, training, registration, serving) |
| 3 | `monitoring_config.py` | A `from_use_case(...)` entry (scoring, thresholds, slicing) |
| 4 | Notebook | Re-run cell 5 — new values appear in the dropdown widgets |

**Already done:** `delay_days` (supplier delay regression) runs on the
same pipeline today.

---

# 15. Known Limitations & Transparency

| Item | Detail |
|------|--------|
| **Date shift** | Validation data (Sep 16–21) was older than the monitor's 30-day lookback. Replayed +25 days via `date_shift_days=25` in config. Calendar-feature drift is an artefact of this shift. |
| **Sample size** | Live KPIs (accuracy 86.5%, F1 macro 0.844 on Oct 16) come from 917 rows over 6 days — encouraging but small. |
| **No Challenger yet** | Rollback is designed and coded but cannot trigger until a second model version is registered. |
| **Warehouse flags (confirmed issue)** | One-hot categories are still the placeholders WH1/WH2/WH3. All 917 scored rows have `wh_other=1`, so the model currently gets **no warehouse signal**. Fix: set the real warehouse codes in `_FR_ONE_HOT` (`feature_config.py`), rebuild features and retrain. |
| **Alerts** | Email / webhook alerts are configured but `enabled = false`. Turn on for production. |

> Speaker note: Be upfront about these. They are engineering decisions,
> not defects — and each has a clear path to resolution.

---

# 16. Next Steps

| Priority | Action | Effort |
|----------|--------|--------|
| 1 | Score with **real recent data** (last 30 days) so the monitor runs without date shifts | Data team |
| 2 | Register a **Challenger** model to enable the rollback path | 1 cell run |
| 3 | **Enable alert emails** (`alerts.enabled = true`, add recipients) | Config edit |
| 4 | **Schedule** the notebook as a Lakeflow Job (daily or on new data) | Job creation |
| 5 | Set the **real warehouse codes** in the one-hot config, then rebuild features and retrain (every row currently lands in `wh_other`) | Config edit + retrain |
| 6 | Add **feature importance** chart to `stage_visualize` | Code + config |
| 7 | Evaluate adding a **supplier reliability** feature | Feature config |

---

# Appendix A — Project Layout

```
mlops_pipeline/
  run_mlops_notebook              One stage_*() call per cell
  MLOps_Framework_Guide.md        Full user guide
  MLOps_Presentation_Deck.md      This deck
  src/
    pipeline.py                   Stage functions + approval gates
    config/
      feature_config.py           Source, transforms, output tables
      mlops_config.py             Model, training, registration, serving
      monitoring_config.py        Scoring, monitor, drift, rollback, dashboard
    feature_engineering/
      build_features.py           Row-level and aggregate transforms
    training/
      model_training.py           Time-split CV, Optuna, MLflow
    model_registration/
      model_registration.py       UC registration, aliases, baseline
      promotion_functions.py      Champion / Challenger comparison
    serving/
      endpoint_manager.py         Endpoint CRUD, AI Gateway
    monitoring/
      batch_inference.py          Scoring, enrichment, upsert
      lakehouse_monitor.py        Monitor lifecycle, dashboard sync
      check_drift.py              Statistical drift detection
      check_rollback.py           Degradation check
      rollback.py                 Alias swap
```

---

# Appendix B — Key Tables

| Table | Purpose |
|-------|---------|
| `prod_platform.mlops.fulfillment_risk_level` | Training source (3,500 rows) |
| `prod_platform.mlops.fulfillment_risk_validation` | Validation source (917 rows) |
| `prod_platform.mlops.fulfillment_risk_features` | Training features (24 cols) |
| `prod_platform.mlops.fulfillment_risk_truth` | Training labels |
| `prod_platform.mlops.fulfillment_risk_validation_features` | Scoring features |
| `prod_platform.mlops.fulfillment_risk_validation_truth` | Scoring labels |
| `prod_platform.mlops.fulfillment_risk_predictions` | Inference table (917 rows) |
| `prod_platform.mlops.fulfillment_risk_model_1_baseline` | Baseline (3,500 rows) |
| `prod_platform.mlops.fulfillment_risk_predictions_profile_metrics` | Profile metrics |
| `prod_platform.mlops.fulfillment_risk_predictions_drift_metrics` | Drift metrics |

---

# Appendix C — Config Quick Reference

| You want to change… | Edit this file |
|---------------------|----------------|
| Source table, transforms, label, holdout | `feature_config.py` |
| Catalog, model name, target, keys, CV, models, metric, search space | `mlops_config.py` |
| Scoring mode, slicing, granularity, drift/rollback thresholds, alerts, dashboard, charts | `monitoring_config.py` |

---

# Thank You

**Questions?**

*Notebook:* `run_mlops_notebook`
*Guide:* `MLOps_Framework_Guide.md`
*Dashboard:* `fulfillment_risk_predictions Monitoring` (auto-generated)
